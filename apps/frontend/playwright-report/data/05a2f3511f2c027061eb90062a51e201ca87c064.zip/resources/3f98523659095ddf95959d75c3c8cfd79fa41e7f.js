(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "confirmMatorStage",
    ()=>confirmMatorStage,
    "createMatorConversation",
    ()=>createMatorConversation,
    "fetchMatorEvents",
    ()=>fetchMatorEvents,
    "fetchMatorModels",
    ()=>fetchMatorModels,
    "fetchMatorSettings",
    ()=>fetchMatorSettings,
    "listMatorConversations",
    ()=>listMatorConversations,
    "matorAttachmentFileUrl",
    ()=>matorAttachmentFileUrl,
    "matorSettingsUrl",
    ()=>matorSettingsUrl,
    "patchMatorMarkers",
    ()=>patchMatorMarkers,
    "postMatorMessage",
    ()=>postMatorMessage,
    "rejectMatorStage",
    ()=>rejectMatorStage,
    "restoreMatorPipeline",
    ()=>restoreMatorPipeline,
    "saveMatorSettings",
    ()=>saveMatorSettings,
    "switchMatorConversation",
    ()=>switchMatorConversation,
    "synthesizeMatorSpeech",
    ()=>synthesizeMatorSpeech,
    "transcribeMatorAudio",
    ()=>transcribeMatorAudio,
    "uploadMatorAttachment",
    ()=>uploadMatorAttachment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
;
function matorSettingsUrl() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('mator/settings');
}
function matorPath(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`mator/${path}`);
}
async function readJson(response, fallbackError) {
    const body = await response.json();
    if (!response.ok) {
        throw new Error(body.error || fallbackError);
    }
    return body;
}
async function readSettingsResponse(response, fallbackError) {
    return readJson(response, fallbackError);
}
async function fetchMatorModels() {
    const response = await fetch(matorPath('models'), {
        cache: 'no-store'
    });
    return readJson(response, 'Unable to load Groq models');
}
async function fetchMatorSettings() {
    const response = await fetch(matorSettingsUrl(), {
        cache: 'no-store'
    });
    return readSettingsResponse(response, 'Unable to load Mator settings');
}
async function saveMatorSettings(patch) {
    const response = await fetch(matorSettingsUrl(), {
        method: 'PUT',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(patch)
    });
    return readSettingsResponse(response, 'Unable to save Mator settings');
}
async function listMatorConversations(workflowId) {
    const response = await fetch(matorPath(`workflows/${encodeURIComponent(workflowId)}/conversations`), {
        cache: 'no-store'
    });
    return readJson(response, 'Unable to load conversations');
}
async function createMatorConversation(workflowId, title) {
    const response = await fetch(matorPath(`workflows/${encodeURIComponent(workflowId)}/conversations`), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(title ? {
            title
        } : {})
    });
    return readJson(response, 'Unable to create conversation');
}
async function switchMatorConversation(workflowId, conversationId) {
    const response = await fetch(matorPath(`workflows/${encodeURIComponent(workflowId)}/current`), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            conversationId
        })
    });
    return readJson(response, 'Unable to switch conversation');
}
async function fetchMatorEvents(conversationId) {
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/events`), {
        cache: 'no-store'
    });
    return readJson(response, 'Unable to load conversation events');
}
async function postMatorMessage(conversationId, body, idempotencyKey, signal) {
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/messages`), {
        method: 'POST',
        headers: {
            'content-type': 'application/json',
            'Idempotency-Key': idempotencyKey
        },
        signal,
        body: JSON.stringify(body)
    });
    return readJson(response, 'Unable to send message');
}
async function confirmMatorStage(conversationId, eventId) {
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/stage/${encodeURIComponent(eventId)}/confirm`), {
        method: 'POST'
    });
    return readJson(response, 'Unable to confirm staged action');
}
async function rejectMatorStage(conversationId, eventId) {
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/stage/${encodeURIComponent(eventId)}/reject`), {
        method: 'POST'
    });
    return readJson(response, 'Unable to reject staged action');
}
async function restoreMatorPipeline(conversationId, confirmDirty = false) {
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/restore-pipeline`), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            confirmDirty
        })
    });
    return readJson(response, 'Unable to restore pipeline');
}
function matorAttachmentFileUrl(attachmentId) {
    return matorPath(`attachments/${encodeURIComponent(attachmentId)}`);
}
function fileToBase64(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = ()=>{
            const result = reader.result;
            if (typeof result !== 'string') {
                reject(new Error('Unable to read attachment'));
                return;
            }
            const comma = result.indexOf(',');
            resolve(comma >= 0 ? result.slice(comma + 1) : result);
        };
        reader.onerror = ()=>reject(new Error('Unable to read attachment'));
        reader.readAsDataURL(file);
    });
}
async function uploadMatorAttachment(conversationId, file) {
    const data = await fileToBase64(file);
    const response = await fetch(matorPath(`conversations/${encodeURIComponent(conversationId)}/attachments`), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            filename: file.name,
            mime: file.type || 'application/octet-stream',
            data
        })
    });
    return readJson(response, 'Unable to upload attachment');
}
async function transcribeMatorAudio(file, signal) {
    const data = await fileToBase64(file);
    const mime = file.type || 'audio/webm';
    const extensionByMime = {
        'audio/mp4': 'm4a',
        'audio/x-m4a': 'm4a',
        'audio/mpeg': 'mp3',
        'audio/ogg': 'ogg',
        'audio/wav': 'wav',
        'audio/webm': 'webm'
    };
    const extension = extensionByMime[mime.split(';')[0].toLowerCase()] ?? 'webm';
    const response = await fetch(matorPath('audio/transcriptions'), {
        method: 'POST',
        signal,
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            data,
            mime,
            filename: `mator-speech.${extension}`
        })
    });
    const body = await readJson(response, 'Unable to transcribe speech');
    return body.text?.trim() ?? '';
}
async function synthesizeMatorSpeech(text, signal) {
    const response = await fetch(matorPath('audio/speech'), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            text
        }),
        signal
    });
    if (!response.ok) {
        let message = 'Unable to speak this reply';
        try {
            const body = await response.json();
            if (body.error) message = body.error;
        } catch  {
        /* binary or empty */ }
        throw new Error(message);
    }
    return response.blob();
}
async function patchMatorMarkers(attachmentId, markers, reviewId) {
    const response = await fetch(matorPath(`attachments/${encodeURIComponent(attachmentId)}/markers`), {
        method: 'PATCH',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            markers,
            ...reviewId !== undefined ? {
                reviewId
            } : {}
        })
    });
    return readJson(response, 'Unable to save markers');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-speech-chunks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Orpheus accepts at most 200 UTF-16 characters per speech request. */ __turbopack_context__.s([
    "chunkMatorSpeech",
    ()=>chunkMatorSpeech,
    "playMatorSpeechChunks",
    ()=>playMatorSpeechChunks
]);
function chunkMatorSpeech(input, limit = 190) {
    if (!Number.isInteger(limit) || limit < 20 || limit > 200) {
        throw new RangeError('Speech chunk limit must be between 20 and 200 characters');
    }
    let remaining = input.replace(/\s+/g, ' ').trim();
    const chunks = [];
    while(remaining.length > limit){
        const window = remaining.slice(0, limit);
        const punctuation = Math.max(window.lastIndexOf('. '), window.lastIndexOf('! '), window.lastIndexOf('? '));
        const whitespace = window.lastIndexOf(' ');
        let cut = limit;
        if (punctuation >= Math.floor(limit / 2)) {
            cut = punctuation + 1;
        } else if (whitespace >= Math.floor(limit / 2)) {
            cut = whitespace;
        }
        if (cut > 0 && cut < remaining.length && /[\uD800-\uDBFF]/.test(remaining[cut - 1]) && /[\uDC00-\uDFFF]/.test(remaining[cut])) {
            cut -= 1;
        }
        if (cut <= 0) cut = limit;
        chunks.push(remaining.slice(0, cut).trim());
        remaining = remaining.slice(cut).trim();
    }
    if (remaining) chunks.push(remaining);
    return chunks;
}
async function playMatorSpeechChunks(text, transport) {
    const chunks = chunkMatorSpeech(text);
    for(let i = 0; i < chunks.length; i += 1){
        if (transport.isCancelled()) return;
        try {
            const audio = await transport.synthesize(chunks[i]);
            if (transport.isCancelled()) return;
            await transport.play(audio);
        } catch  {
            if (!transport.isCancelled()) {
                await transport.fallback(chunks.slice(i).join(' '));
            }
            return;
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/voice-support.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "acquireCurrentVoiceStream",
    ()=>acquireCurrentVoiceStream,
    "createVoiceDeliveryGate",
    ()=>createVoiceDeliveryGate,
    "readVoiceSupport",
    ()=>readVoiceSupport
]);
function readVoiceSupport(scope) {
    try {
        if (!scope) return 'unsupported';
        const candidate = scope;
        if (typeof candidate.SpeechRecognition === 'function' || typeof candidate.webkitSpeechRecognition === 'function') {
            return 'ready';
        }
        return 'unsupported';
    } catch  {
        return 'unsupported';
    }
}
async function acquireCurrentVoiceStream(request, isCurrent) {
    const stream = await request();
    if (isCurrent()) return stream;
    for (const track of stream.getTracks())track.stop();
    return null;
}
function createVoiceDeliveryGate() {
    let epoch = 0;
    return {
        start: ()=>++epoch,
        invalidate: ()=>{
            epoch += 1;
        },
        isCurrent: (token)=>token === epoch
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/use-voice-session.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVoiceSession",
    ()=>useVoiceSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$speech$2d$chunks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-speech-chunks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$voice$2d$support$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/voice-support.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const VOICE_MISSING = 'Voice needs Chrome or Edge on this machine. Type a command instead.';
const VOICE_RETRY = "Voice didn't catch that. Try the mic again, or type a correction.";
const MIC_BLOCKED = 'Allow the microphone, or type a correction.';
let releaseActive = null;
function subscribeVoice() {
    return ()=>{};
}
function clientVoiceSupport() {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$voice$2d$support$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readVoiceSupport"])(window) === 'ready') return 'ready';
    if (typeof MediaRecorder === 'function' && typeof navigator.mediaDevices?.getUserMedia === 'function') {
        return 'ready';
    }
    return 'unsupported';
}
function serverVoiceSupport() {
    return 'pending';
}
function claim(release) {
    const previous = releaseActive;
    releaseActive = release;
    previous?.();
}
function recognitionConstructor(scope) {
    const candidate = scope;
    return candidate.SpeechRecognition ?? candidate.webkitSpeechRecognition ?? null;
}
function useVoiceSession({ onFinal, silenceMs = 1200 }) {
    _s();
    const support = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeVoice, clientVoiceSupport, serverVoiceSupport);
    const [listening, setListening] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [speaking, setSpeaking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [interim, setInterim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [muted, setMuted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const onFinalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onFinal);
    const mutedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const silenceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(silenceMs);
    const stopRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const audioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const recorderStopRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const speechEpochRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const speechAbortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const playbackCancelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const browserRetryRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const cancelRecorderRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const captureGenerationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const microphonePermissionPendingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const deliveryGateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$voice$2d$support$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createVoiceDeliveryGate"])());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useVoiceSession.useEffect": ()=>{
            onFinalRef.current = onFinal;
            mutedRef.current = muted;
            silenceRef.current = silenceMs;
        }
    }["useVoiceSession.useEffect"], [
        onFinal,
        muted,
        silenceMs
    ]);
    function stopSpeech() {
        speechEpochRef.current += 1;
        speechAbortRef.current?.abort();
        speechAbortRef.current = null;
        playbackCancelRef.current?.();
        playbackCancelRef.current = null;
        audioRef.current?.pause();
        audioRef.current = null;
        window.speechSynthesis?.cancel();
        setSpeaking(false);
    }
    function speakWithBrowser(clean, epoch) {
        return new Promise((resolve, reject)=>{
            if (speechEpochRef.current !== epoch) {
                resolve();
                return;
            }
            if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.speechSynthesis || typeof SpeechSynthesisUtterance === 'undefined') {
                reject(new Error('Browser speech output is unavailable.'));
                return;
            }
            const utterance = new SpeechSynthesisUtterance(clean);
            utterance.lang = 'en-US';
            const english = window.speechSynthesis.getVoices().find((voice)=>voice.lang.toLowerCase().startsWith('en'));
            if (english) utterance.voice = english;
            let settled = false;
            const finish = (problem)=>{
                if (settled) return;
                settled = true;
                if (playbackCancelRef.current === finish) playbackCancelRef.current = null;
                if (problem) reject(problem);
                else resolve();
            };
            playbackCancelRef.current = finish;
            utterance.onstart = ()=>{
                if (speechEpochRef.current === epoch) setSpeaking(true);
            };
            utterance.onend = ()=>finish();
            utterance.onerror = ()=>finish(new Error('Browser speech playback failed.'));
            window.speechSynthesis.speak(utterance);
        });
    }
    function playAudio(blob, epoch) {
        return new Promise((resolve, reject)=>{
            if (speechEpochRef.current !== epoch) {
                resolve();
                return;
            }
            const url = URL.createObjectURL(blob);
            const audio = new Audio(url);
            audioRef.current = audio;
            let settled = false;
            const finish = (problem)=>{
                if (settled) return;
                settled = true;
                audio.onended = null;
                audio.onerror = null;
                if (audioRef.current === audio) audioRef.current = null;
                if (playbackCancelRef.current === cancel) playbackCancelRef.current = null;
                audio.pause();
                URL.revokeObjectURL(url);
                if (problem) reject(problem);
                else resolve();
            };
            const cancel = ()=>finish();
            playbackCancelRef.current = cancel;
            audio.onplay = ()=>{
                if (speechEpochRef.current === epoch) setSpeaking(true);
            };
            audio.onended = ()=>finish();
            audio.onerror = ()=>finish(new Error('Audio playback failed'));
            void audio.play().catch((error)=>finish(error instanceof Error ? error : new Error('Audio playback failed')));
        });
    }
    function speakAndWait(text, force = false, signal) {
        if (("TURBOPACK compile-time value", "object") === 'undefined' || signal?.aborted || mutedRef.current && !force) {
            return Promise.resolve();
        }
        const clean = text.replace(/\s+/g, ' ').trim();
        if (!clean) return Promise.resolve();
        stopSpeech();
        const epoch = speechEpochRef.current;
        const controller = new AbortController();
        speechAbortRef.current = controller;
        const onAbort = ()=>stopSpeech();
        signal?.addEventListener('abort', onAbort, {
            once: true
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$speech$2d$chunks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playMatorSpeechChunks"])(clean, {
            synthesize: (segment)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["synthesizeMatorSpeech"])(segment, controller.signal),
            play: (blob)=>playAudio(blob, epoch),
            fallback: (remaining)=>speakWithBrowser(remaining, epoch),
            isCancelled: ()=>epoch !== speechEpochRef.current || controller.signal.aborted || signal?.aborted === true || mutedRef.current && !force
        }).catch((error)=>{
            if (speechEpochRef.current === epoch) {
                setError('Voice playback failed. The written reply is still available.');
            }
            throw error;
        }).finally(()=>{
            signal?.removeEventListener('abort', onAbort);
            if (speechEpochRef.current !== epoch) return;
            if (speechAbortRef.current === controller) speechAbortRef.current = null;
            setSpeaking(false);
        });
    }
    function speak(text, force = false) {
        // Non-call playback is optional. Call mode awaits and handles rejection.
        void speakAndWait(text, force).catch(()=>{});
    }
    function stopSpeaking() {
        if ("TURBOPACK compile-time truthy", 1) stopSpeech();
    }
    function toggleMute() {
        const next = !mutedRef.current;
        mutedRef.current = next;
        setMuted(next);
        if (next && ("TURBOPACK compile-time value", "object") !== 'undefined') stopSpeech();
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useVoiceSession.useEffect": ()=>({
                "useVoiceSession.useEffect": ()=>{
                    deliveryGateRef.current.invalidate();
                    captureGenerationRef.current += 1;
                    microphonePermissionPendingRef.current = false;
                    speechEpochRef.current += 1;
                    speechAbortRef.current?.abort();
                    playbackCancelRef.current?.();
                    audioRef.current?.pause();
                    window.speechSynthesis?.cancel();
                    cancelRecorderRef.current?.();
                    stopRef.current?.(false);
                }
            })["useVoiceSession.useEffect"]
    }["useVoiceSession.useEffect"], []);
    async function beginGroqRecording(deliveryToken) {
        const generation = ++captureGenerationRef.current;
        microphonePermissionPendingRef.current = true;
        setListening(true);
        setInterim('Waiting for microphone access…');
        let stream = null;
        try {
            stream = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$voice$2d$support$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireCurrentVoiceStream"])(()=>navigator.mediaDevices.getUserMedia({
                    audio: true
                }), ()=>captureGenerationRef.current === generation);
            if (!stream) return;
        } catch  {
            if (captureGenerationRef.current === generation) {
                setListening(false);
                setInterim('');
                setError(MIC_BLOCKED);
            }
            return;
        } finally{
            if (captureGenerationRef.current === generation) {
                microphonePermissionPendingRef.current = false;
            }
        }
        let recorder;
        try {
            recorder = new MediaRecorder(stream);
        } catch  {
            stream.getTracks().forEach((track)=>track.stop());
            setListening(false);
            setInterim('');
            setError(MIC_BLOCKED);
            return;
        }
        const chunks = [];
        recorder.ondataavailable = (event)=>{
            if (event.data.size > 0) chunks.push(event.data);
        };
        let stopRecorder = null;
        let cancelRecording = null;
        const release = ()=>{
            if (recorderStopRef.current === stopRecorder) recorderStopRef.current = null;
            if (cancelRecorderRef.current === cancelRecording) cancelRecorderRef.current = null;
            if (releaseActive === cancelRecording) releaseActive = null;
            stream.getTracks().forEach((track)=>track.stop());
            setListening(false);
            setInterim('');
        };
        recorder.onstop = ()=>{
            release();
            if (!deliveryGateRef.current.isCurrent(deliveryToken)) return;
            const blob = new Blob(chunks, {
                type: recorder.mimeType || 'audio/webm'
            });
            if (!blob.size) return;
            setInterim('Transcribing…');
            void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transcribeMatorAudio"])(blob).then((text)=>{
                if (!deliveryGateRef.current.isCurrent(deliveryToken)) return;
                setInterim('');
                if (text) onFinalRef.current(text);
                else setError(VOICE_RETRY);
            }).catch(()=>{
                if (!deliveryGateRef.current.isCurrent(deliveryToken)) return;
                setInterim('');
                browserRetryRef.current = Boolean(recognitionConstructor(window));
                setError(browserRetryRef.current ? 'Groq transcription failed. Tap the microphone again to re-record using browser speech recognition.' : 'Groq transcription failed. Retry the microphone or type your request.');
            });
        };
        stopRecorder = ()=>{
            if (recorder.state !== 'inactive') recorder.stop();
            else release();
        };
        recorderStopRef.current = stopRecorder;
        cancelRecording = ()=>{
            recorder.onstop = null; // A canceled recording must not submit audio.
            if (recorder.state !== 'inactive') recorder.stop();
            release();
        };
        cancelRecorderRef.current = cancelRecording;
        claim(cancelRecording);
        try {
            recorder.start();
        } catch  {
            cancelRecording();
            setError(MIC_BLOCKED);
            return;
        }
        setListening(true);
        setError(null);
        setInterim('Listening… tap again to transcribe');
    }
    function begin() {
        const deliveryToken = deliveryGateRef.current.start();
        stopSpeech(); // Barge-in cancels an active spoken reply.
        // Web Speech cannot transcribe a saved MediaRecorder Blob.
        // After a Groq error, the next explicit tap starts a new recording.
        const tryBrowser = browserRetryRef.current && Boolean(recognitionConstructor(window));
        browserRetryRef.current = false;
        if (!tryBrowser && typeof MediaRecorder !== 'undefined' && typeof navigator.mediaDevices?.getUserMedia === 'function') {
            void beginGroqRecording(deliveryToken);
            return;
        }
        const Ctor = recognitionConstructor(window);
        if (!Ctor) {
            setError(VOICE_MISSING);
            return;
        }
        stopSpeech();
        const recognition = new Ctor();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';
        let finals = '';
        let timer = 0;
        const finish = (emit)=>{
            if (recognition.settled) return;
            recognition.settled = true;
            if (releaseActive === release) releaseActive = null;
            window.clearTimeout(timer);
            try {
                recognition.abort();
            } catch  {
            /* already stopped */ }
            setInterim('');
            setListening(false);
            if (stopRef.current === finish) stopRef.current = null;
            const text = finals.trim();
            if (emit && text && deliveryGateRef.current.isCurrent(deliveryToken)) {
                onFinalRef.current(text);
            }
        };
        const release = ()=>finish(false);
        stopRef.current = finish;
        recognition.onresult = (event)=>{
            if (recognition.settled) return;
            let finalText = '';
            let interimText = '';
            for(let index = 0; index < event.results.length; index += 1){
                const result = event.results[index];
                const piece = result?.[0]?.transcript ?? '';
                if (result?.isFinal) finalText += piece;
                else interimText += piece;
            }
            finals = finalText;
            setInterim(`${finalText} ${interimText}`.replace(/\s+/g, ' ').trim());
            window.clearTimeout(timer);
            timer = window.setTimeout(()=>finish(true), silenceRef.current);
        };
        recognition.onerror = (event)=>{
            if (recognition.settled || event.error === 'aborted') return;
            recognition.settled = true;
            if (releaseActive === release) releaseActive = null;
            window.clearTimeout(timer);
            setListening(false);
            setInterim('');
            if (event.error === 'no-speech') return;
            setError(event.error === 'not-allowed' ? MIC_BLOCKED : VOICE_RETRY);
        };
        recognition.onend = ()=>{
            if (!recognition.settled) finish(true);
        };
        claim(release);
        try {
            recognition.start();
            setListening(true);
            setError(null);
            setInterim('');
        } catch  {
            finish(false);
            setError(VOICE_RETRY);
        }
    }
    function cancelPendingTranscript() {
        deliveryGateRef.current.invalidate();
        captureGenerationRef.current += 1;
        microphonePermissionPendingRef.current = false;
        cancelRecorderRef.current?.();
        stopRef.current?.(false);
        setListening(false);
        setInterim('');
    }
    function toggleListen() {
        if (microphonePermissionPendingRef.current) {
            cancelPendingTranscript();
            return;
        }
        if (listening) {
            if (recorderStopRef.current) recorderStopRef.current();
            else stopRef.current?.(true);
            return;
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        try {
            if (clientVoiceSupport() === 'unsupported') {
                setError(VOICE_MISSING);
                return;
            }
            begin();
        } catch  {
            setListening(false);
            setError(VOICE_RETRY);
        }
    }
    return {
        support,
        listening,
        speaking,
        interim,
        muted,
        error,
        toggleListen,
        toggleMute,
        speak,
        speakAndWait,
        stopSpeaking,
        cancelPendingTranscript
    };
}
_s(useVoiceSession, "ibmWF2HhJua0zLsGM7cWkOdJt2U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-composer-format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fileSizeLabel",
    ()=>fileSizeLabel,
    "iconButton",
    ()=>iconButton,
    "supportedFile",
    ()=>supportedFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
;
function supportedFile(file) {
    const name = file.name.toLowerCase();
    const images = [
        'image/png',
        'image/jpeg',
        'image/webp',
        'image/gif',
        'image/avif',
        'image/bmp',
        'image/tiff',
        'image/heic',
        'image/heif'
    ];
    return images.includes(file.type) || ([
        '.txt',
        '.md',
        '.markdown',
        '.readme'
    ].some((ext)=>name.endsWith(ext)) || /^readme(?:\.[a-z0-9_-]+)?$/.test(name)) && (!file.type || [
        'text/plain',
        'text/markdown',
        'application/octet-stream'
    ].includes(file.type));
}
function iconButton(tone, extra) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('inline-flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40', tone === 'default' && 'text-slate-500 hover:bg-slate-100 hover:text-slate-800', tone === 'active' && 'bg-teal-700 text-white hover:bg-teal-600', tone === 'danger' && 'text-rose-600 hover:bg-rose-50', extra);
}
function fileSizeLabel(bytes) {
    if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
    return `${bytes} B`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/model-selector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ModelSelector",
    ()=>ModelSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/check.mjs [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/sparkles.mjs [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function ModelSelector({ models, currentId, onSelect, disabled, compact, className }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const reducedMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const current = models.find((model)=>model.id === currentId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
        open: open,
        onOpenChange: setOpen,
        side: "top",
        align: "end",
        "aria-label": "Select chat model",
        className: className,
        trigger: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            "aria-haspopup": "dialog",
            "aria-expanded": open,
            disabled: disabled,
            onClick: ()=>setOpen((value)=>!value),
            "data-testid": "mator-model-selector",
            "aria-label": current ? `Chat model: ${current.label}` : 'Choose chat model',
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('inline-flex min-h-9 cursor-pointer items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 text-[11px] font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40', compact && 'min-h-11 px-2'),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                    className: "size-3 text-teal-700",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('max-w-28 truncate', compact && 'hidden'),
                    children: current?.label ?? 'Model'
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                    lineNumber: 58,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    "aria-hidden": "true",
                    className: "size-3 text-slate-400"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                    lineNumber: 61,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
            lineNumber: 42,
            columnNumber: 9
        }, this),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
            children: open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].ul, {
                initial: reducedMotion ? {
                    opacity: 1
                } : {
                    opacity: 0,
                    y: 4
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                exit: reducedMotion ? {
                    opacity: 1
                } : {
                    opacity: 0,
                    y: 2
                },
                transition: {
                    duration: 0.15,
                    ease: 'easeOut'
                },
                role: "listbox",
                "aria-label": "Chat models",
                className: "max-h-64 overflow-y-auto p-1",
                children: models.map((model)=>{
                    const selected = model.id === currentId;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            role: "option",
                            "aria-selected": selected,
                            onClick: ()=>{
                                onSelect(model.id);
                                setOpen(false);
                            },
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex w-full cursor-pointer items-start gap-2 rounded-xl px-2.5 py-2 text-left transition-colors hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700', selected && 'bg-slate-50'),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "min-w-0 flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "truncate text-xs font-semibold text-slate-800",
                                                    children: model.label
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                    tone: model.tier === 'paid' ? 'teal' : 'default',
                                                    size: "xs",
                                                    children: model.tier
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                            lineNumber: 95,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "block truncate text-[11px] text-slate-400",
                                            children: [
                                                model.price,
                                                " · ",
                                                model.name
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                            lineNumber: 106,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                    lineNumber: 94,
                                    columnNumber: 21
                                }, this),
                                selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "mt-0.5 size-3.5 shrink-0 text-teal-700",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                                    lineNumber: 111,
                                    columnNumber: 23
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                            lineNumber: 81,
                            columnNumber: 19
                        }, this)
                    }, model.id, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                        lineNumber: 80,
                        columnNumber: 17
                    }, this);
                })
            }, "model-list", false, {
                fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
                lineNumber: 67,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
            lineNumber: 65,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/elements/model-selector.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(ModelSelector, "FMYG4bqp7xP6yv2DuDSvuLfVD6Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
});
_c = ModelSelector;
var _c;
__turbopack_context__.k.register(_c, "ModelSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatorAttachmentCanvas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/map-pin.mjs [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function newMarkerId() {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
        return crypto.randomUUID();
    }
    return `pin-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function MatorAttachmentCanvas({ attachmentId, imageSrc, markers, onMarkersChange, draftText = '', interactive = true, className = '' }) {
    _s();
    const reduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const labelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const frameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [selectedId, setSelectedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [broken, setBroken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const placePin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "MatorAttachmentCanvas.useCallback[placePin]": (clientX, clientY)=>{
            if (!interactive || !onMarkersChange || !frameRef.current) return;
            const rect = frameRef.current.getBoundingClientRect();
            if (rect.width <= 0 || rect.height <= 0) return;
            const x = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
            const y = Math.min(1, Math.max(0, (clientY - rect.top) / rect.height));
            const text = draftText.trim() || (("TURBOPACK compile-time truthy", 1) ? window.prompt('Marker note', '')?.trim() || '' : "TURBOPACK unreachable");
            if (!text) return;
            const next = {
                id: newMarkerId(),
                x,
                y,
                text
            };
            onMarkersChange([
                ...markers,
                next
            ]);
            setSelectedId(next.id);
        }
    }["MatorAttachmentCanvas.useCallback[placePin]"], [
        draftText,
        interactive,
        markers,
        onMarkersChange
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "mator-attachment-canvas",
        "data-attachment-id": attachmentId,
        className: `overflow-hidden rounded-xl border border-teal-200/80 bg-slate-950/5 ${className}`,
        "aria-labelledby": labelId,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                id: labelId,
                className: "sr-only",
                children: "Attachment canvas with image markers"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: frameRef,
                role: interactive ? 'application' : 'img',
                "aria-label": interactive ? 'Click to place a marker on this image' : 'Attachment with markers',
                className: `relative aspect-[4/3] w-full overflow-hidden bg-gradient-to-br from-slate-100 via-teal-50 to-slate-200 ${interactive ? 'cursor-crosshair' : ''}`,
                onClick: (event)=>{
                    if (event.target.closest('[data-marker-pin]')) return;
                    placePin(event.clientX, event.clientY);
                },
                children: [
                    imageSrc && !broken ? // eslint-disable-next-line @next/next/no-img-element -- attachment blobs / API URLs
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: imageSrc,
                        alt: "Conversation attachment",
                        className: "pointer-events-none absolute inset-0 size-full object-contain",
                        onError: ()=>setBroken(true)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 flex flex-col items-center justify-center gap-2 px-4 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                className: "size-6 text-teal-700/70",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-slate-600",
                                children: broken ? 'Image unavailable' : 'Attachment ready for markers'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                lineNumber: 105,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[11px] text-slate-500",
                                children: [
                                    "Click to pin a note",
                                    draftText.trim() ? ' from your voice draft' : ''
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this),
                    markers.map((marker, index)=>{
                        const active = selectedId === marker.id;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                            type: "button",
                            "data-marker-pin": true,
                            initial: reduceMotion ? false : {
                                scale: 0.6,
                                opacity: 0
                            },
                            animate: {
                                scale: 1,
                                opacity: 1
                            },
                            transition: reduceMotion ? {
                                duration: 0
                            } : {
                                duration: 0.2,
                                ease: 'easeOut'
                            },
                            style: {
                                left: `${marker.x * 100}%`,
                                top: `${marker.y * 100}%`
                            },
                            className: `absolute z-10 flex max-w-[55%] -translate-x-1/2 -translate-y-full flex-col items-center gap-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 ${active ? 'z-20' : ''}`,
                            onClick: (event)=>{
                                event.stopPropagation();
                                setSelectedId(marker.id);
                            },
                            "aria-label": `Marker ${index + 1}: ${marker.text}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `rounded-md px-2 py-1 text-left text-[10px] leading-snug font-semibold shadow-sm ${active ? 'bg-teal-800 text-white' : 'bg-white/95 text-teal-950 ring-1 ring-teal-200'}`,
                                    children: marker.text
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "inline-flex size-6 items-center justify-center rounded-full bg-teal-700 text-[10px] font-bold text-white shadow ring-2 ring-white",
                                    children: index + 1
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                    lineNumber: 151,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, marker.id, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                            lineNumber: 118,
                            columnNumber: 13
                        }, this);
                    })
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            markers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-1 border-t border-teal-100 bg-teal-50/50 px-3 py-2",
                children: markers.map((marker, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "text-[11px] text-slate-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-teal-900",
                                children: [
                                    index + 1,
                                    "."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                                lineNumber: 162,
                                columnNumber: 15
                            }, this),
                            ' ',
                            marker.text
                        ]
                    }, marker.id, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                        lineNumber: 161,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
                lineNumber: 159,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
}
_s(MatorAttachmentCanvas, "oHsLENIUeyuXGahzV1hV9pizbRE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = MatorAttachmentCanvas;
var _c;
__turbopack_context__.k.register(_c, "MatorAttachmentCanvas");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-attachment-preview.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatorAttachmentPreview
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/file-text.mjs [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$canvas$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-attachment-canvas.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function MatorAttachmentPreview({ attachmentId, imageSrc, filename = 'Image', mime = 'image/png', markers, interactive = true, reviewId, onAnnotateFull, onMarkersChange }) {
    _s();
    const [broken, setBroken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quickOpen, setQuickOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [draftMarkers, setDraftMarkers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [draftNote, setDraftNote] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saveError, setSaveError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isImage = mime.startsWith('image/');
    const canPlaceMarkers = interactive && Boolean(onMarkersChange);
    function openAnnotation() {
        if (onAnnotateFull) {
            void onAnnotateFull();
            return;
        }
        if (!canPlaceMarkers) return;
        setDraftMarkers(markers.map((marker)=>({
                ...marker
            })));
        setDraftNote('');
        setSaveError('');
        setQuickOpen(true);
    }
    function dismissQuickAnnotation() {
        if (saving) return;
        setQuickOpen(false);
        triggerRef.current?.focus();
    }
    function addCenterNote() {
        if (!draftNote.trim()) return;
        const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `pin-${Date.now().toString(36)}`;
        setDraftMarkers((current)=>[
                ...current,
                {
                    id,
                    x: 0.5,
                    y: 0.5,
                    text: draftNote.trim()
                }
            ]);
        setDraftNote('');
    }
    async function saveQuickAnnotation() {
        if (!onMarkersChange) return;
        setSaving(true);
        setSaveError('');
        try {
            await onMarkersChange(draftMarkers);
            setQuickOpen(false);
            triggerRef.current?.focus();
        } catch (error) {
            setSaveError(error instanceof Error ? error.message : 'Could not save image annotations');
        } finally{
            setSaving(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            isImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "relative inline-flex size-20 shrink-0 sm:size-24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            ref: triggerRef,
                            type: "button",
                            title: filename,
                            "aria-label": `Annotate image ${filename}`,
                            "data-testid": "mator-image-thumbnail",
                            disabled: !onAnnotateFull && !canPlaceMarkers,
                            onClick: openAnnotation,
                            className: "flex size-20 items-center justify-center overflow-hidden rounded-lg border border-slate-200 bg-slate-50 cursor-pencil focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 sm:size-24",
                            children: [
                                imageSrc && !broken ? // eslint-disable-next-line @next/next/no-img-element -- local blob or authorized attachment route
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: imageSrc,
                                    alt: "",
                                    className: "size-full object-cover",
                                    onError: ()=>setBroken(true)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 111,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                    className: "size-5 text-slate-500",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 118,
                                    columnNumber: 17
                                }, this),
                                markers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute right-1 bottom-1 rounded bg-slate-950/80 px-1 text-[10px] text-white",
                                    children: [
                                        markers.length,
                                        " notes"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 124,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 99,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                        lineNumber: 98,
                        columnNumber: 11
                    }, this),
                    reviewId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        "data-testid": "mator-annotation-yaml-link",
                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`visual-reviews/${reviewId}/yaml`),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "mx-auto block max-w-[6rem] truncate text-[10px] font-semibold text-teal-700 underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                        children: [
                            markers.length > 0 ? `${markers.length} notes · ` : '',
                            "YAML"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                        lineNumber: 131,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                title: filename,
                "aria-label": filename,
                className: "flex size-20 shrink-0 flex-col items-center justify-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-1 sm:size-24",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                        className: "size-5 text-slate-500",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "w-full truncate text-center text-[10px] text-slate-600",
                        children: filename
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                        lineNumber: 149,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                lineNumber: 143,
                columnNumber: 9
            }, this),
            isImage && canPlaceMarkers && !onAnnotateFull && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: quickOpen,
                onDismiss: dismissQuickAnnotation,
                title: "Annotate image",
                description: filename,
                testId: "mator-image-annotation-modal",
                size: "wide",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-3xl space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$canvas$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            attachmentId: attachmentId,
                            imageSrc: imageSrc,
                            markers: draftMarkers,
                            draftText: draftNote,
                            onMarkersChange: setDraftMarkers,
                            interactive: true,
                            className: "w-full"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 164,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: `mator-image-note-${attachmentId}`,
                            className: "block text-xs font-semibold text-slate-700",
                            children: "Annotation comment"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 173,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2 sm:flex-row",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    id: `mator-image-note-${attachmentId}`,
                                    value: draftNote,
                                    onChange: (event)=>setDraftNote(event.target.value),
                                    placeholder: "Describe what should change",
                                    className: "min-h-11 min-w-0 flex-1 rounded-lg border border-slate-200 px-3 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 180,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: addCenterNote,
                                    disabled: !draftNote.trim(),
                                    className: "inline-flex min-h-11 items-center gap-2 rounded-lg border border-slate-200 px-3 text-xs font-semibold text-teal-800 disabled:opacity-40",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                            className: "size-4",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                            lineNumber: 193,
                                            columnNumber: 17
                                        }, this),
                                        " Add comment at center"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 187,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 179,
                            columnNumber: 13
                        }, this),
                        saveError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "text-xs text-rose-700",
                            children: saveError
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 198,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-end gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: dismissQuickAnnotation,
                                    disabled: saving,
                                    className: "min-h-11 rounded-lg border border-slate-200 px-4 text-sm",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 203,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "data-testid": "mator-annotation-save",
                                    onClick: ()=>void saveQuickAnnotation(),
                                    disabled: saving,
                                    className: "min-h-11 rounded-lg bg-teal-800 px-4 text-sm font-semibold text-white disabled:opacity-50",
                                    children: saving ? 'Saving…' : 'Save annotations'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                                    lineNumber: 211,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                            lineNumber: 202,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-attachment-preview.tsx",
                lineNumber: 155,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(MatorAttachmentPreview, "MIyu5PishkK91Xth3eH89hjqr6A=");
_c = MatorAttachmentPreview;
var _c;
__turbopack_context__.k.register(_c, "MatorAttachmentPreview");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-chat-settings.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatorChatSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/settings.mjs [app-client] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$slider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/slider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/switch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$model$2d$selector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/model-selector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const EFFORT_STOPS = [
    'low',
    'medium',
    'high'
];
const EFFORT_LABELS = [
    'Low',
    'Medium',
    'High'
];
function MatorChatSettings({ disabled, onSettingsSaved }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const toast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "MatorChatSettings.useCallback[load]": async ()=>{
            setLoading(true);
            setError('');
            try {
                const [loadedSettings, loadedModels] = await Promise.all([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorSettings"])(),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorModels"])()
                ]);
                setSettings(loadedSettings);
                setModels(loadedModels.models.filter({
                    "MatorChatSettings.useCallback[load]": (model)=>model.role === 'chat'
                }["MatorChatSettings.useCallback[load]"]));
            } catch (cause) {
                setError(cause instanceof Error ? cause.message : 'Unable to load chat settings');
            } finally{
                setLoading(false);
            }
        }
    }["MatorChatSettings.useCallback[load]"], []);
    const patch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "MatorChatSettings.useCallback[patch]": async (change)=>{
            setSaving(true);
            try {
                const saved = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveMatorSettings"])(change);
                setSettings(saved);
                onSettingsSaved?.(saved);
                toast('Chat settings saved', 'success');
            } catch (cause) {
                toast(cause instanceof Error ? cause.message : 'Unable to save chat settings', 'error');
            } finally{
                setSaving(false);
            }
        }
    }["MatorChatSettings.useCallback[patch]"], [
        toast,
        onSettingsSaved
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MatorChatSettings.useEffect": ()=>{
            if (open) void load();
        }
    }["MatorChatSettings.useEffect"], [
        open,
        load
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
        open: open,
        onOpenChange: setOpen,
        side: "top",
        align: "end",
        "aria-label": "Chat settings",
        contentClassName: "w-[min(19rem,calc(100vw-2rem))]",
        trigger: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            "aria-haspopup": "dialog",
            "aria-expanded": open,
            "aria-label": "Chat settings",
            "data-testid": "mator-settings-trigger",
            disabled: disabled,
            onClick: ()=>setOpen((value)=>!value),
            className: "block cursor-pointer rounded-full text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "inline-flex size-11 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                    className: "size-4",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                    lineNumber: 110,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                lineNumber: 109,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
            lineNumber: 99,
            columnNumber: 9
        }, this),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-3 px-1.5 py-1",
            children: [
                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-3",
                    "aria-busy": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            className: "h-4 w-28"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 118,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            className: "h-10 w-full"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 119,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            className: "h-6 w-full"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 120,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                    lineNumber: 117,
                    columnNumber: 11
                }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    role: "alert",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-rose-700",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 124,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>void load(),
                            className: "min-h-10 rounded-xl border border-slate-200 px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                            children: "Retry loading settings"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                    lineNumber: 123,
                    columnNumber: 11
                }, this) : settings ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] font-semibold tracking-wider text-slate-500 uppercase",
                                    children: "Chat model"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 136,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-1.5",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$model$2d$selector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModelSelector"], {
                                        models: models,
                                        currentId: settings.modelId,
                                        onSelect: (modelId)=>void patch({
                                                modelId
                                            }),
                                        disabled: saving
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                        lineNumber: 140,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 139,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 135,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[11px] font-semibold tracking-wider text-slate-500 uppercase",
                                            children: "Reasoning effort"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                            lineNumber: 150,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                            tone: "outline",
                                            size: "xs",
                                            children: settings.reasoningEffort
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                            lineNumber: 153,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 149,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$slider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slider"], {
                                        value: EFFORT_STOPS.indexOf(settings.reasoningEffort),
                                        min: 0,
                                        max: 2,
                                        step: 1,
                                        stops: EFFORT_LABELS,
                                        disabled: saving,
                                        "aria-label": "Reasoning effort",
                                        "aria-valuetext": settings.reasoningEffort,
                                        onValueChange: (value)=>void patch({
                                                reasoningEffort: EFFORT_STOPS[value] ?? 'medium'
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                        lineNumber: 158,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 157,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 148,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col divide-y divide-slate-100",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SettingsRow, {
                                    label: "Auto-approve staged changes",
                                    hint: "Skips the confirmation step when the backend allows it.",
                                    checked: settings.autoApprove,
                                    saving: saving,
                                    onToggle: (autoApprove)=>void patch({
                                            autoApprove
                                        })
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 176,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SettingsRow, {
                                    label: "Speak replies and workflow updates",
                                    hint: "In voice mode, reads new Mator replies and verified run status changes aloud.",
                                    checked: settings.howTtsEnabled,
                                    saving: saving,
                                    onToggle: (howTtsEnabled)=>void patch({
                                            howTtsEnabled
                                        })
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SettingsRow, {
                                    label: "Moderation check",
                                    hint: "Mator re-checks a step before it can be staged.",
                                    checked: settings.moderationEnabled,
                                    saving: saving,
                                    onToggle: (moderationEnabled)=>void patch({
                                            moderationEnabled
                                        })
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                                    lineNumber: 190,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                            lineNumber: 175,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true) : null,
                saving && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                    className: "size-3 animate-spin self-end text-teal-700",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                    lineNumber: 203,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
            lineNumber: 115,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
        lineNumber: 91,
        columnNumber: 5
    }, this);
}
_s(MatorChatSettings, "4JKhJNi4iLDUK7v9QzEWI0GaV18=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = MatorChatSettings;
function SettingsRow({ label, hint, checked, saving, onToggle }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: "flex cursor-pointer items-start justify-between gap-3 py-2.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "block truncate text-xs font-semibold text-slate-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                        lineNumber: 229,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "block text-[10px] leading-4 text-slate-400",
                        children: hint
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                        lineNumber: 232,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                lineNumber: 228,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Switch"], {
                checked: checked,
                disabled: saving,
                onCheckedChange: onToggle,
                "aria-label": label
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-chat-settings.tsx",
        lineNumber: 227,
        columnNumber: 5
    }, this);
}
_c1 = SettingsRow;
var _c, _c1;
__turbopack_context__.k.register(_c, "MatorChatSettings");
__turbopack_context__.k.register(_c1, "SettingsRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-voice-listener.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MatorCallControls",
    ()=>MatorCallControls,
    "default",
    ()=>MatorVoiceListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/mic.mjs [app-client] (ecmascript) <export default as Mic>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MicOff$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/mic-off.mjs [app-client] (ecmascript) <export default as MicOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/pause.mjs [app-client] (ecmascript) <export default as Pause>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/phone.mjs [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneOff$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/phone-off.mjs [app-client] (ecmascript) <export default as PhoneOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/play.mjs [app-client] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VolumeX$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/volume-x.mjs [app-client] (ecmascript) <export default as VolumeX>");
'use client';
;
;
const PHASE_LABELS = {
    idle: 'Start a conversation with Mator',
    ended: 'Call ended',
    connecting: 'Connecting to Mator…',
    listening: 'Listening…',
    transcribing: 'Understanding your words…',
    thinking: 'Mator is thinking…',
    speaking: 'Mator is speaking',
    'clarifying-voice': 'Answer the visible question aloud',
    'clarifying-form': 'Complete the question on screen',
    'awaiting-approval': 'Approve or reject the change on screen',
    paused: 'Call paused',
    'needs-attention': 'Needs your attention in chat',
    'error-paused': 'Call paused after an error'
};
function fmt(seconds) {
    const minutes = Math.floor(seconds / 60);
    return `${String(minutes).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}
function MatorCallControls({ call }) {
    const { state } = call;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex shrink-0 items-center gap-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-call-mic-mute",
                "aria-label": state.micMuted ? 'Unmute microphone' : 'Mute microphone',
                "aria-pressed": state.micMuted,
                onClick: ()=>call.muteMic(!state.micMuted),
                className: "flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-full border border-slate-200 bg-white/80 text-slate-800 backdrop-blur-sm transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                children: state.micMuted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MicOff$3e$__["MicOff"], {
                    className: "size-4 text-rose-700",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 56,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__["Mic"], {
                    className: "size-4",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 58,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-call-end",
                "aria-label": "End Mator call",
                onClick: call.end,
                className: "flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-full bg-rose-700 text-white shadow-[0_8px_20px_-8px_rgba(159,18,57,.7)] transition-colors hover:bg-rose-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-700",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneOff$3e$__["PhoneOff"], {
                    className: "size-4",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_c = MatorCallControls;
const BAR_COUNT = 19;
/** Level bars driven by the real WebAudio RMS meter from the call session. */ function VoiceBars({ call }) {
    const { phase } = call.state;
    const voiceLevel = call.voiceLevel;
    const listening = phase === 'listening';
    const speaking = phase === 'speaking';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "img",
        "data-testid": "mator-call-level",
        "aria-label": listening ? 'Microphone level indicator' : speaking ? 'Mator response audio' : 'No live audio',
        className: "flex h-8 items-center justify-center gap-[3px]",
        children: Array.from({
            length: BAR_COUNT
        }, (_, i)=>{
            const shape = 0.55 + (i % 5 + 1) * 0.2;
            const height = listening ? 5 + 12 * voiceLevel : speaking ? 9 : 3;
            const tone = listening ? 'bg-teal-300' : speaking ? 'bg-cyan-200/90' : 'bg-white/25';
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `w-1 shrink-0 rounded-full ${tone} ${speaking ? 'mator-bar-idle' : ''}`,
                style: {
                    height,
                    transform: listening ? `scaleY(${0.55 + shape * voiceLevel * 1.2})` : undefined,
                    animationDelay: speaking ? `${i * 65}ms` : undefined
                }
            }, i, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 104,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
}
_c1 = VoiceBars;
function MatorVoiceListener({ call, ready }) {
    const { state, active } = call;
    const resumeAllowed = [
        'paused',
        'needs-attention',
        'error-paused'
    ].includes(state.phase);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-testid": "mator-ai-call-panel",
        "aria-label": "Mator AI call audio",
        className: "relative isolate mt-1 flex flex-col items-center gap-2.5 overflow-hidden pt-7 pb-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "aria-hidden": "true",
                className: "mator-galaxy pointer-events-none absolute inset-x-0 -top-16 bottom-0 -z-10"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                "aria-label": `Call duration ${fmt(call.seconds)}`,
                className: "z-10 rounded-full bg-white/10 px-2.5 py-0.5 text-[10px] font-semibold text-teal-50/90 tabular-nums",
                children: fmt(call.seconds)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 141,
                columnNumber: 9
            }, this),
            !active ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-call-start",
                onClick: call.start,
                disabled: !ready,
                "aria-label": ready ? 'Start the Mator call' : 'Select a workflow conversation before calling',
                className: "group relative flex size-20 shrink-0 cursor-pointer items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-300 disabled:cursor-not-allowed disabled:opacity-60",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "absolute -inset-3 -z-10 rounded-full bg-[radial-gradient(closest-side,rgba(45,212,191,.35),transparent)] blur-md"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 163,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "absolute inset-0 rounded-full bg-gradient-to-br from-teal-400/80 via-teal-700/90 to-slate-950 shadow-[0_0_36px_-8px_rgba(45,212,191,.8)] ring-1 ring-teal-300/50 transition-transform group-hover:scale-[1.04] motion-reduce:transition-none"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 167,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                        className: "relative size-6 text-white transition-transform group-hover:-rotate-6 motion-reduce:transition-none",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 151,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-call-pause",
                onClick: resumeAllowed ? call.resume : call.pause,
                "aria-label": resumeAllowed ? 'Resume call' : 'Pause call',
                className: "group relative flex size-20 shrink-0 cursor-pointer items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-300",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "absolute -inset-3 -z-10 rounded-full bg-[radial-gradient(closest-side,rgba(45,212,191,.35),transparent)] blur-md"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 184,
                        columnNumber: 11
                    }, this),
                    state.phase === 'listening' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "aria-hidden": "true",
                                className: "mator-listen-ring pointer-events-none absolute inset-0 rounded-full border-2 border-teal-300/70"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                                lineNumber: 190,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "aria-hidden": "true",
                                className: "mator-listen-ring pointer-events-none absolute inset-0 rounded-full border border-teal-200/50",
                                style: {
                                    animationDelay: '600ms'
                                }
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                                lineNumber: 194,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "absolute inset-0 rounded-full bg-gradient-to-br from-teal-400/80 via-teal-700/90 to-slate-950 shadow-[0_0_36px_-8px_rgba(45,212,191,.8)] ring-1 ring-teal-300/50 transition-transform group-hover:scale-[1.04] motion-reduce:transition-none"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 201,
                        columnNumber: 11
                    }, this),
                    resumeAllowed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                        className: "relative size-6 text-white",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 206,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__["Pause"], {
                        className: "relative size-5 text-white",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                        lineNumber: 208,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 177,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(VoiceBars, {
                call: call
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 213,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "z-10 flex items-center gap-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    "data-testid": "mator-call-status",
                    "aria-live": "polite",
                    className: "text-center text-[11px] font-medium text-white/85",
                    children: PHASE_LABELS[state.phase]
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 215,
                columnNumber: 7
            }, this),
            state.detail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "z-10 max-w-72 text-center text-[11px] leading-relaxed text-rose-300",
                children: state.detail
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 226,
                columnNumber: 9
            }, this),
            !active && !ready && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "z-10 text-center text-[11px] text-white/70",
                children: "Select a workflow conversation to start the call."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 235,
                columnNumber: 9
            }, this),
            active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-call-speaker-mute",
                "aria-label": state.speakerMuted ? 'Enable speaker' : 'Silence speaker',
                "aria-pressed": state.speakerMuted,
                onClick: ()=>call.muteSpeaker(!state.speakerMuted),
                className: "z-10 inline-flex size-8 cursor-pointer items-center justify-center rounded-full bg-white/10 text-teal-100 transition-colors hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-300",
                children: state.speakerMuted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VolumeX$3e$__["VolumeX"], {
                    className: "size-3.5",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 250,
                    columnNumber: 13
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                    className: "size-3.5",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                    lineNumber: 252,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
                lineNumber: 241,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-voice-listener.tsx",
        lineNumber: 129,
        columnNumber: 5
    }, this);
}
_c2 = MatorVoiceListener;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "MatorCallControls");
__turbopack_context__.k.register(_c1, "VoiceBars");
__turbopack_context__.k.register(_c2, "MatorVoiceListener");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-voice-preference.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setVoiceOnlyPreference",
    ()=>setVoiceOnlyPreference,
    "useVoiceOnlyPreference",
    ()=>useVoiceOnlyPreference
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const STORAGE_KEY = 'mator.voiceOnly';
const CHANGE_EVENT = 'mator-voice-only-change';
let fallbackVoiceOnly = false;
function readVoiceOnly() {
    try {
        return window.localStorage.getItem(STORAGE_KEY) === '1';
    } catch  {
        return fallbackVoiceOnly;
    }
}
function subscribeVoiceOnly(onChange) {
    window.addEventListener(CHANGE_EVENT, onChange);
    window.addEventListener('storage', onChange);
    return ()=>{
        window.removeEventListener(CHANGE_EVENT, onChange);
        window.removeEventListener('storage', onChange);
    };
}
function setVoiceOnlyPreference(voiceOnly) {
    fallbackVoiceOnly = voiceOnly;
    try {
        window.localStorage.setItem(STORAGE_KEY, voiceOnly ? '1' : '0');
    } catch  {
    // Keep the interface usable when the browser blocks local storage.
    }
    window.dispatchEvent(new Event(CHANGE_EVENT));
}
function useVoiceOnlyPreference() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeVoiceOnly, readVoiceOnly, {
        "useVoiceOnlyPreference.useSyncExternalStore": ()=>false
    }["useVoiceOnlyPreference.useSyncExternalStore"]);
}
_s(useVoiceOnlyPreference, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-composer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ATTACH_ACCEPT",
    ()=>ATTACH_ACCEPT,
    "VoiceMicButton",
    ()=>VoiceMicButton,
    "default",
    ()=>MatorComposer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-right.mjs [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUp$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-up.mjs [app-client] (ecmascript) <export default as ArrowUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/mic.mjs [app-client] (ecmascript) <export default as Mic>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paperclip$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/paperclip.mjs [app-client] (ecmascript) <export default as Paperclip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/phone.mjs [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/square.mjs [app-client] (ecmascript) <export default as Square>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/switch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-composer-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$model$2d$selector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/model-selector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$preview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-attachment-preview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$settings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-chat-settings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$listener$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-voice-listener.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-voice-preference.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const ATTACH_ACCEPT = 'image/*,.txt,.md,.markdown,.readme,README';
function VoiceMicButton({ listening, disabled, onClick, label = 'Speak to Mator', size = 'lg' }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        "data-testid": size === 'lg' ? 'mator-mic' : 'annotation-mic',
        "aria-label": listening ? 'Stop listening' : label,
        "aria-pressed": listening,
        disabled: disabled,
        onClick: onClick,
        className: `relative inline-flex ${size === 'lg' ? 'size-14' : 'size-12'} cursor-pointer items-center justify-center rounded-full bg-teal-800 text-white shadow-sm hover:bg-teal-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 motion-reduce:transform-none`,
        children: [
            listening && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mator-listen-ring pointer-events-none absolute inset-0 rounded-full border-2 border-teal-600",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 97,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__["Mic"], {
                className: size === 'lg' ? 'size-5' : 'size-5',
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
_c = VoiceMicButton;
function MatorComposer({ voice, call, callReady, operatorPendingLabel = null, onConfirmOperator, message, onMessageChange, onSendMessage, onUploadFile, onSendText, onSaveMarkers, onAnnotateDraft, onPendingAssetsChange, busy = false, incomplete = false, onIncompleteContinue, models = [], modelId = null, onModelChange, onSettingsSaved, emptyThread = false, startPrompt = null }) {
    _s();
    const [pending, setPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [draftError, setDraftError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [annotateError, setAnnotateError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const previewUrls = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    const nextAttachmentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const formRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const textareaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const voiceOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceOnlyPreference"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MatorComposer.useEffect": ()=>{
            const textarea = textareaRef.current;
            if (!textarea || voiceOnly) return;
            textarea.style.height = 'auto';
            textarea.style.height = `${Math.min(textarea.scrollHeight, 116)}px`;
        }
    }["MatorComposer.useEffect"], [
        voiceOnly
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MatorComposer.useEffect": ()=>{
            onPendingAssetsChange?.(pending.length);
        }
    }["MatorComposer.useEffect"], [
        pending.length,
        onPendingAssetsChange
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MatorComposer.useEffect": ()=>({
                "MatorComposer.useEffect": ()=>{
                    for (const url of previewUrls.current)URL.revokeObjectURL(url);
                    previewUrls.current.clear();
                }
            })["MatorComposer.useEffect"]
    }["MatorComposer.useEffect"], []);
    const attach = (files)=>{
        if (!files?.length) return;
        const selected = Array.from(files);
        const accepted = selected.filter(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supportedFile"]);
        // The backend accepts at most 12 attachment IDs per message. Reject the
        // selection before allocating previews or uploading any of its files.
        if (pending.length + accepted.length > 12) {
            setDraftError('You can attach up to 12 files to one message.');
            return;
        }
        if (accepted.length !== selected.length) {
            setDraftError('Supported assets are raster images, TXT and README files.');
        } else {
            setDraftError('');
        }
        const rows = accepted.map((file)=>{
            const imageSrc = file.type.startsWith('image/') ? URL.createObjectURL(file) : null;
            if (imageSrc) previewUrls.current.add(imageSrc);
            return {
                id: nextAttachmentId.current++,
                file,
                name: file.name,
                size: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fileSizeLabel"])(file.size),
                imageSrc,
                markers: [],
                state: 'ready'
            };
        });
        setPending((current)=>[
                ...current,
                ...rows
            ]);
        inputRef.current?.blur();
    };
    const removeDraft = (id)=>{
        setPending((current)=>{
            const removed = current.find((asset)=>asset.id === id);
            if (removed?.imageSrc) {
                URL.revokeObjectURL(removed.imageSrc);
                previewUrls.current.delete(removed.imageSrc);
            }
            return current.filter((asset)=>asset.id !== id);
        });
    };
    const sendDraft = async ()=>{
        if (submitting || busy || !pending.length || !onUploadFile || !onSendText) return;
        setSubmitting(true);
        setDraftError('');
        try {
            const ids = [];
            for (const asset of pending){
                let id = asset.uploadedId;
                if (!id) {
                    setPending((current)=>current.map((row)=>row.id === asset.id ? {
                                ...row,
                                state: 'uploading'
                            } : row));
                    id = await onUploadFile(asset.file);
                    if (!id) throw Error(`Could not upload ${asset.name}`);
                    asset.uploadedId = id;
                    setPending((current)=>current.map((row)=>row.id === asset.id ? {
                                ...row,
                                uploadedId: id,
                                state: 'ready'
                            } : row));
                }
                if ((asset.markers.length || asset.reviewId) && onSaveMarkers) {
                    await onSaveMarkers(id, asset.markers, asset.reviewId);
                }
                ids.push(id);
            }
            const sent = await onSendText(message.trim(), ids);
            if (sent === false) throw Error('Could not send assets. Your draft is preserved.');
            setPending([]);
            setAnnotateError('');
            for (const asset of pending){
                if (asset.imageSrc) {
                    URL.revokeObjectURL(asset.imageSrc);
                    previewUrls.current.delete(asset.imageSrc);
                }
            }
            onMessageChange('');
        } catch (cause) {
            setPending((current)=>current.map((row)=>row.state === 'uploading' ? {
                        ...row,
                        state: 'error'
                    } : row));
            setDraftError(cause instanceof Error ? cause.message : 'Could not send assets');
        } finally{
            setSubmitting(false);
        }
    };
    const annotateDraftRow = async (asset)=>{
        if (!onAnnotateDraft) return;
        setAnnotateError('');
        try {
            const result = await onAnnotateDraft(asset.file, message.trim().slice(0, 1500) || undefined);
            if (result?.reviewId) {
                setPending((current)=>current.map((row)=>row.id === asset.id ? {
                            ...row,
                            reviewId: result.reviewId
                        } : row));
            }
        } catch (cause) {
            setAnnotateError(cause instanceof Error ? cause.message : 'Could not open the annotation studio');
        }
    };
    const gallery = pending.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-w-0 px-1.5 py-1.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "mator-pending-gallery",
                className: "grid max-h-44 grid-cols-3 gap-1.5 overflow-y-auto sm:grid-cols-4",
                role: "list",
                "aria-label": "Assets ready to send",
                children: pending.map((asset)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "listitem",
                        className: "relative w-fit",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$preview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                attachmentId: asset.uploadedId ?? `draft-${asset.id}`,
                                filename: asset.name,
                                mime: asset.file.type || (asset.imageSrc ? 'image/png' : 'text/plain'),
                                imageSrc: asset.imageSrc,
                                markers: asset.markers,
                                reviewId: asset.reviewId,
                                onMarkersChange: (markers)=>{
                                    setPending((current)=>current.map((row)=>row.id === asset.id ? {
                                                ...row,
                                                markers
                                            } : row));
                                },
                                onAnnotateFull: onAnnotateDraft && asset.file.type.startsWith('image/') ? ()=>annotateDraftRow(asset) : undefined
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 313,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                "aria-label": `Remove ${asset.name}`,
                                onClick: ()=>removeDraft(asset.id),
                                className: "absolute -top-1 -right-1 flex size-6 items-center justify-center rounded-full bg-slate-800 text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "size-3",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 341,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 335,
                                columnNumber: 13
                            }, this),
                            asset.state !== 'ready' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "block text-[10px] text-slate-600",
                                children: asset.state
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 344,
                                columnNumber: 15
                            }, this)
                        ]
                    }, asset.id, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 312,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 305,
                columnNumber: 7
            }, this),
            annotateError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                "data-testid": "mator-annotate-error",
                className: "px-1 pt-1 text-xs text-rose-700",
                children: annotateError
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 352,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
        lineNumber: 304,
        columnNumber: 5
    }, this) : null;
    /* ── AI Call: transparent galaxy listener dock replaces the text composer
     and the old card; the header owns mute + end call during the call. ── */ if (voiceOnly) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-testid": "mator-composer",
            "data-mode": "voice-only",
            className: "shrink-0 px-2 pt-1 pb-1",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-w-0 flex-nowrap items-center justify-between gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "inline-flex min-w-0 shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-semibold text-teal-800",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                    className: "size-3.5",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 374,
                                    columnNumber: 13
                                }, this),
                                "Mator AI Call"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                            lineNumber: 373,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-flex min-w-0 shrink-0 flex-nowrap items-center gap-0.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "aria-label": "Attach a file during AI call",
                                    "data-testid": "mator-voice-attach",
                                    disabled: call.active,
                                    onClick: ()=>inputRef.current?.click(),
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButton"])('default'),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paperclip$3e$__["Paperclip"], {
                                        className: "size-4",
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 386,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 378,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ref: inputRef,
                                    type: "file",
                                    multiple: true,
                                    accept: ATTACH_ACCEPT,
                                    className: "sr-only",
                                    "aria-hidden": "true",
                                    tabIndex: -1,
                                    onChange: (event)=>{
                                        attach(event.target.files);
                                        event.target.value = '';
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 388,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$settings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    disabled: busy || call.active,
                                    onSettingsSaved: onSettingsSaved
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 401,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "inline-flex size-11 shrink-0 items-center justify-center",
                                    title: "Switch to text conversation",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Switch"], {
                                        checked: voiceOnly,
                                        onCheckedChange: (checked)=>{
                                            if (!checked) call.end();
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setVoiceOnlyPreference"])(checked);
                                        },
                                        "aria-label": "Mator AI Call mode",
                                        "data-testid": "mator-voice-switch"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 409,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 405,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                            lineNumber: 377,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 372,
                    columnNumber: 9
                }, this),
                gallery,
                pending.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 flex items-end gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: message,
                            onChange: (event)=>onMessageChange(event.target.value),
                            "aria-label": "Caption for assets",
                            placeholder: "Add a caption or prompt…",
                            className: "min-h-11 min-w-0 flex-1 rounded-xl border border-slate-200 px-3 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                            lineNumber: 424,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            "data-testid": "mator-send",
                            onClick: ()=>void sendDraft(),
                            disabled: submitting || busy || call.active,
                            className: "min-h-11 rounded-xl bg-teal-800 px-3 text-sm font-semibold text-white disabled:opacity-50",
                            children: "Send assets"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                            lineNumber: 432,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 423,
                    columnNumber: 11
                }, this),
                draftError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "text-xs text-rose-700",
                    children: draftError
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 444,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-1",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$listener$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        call: call,
                        ready: callReady && !busy
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 449,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 448,
                    columnNumber: 9
                }, this),
                operatorPendingLabel && onConfirmOperator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OperatorPendingApproval, {
                    label: operatorPendingLabel,
                    onConfirm: onConfirmOperator,
                    busy: busy
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 452,
                    columnNumber: 11
                }, this),
                incomplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IncompleteBanner, {
                    onContinue: onIncompleteContinue,
                    busy: busy
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 459,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
            lineNumber: 367,
            columnNumber: 7
        }, this);
    }
    /* ── Text-first deck ─────────────────────────────────────────── */ const canSend = Boolean(message.trim() || pending.length) && !busy && !submitting;
    const showSuggestions = emptyThread && Boolean(startPrompt);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "mator-composer",
        "data-mode": "text",
        className: "shrink-0 border-t border-slate-200 bg-white px-3 pt-2 pb-3",
        children: [
            incomplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IncompleteBanner, {
                onContinue: onIncompleteContinue,
                busy: busy
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 477,
                columnNumber: 9
            }, this),
            operatorPendingLabel && onConfirmOperator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OperatorPendingApproval, {
                label: operatorPendingLabel,
                onConfirm: onConfirmOperator,
                busy: busy
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 480,
                columnNumber: 9
            }, this),
            showSuggestions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-1.5 pt-1 pb-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    "data-testid": "mator-start-prompt",
                    onClick: ()=>onMessageChange(startPrompt),
                    className: "min-h-9 cursor-pointer rounded-full border border-slate-200 bg-white px-3 text-xs font-medium text-slate-600 transition-colors hover:border-teal-400 hover:bg-teal-50/60 hover:text-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                    children: [
                        startPrompt?.slice(0, 42),
                        startPrompt?.length > 42 ? '…' : ''
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                    lineNumber: 488,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 487,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                ref: formRef,
                onSubmit: (event)=>{
                    if (pending.length) {
                        event.preventDefault();
                        void sendDraft();
                    } else onSendMessage(event);
                },
                className: "flex min-w-0 flex-col gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0 rounded-2xl border border-slate-200 bg-white px-1.5 pt-1 pb-1.5 shadow-[inset_0_1px_2px_rgba(15,23,42,.03)] transition-colors focus-within:border-teal-600/70 focus-within:ring-2 focus-within:ring-teal-700/10",
                        children: [
                            gallery,
                            draftError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                role: "alert",
                                className: "px-2 text-xs text-rose-700",
                                children: draftError
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 512,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                ref: textareaRef,
                                value: message,
                                rows: 1,
                                id: "mator-composer-input",
                                "aria-label": "Message Mator",
                                "data-testid": "mator-input",
                                disabled: busy,
                                placeholder: "Message Mator…",
                                onChange: (event)=>onMessageChange(event.target.value),
                                onKeyDown: (event)=>{
                                    if (event.key === 'Enter' && !event.shiftKey) {
                                        event.preventDefault();
                                        if (canSend) formRef.current?.requestSubmit();
                                    }
                                },
                                className: "max-h-29 w-full resize-none bg-transparent px-2.5 py-2 text-sm leading-5 text-slate-900 placeholder:text-slate-400 focus-visible:outline-none disabled:opacity-60"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 516,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex min-w-0 flex-nowrap items-center gap-0.5 px-0.5 pb-0.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "aria-label": "Attach a file",
                                        "data-testid": "mator-attach",
                                        onClick: ()=>inputRef.current?.click(),
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButton"])('default'),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Paperclip$3e$__["Paperclip"], {
                                            className: "size-4",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                            lineNumber: 542,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 535,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        ref: inputRef,
                                        type: "file",
                                        accept: ATTACH_ACCEPT,
                                        multiple: true,
                                        className: "sr-only",
                                        "aria-hidden": "true",
                                        tabIndex: -1,
                                        onChange: (event)=>{
                                            attach(event.target.files);
                                            event.target.value = '';
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 544,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "aria-label": voice.listening ? 'Stop dictation' : 'Dictate into text draft',
                                        "aria-pressed": voice.listening,
                                        "data-testid": "mator-mic",
                                        disabled: voice.support === 'unsupported' || busy,
                                        onClick: voice.toggleListen,
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$composer$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["iconButton"])(voice.listening ? 'active' : 'default'),
                                        children: voice.listening ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square$3e$__["Square"], {
                                            className: "size-3.5",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                            lineNumber: 569,
                                            columnNumber: 17
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__["Mic"], {
                                            className: "size-4",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                            lineNumber: 571,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 557,
                                        columnNumber: 13
                                    }, this),
                                    voice.listening && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        "aria-live": "polite",
                                        className: "min-w-0 flex-1 truncate text-[11px] font-medium text-teal-800",
                                        children: voice.interim || 'Listening…'
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 575,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "ml-auto flex min-w-0 shrink-0 flex-nowrap items-center gap-0.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "inline-flex size-11 shrink-0 items-center justify-center",
                                                title: "Voice-only conversation",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Switch"], {
                                                    checked: voiceOnly,
                                                    onCheckedChange: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setVoiceOnlyPreference"],
                                                    "aria-label": "Mator AI Call mode",
                                                    "data-testid": "mator-voice-switch"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                    lineNumber: 587,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                lineNumber: 583,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$settings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                disabled: busy,
                                                onSettingsSaved: onSettingsSaved
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                lineNumber: 594,
                                                columnNumber: 15
                                            }, this),
                                            models.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$model$2d$selector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModelSelector"], {
                                                models: models,
                                                currentId: modelId,
                                                onSelect: (id)=>onModelChange?.(id),
                                                disabled: busy,
                                                compact: true,
                                                className: "relative"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                lineNumber: 599,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                "aria-label": busy ? 'Sending' : 'Send message',
                                                "data-testid": "mator-send",
                                                disabled: !canSend,
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('inline-flex size-11 cursor-pointer items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed', canSend ? 'bg-teal-800 text-white hover:bg-teal-700' : 'bg-slate-100 text-slate-300'),
                                                children: busy ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                                    className: "size-4 animate-spin",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                    lineNumber: 621,
                                                    columnNumber: 19
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUp$3e$__["ArrowUp"], {
                                                    className: "size-4",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                    lineNumber: 626,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                                lineNumber: 608,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                        lineNumber: 582,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                lineNumber: 534,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 509,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center px-1.5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "hidden truncate text-[10px] text-slate-400 select-none sm:flex sm:items-center sm:gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                    className: "size-3",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                                    lineNumber: 634,
                                    columnNumber: 13
                                }, this),
                                "Enter sends · Shift+Enter adds a line"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                            lineNumber: 633,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 632,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 499,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
        lineNumber: 471,
        columnNumber: 5
    }, this);
}
_s(MatorComposer, "VWNSh2KNQD7iT3EjBfgI4MSR/1Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceOnlyPreference"]
    ];
});
_c1 = MatorComposer;
function OperatorPendingApproval({ label, onConfirm, busy }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "operator-pending-approval",
        role: "status",
        className: "mb-2 flex w-fit max-w-full min-w-0 flex-wrap items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs text-amber-900",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "min-w-0 max-w-48 truncate",
                title: label,
                children: [
                    "Local command: ",
                    label
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 658,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "operator-confirm-pending",
                onClick: onConfirm,
                disabled: busy,
                className: "inline-flex min-h-11 shrink-0 items-center gap-1.5 rounded-lg bg-amber-700 px-3 text-xs font-semibold text-white hover:bg-amber-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-700 disabled:opacity-40",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                        className: "size-4",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 668,
                        columnNumber: 9
                    }, this),
                    "Confirm local command"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 661,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
        lineNumber: 653,
        columnNumber: 5
    }, this);
}
_c2 = OperatorPendingApproval;
function IncompleteBanner({ onContinue, busy }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "incomplete-banner",
        className: "mb-2 flex items-center justify-between gap-2 rounded-xl border border-amber-200 bg-amber-50/80 px-2.5 py-1.5 text-[11px] font-semibold text-amber-900",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "min-w-0 truncate",
                children: "Mator left this run incomplete."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 687,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "data-testid": "mator-incomplete-continue",
                disabled: busy,
                onClick: onContinue,
                className: "inline-flex min-h-8 shrink-0 cursor-pointer items-center gap-1 rounded-lg bg-amber-700 px-2 text-[11px] font-bold text-white hover:bg-amber-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-700 disabled:cursor-not-allowed disabled:opacity-40",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                        className: "size-3",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                        lineNumber: 695,
                        columnNumber: 9
                    }, this),
                    "Continue"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
                lineNumber: 688,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-composer.tsx",
        lineNumber: 683,
        columnNumber: 5
    }, this);
}
_c3 = IncompleteBanner;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "VoiceMicButton");
__turbopack_context__.k.register(_c1, "MatorComposer");
__turbopack_context__.k.register(_c2, "OperatorPendingApproval");
__turbopack_context__.k.register(_c3, "IncompleteBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-run-speech.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "collectRunSpeechUpdates",
    ()=>collectRunSpeechUpdates,
    "summarizeRunEventForSpeech",
    ()=>summarizeRunEventForSpeech
]);
function summarizeRunEventForSpeech(event) {
    const message = event.message.trim();
    if (event.kind === 'approval') return 'The workflow needs your approval.';
    if (event.kind === 'input') return 'The workflow needs more information.';
    if (event.kind === 'error') return 'The workflow needs attention. Open the run details for more information.';
    if (event.kind === 'step') {
        if (message.startsWith('Started: ')) return `Step started: ${message.slice(9, 110)}.`;
        if (message.startsWith('Completed: ')) return `Step completed: ${message.slice(11, 110)}.`;
        if (message.startsWith('Failed: ')) return 'A workflow step failed. Open its details to review the cause.';
        return null;
    }
    if (event.kind !== 'status') return null;
    if (message === 'Run queued for browser startup') return 'The workflow is starting.';
    if (message.startsWith('Run paused')) return 'The workflow is paused.';
    if (message.startsWith('Run resumed')) return 'The workflow has resumed.';
    if (message === 'Run finished with verified steps') return 'The workflow finished with its steps verified.';
    if (message.startsWith('Run ended: failed') || message.startsWith('Run ended: blocked')) {
        return 'The workflow could not finish. Open the run details to see why.';
    }
    if (message.startsWith('Run ended: cancelled')) return 'The workflow was cancelled.';
    return null;
}
function collectRunSpeechUpdates(events, runId, seen) {
    const updates = [];
    for (const event of events){
        if (event.runId !== runId || seen.has(event.id)) continue;
        seen.add(event.id);
        const spoken = summarizeRunEventForSpeech(event);
        if (spoken) updates.push(spoken);
    }
    return updates;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-assistant-avatar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AssistantAvatar",
    ()=>AssistantAvatar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/workflow.mjs [app-client] (ecmascript) <export default as Workflow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/avatar.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function AssistantAvatar() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
        className: "size-8 bg-gradient-to-br from-teal-700 to-teal-800 text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__["Workflow"], {
                className: "size-4",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-assistant-avatar.tsx",
                lineNumber: 10,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/apps/frontend/components/mator/chat/mator-assistant-avatar.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-assistant-avatar.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = AssistantAvatar;
var _c;
__turbopack_context__.k.register(_c, "AssistantAvatar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-review-image.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReviewImage",
    ()=>ReviewImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
'use client';
;
;
function ReviewImage({ review, src }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        unoptimized: true,
        src: src,
        alt: `Annotated ${review.pageUrl}`,
        width: 640,
        height: 400,
        className: "pointer-events-none max-h-44 w-full object-contain select-none"
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-review-image.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = ReviewImage;
var _c;
__turbopack_context__.k.register(_c, "ReviewImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/task.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Task",
    ()=>Task
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-alert.mjs [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CircleCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$dashed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleDashed$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-dashed.mjs [app-client] (ecmascript) <export default as CircleDashed>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$slash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleSlash$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-slash.mjs [app-client] (ecmascript) <export default as CircleSlash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function taskTitle(steps) {
    const running = steps.find((step)=>step.status === 'running');
    const blocked = steps.find((step)=>step.status === 'blocked');
    const failing = steps.find((step)=>step.status === 'error');
    const cancelled = steps.find((step)=>step.status === 'cancelled');
    if (running) return running.title;
    if (blocked) return `Blocked: ${blocked.title}`;
    if (failing) return `Failed: ${failing.title}`;
    if (cancelled) return `Cancelled: ${cancelled.title}`;
    return steps[steps.length - 1]?.title ?? 'Recorded tasks';
}
function Task({ running, steps, className }) {
    _s();
    const reducedMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const contentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const triggerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    if (steps.length === 0) return null;
    const hasError = steps.some((step)=>[
            'error',
            'blocked'
        ].includes(step.status ?? ''));
    const hasCancelled = steps.some((step)=>step.status === 'cancelled');
    const hasUnknown = steps.some((step)=>step.status === 'unknown');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "task",
        "data-testid": "task-trace",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('min-w-0 rounded-xl border border-slate-200 bg-white/80', className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                id: triggerId,
                "aria-controls": contentId,
                "aria-expanded": open,
                "data-testid": "task-trace-trigger",
                onClick: ()=>setOpen((value)=>!value),
                className: "flex min-h-11 w-full cursor-pointer items-center gap-2 px-3 py-2 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                children: [
                    running ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                        className: "size-3.5 shrink-0 animate-spin text-teal-700",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this) : hasError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        className: "size-3.5 shrink-0 text-rose-600",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this) : hasCancelled ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$slash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleSlash$3e$__["CircleSlash"], {
                        className: "size-3.5 shrink-0 text-slate-600",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this) : hasUnknown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$dashed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleDashed$3e$__["CircleDashed"], {
                        className: "size-3.5 shrink-0 text-slate-500",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 86,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__["CircleCheck"], {
                        className: "size-3.5 shrink-0 text-teal-700",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "truncate text-xs font-semibold text-slate-700",
                        children: taskTitle(steps)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-auto shrink-0 text-[11px] text-slate-400",
                        children: [
                            steps.length,
                            " step",
                            steps.length === 1 ? '' : 's'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                        "aria-hidden": "true",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('size-3.5 shrink-0 text-slate-400 transition-transform', open && 'rotate-180')
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                initial: false,
                children: open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].ul, {
                    id: contentId,
                    role: "region",
                    "aria-labelledby": triggerId,
                    initial: reducedMotion ? {
                        opacity: 0
                    } : {
                        opacity: 0,
                        y: -4
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: reducedMotion ? {
                        opacity: 0
                    } : {
                        opacity: 0,
                        y: -4
                    },
                    transition: {
                        duration: 0.2,
                        ease: 'easeOut'
                    },
                    className: "overflow-hidden border-t border-slate-100 px-3 py-2",
                    children: steps.map((step)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "flex items-center gap-2 py-0.5 text-[12px] text-slate-600",
                            children: [
                                step.status === 'running' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                    className: "size-3 shrink-0 animate-spin text-teal-700",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 123,
                                    columnNumber: 19
                                }, this) : step.status === 'error' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                    className: "size-3 shrink-0 text-rose-500",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 128,
                                    columnNumber: 19
                                }, this) : step.status === 'blocked' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                    className: "size-3 shrink-0 text-rose-500",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 133,
                                    columnNumber: 19
                                }, this) : step.status === 'cancelled' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$slash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleSlash$3e$__["CircleSlash"], {
                                    className: "size-3 shrink-0 text-slate-500",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 135,
                                    columnNumber: 19
                                }, this) : step.status === 'unknown' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$dashed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleDashed$3e$__["CircleDashed"], {
                                    className: "size-3 shrink-0 text-slate-400",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 137,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__["CircleCheck"], {
                                    className: "size-3 shrink-0 text-slate-300",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 139,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "truncate",
                                    children: step.title
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                                    lineNumber: 141,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, step.id, true, {
                            fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                            lineNumber: 118,
                            columnNumber: 15
                        }, this))
                }, "task-steps", false, {
                    fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                    lineNumber: 106,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/elements/task.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_s(Task, "klkGym6d2AxcVflqngjsV66VBU4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Task;
var _c;
__turbopack_context__.k.register(_c, "Task");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-run-task-trace.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "projectRunTaskTrace",
    ()=>projectRunTaskTrace
]);
const taskPattern = /^[A-Za-z][A-Za-z0-9_-]{0,63}$/;
const recognizedStages = new Set([
    'started',
    'completed',
    'failed'
]);
function projectRunTaskTrace(events) {
    const runId = events[0]?.runId;
    const unique = new Map();
    const conflicting = new Set();
    for (const event of events){
        if (event.runId !== runId || !Number.isSafeInteger(event.id) || event.id < 1) continue;
        if (conflicting.has(event.id)) continue;
        const previous = unique.get(event.id);
        if (previous && JSON.stringify(previous) !== JSON.stringify(event)) {
            unique.delete(event.id);
            conflicting.add(event.id);
        } else if (!previous) {
            unique.set(event.id, event);
        }
    }
    const sorted = [
        ...unique.values()
    ].sort((a, b)=>a.id - b.id);
    const tasks = new Map();
    const notes = [];
    let terminal = null;
    for (const event of sorted){
        const data = event.details;
        const details = data && typeof data === 'object' && !Array.isArray(data) ? data : null;
        const stepId = details?.stepId;
        const phase = details?.stage;
        const taskEvent = event.kind === 'step' && typeof stepId === 'string' && taskPattern.test(stepId) && typeof phase === 'string' && recognizedStages.has(phase);
        if (taskEvent && !terminal) {
            const title = event.message.replace(/^(Started|Completed|Failed):\s*/i, '').trim();
            tasks.set(stepId, {
                id: stepId,
                title: title || (tasks.get(stepId)?.title ?? stepId),
                status: phase === 'completed' ? 'done' : phase === 'failed' ? 'error' : 'running'
            });
            continue;
        }
        notes.push({
            id: event.id,
            kind: event.kind,
            message: event.message
        });
        if (event.kind === 'status') {
            const state = /^Run ended:\s*(cancelled|blocked|failed|completed)/i.exec(event.message);
            if (state) terminal = state[1].toLowerCase();
            else if (event.message === 'Run finished with verified steps') terminal = 'completed';
        }
        if (terminal) {
            for (const task of tasks.values()){
                if (task.status !== 'running') continue;
                task.status = terminal === 'completed' ? 'unknown' : terminal === 'failed' ? 'error' : terminal;
            }
        }
    }
    const steps = [
        ...tasks.values()
    ];
    return {
        steps,
        notes,
        running: steps.some((step)=>step.status === 'running'),
        hasConflicts: conflicting.size > 0
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-task-block.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TaskBlock",
    ()=>TaskBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$task$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/task.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$run$2d$task$2d$trace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-run-task-trace.ts [app-client] (ecmascript)");
'use client';
;
;
;
function TaskBlock({ steps, evidence }) {
    const trace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$run$2d$task$2d$trace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectRunTaskTrace"])(steps);
    const visibleNotes = trace.notes.slice(-12);
    const journalId = steps[0]?.runId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full max-w-[min(100%,32rem)] min-w-0 space-y-2",
        children: [
            trace.steps.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$task$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Task"], {
                steps: trace.steps,
                running: trace.running
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                lineNumber: 20,
                columnNumber: 34
            }, this),
            trace.hasConflicts && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "text-xs text-amber-800",
                children: "Conflicting Runner events were excluded. Execution history may be incomplete."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                lineNumber: 22,
                columnNumber: 9
            }, this),
            visibleNotes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                className: "min-w-0 rounded-xl border border-slate-200 bg-white/70 px-3 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                        className: "cursor-pointer text-xs font-medium text-slate-600",
                        children: [
                            trace.notes.length,
                            " recorded observation",
                            trace.notes.length === 1 ? '' : 's'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this),
                    trace.notes.length > visibleNotes.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-[11px] text-slate-500",
                        children: [
                            "Showing the most recent ",
                            visibleNotes.length,
                            " observations."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                        lineNumber: 32,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "mt-2 max-h-48 space-y-2 overflow-y-auto text-xs text-slate-600",
                        children: visibleNotes.map((event)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "break-words",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold capitalize",
                                        children: event.kind
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                                        lineNumber: 39,
                                        columnNumber: 17
                                    }, this),
                                    ": ",
                                    event.message
                                ]
                            }, event.id, true, {
                                fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                                lineNumber: 38,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this),
                    journalId && /^[0-9a-f-]{36}$/i.test(journalId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: `/api/runs/${encodeURIComponent(journalId)}/logs`,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "mt-2 inline-block text-xs text-teal-800 underline",
                        children: "Open recorded Runner journal"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                        lineNumber: 44,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this),
            evidence
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-task-block.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = TaskBlock;
var _c;
__turbopack_context__.k.register(_c, "TaskBlock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MatorPipelineExecution",
    ()=>MatorPipelineExecution
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const states = {
    waiting: 'Waiting',
    running: 'Running',
    completed: 'Completed',
    finalizing: 'Verifying and cleaning up',
    'approval-needed': 'Approval required',
    'input-needed': 'Response required',
    paused: 'Paused',
    blocked: 'Blocked',
    failed: 'Failed',
    cancelled: 'Cancelled',
    unavailable: 'Unavailable'
};
function PendingTask({ task, runId, busy, onDecision, onInput }) {
    _s();
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [requestError, setRequestError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const live = task.checkpointId && runId;
    const submit = async (operation)=>{
        if (busy || submitting) return;
        setSubmitting(true);
        setRequestError('');
        try {
            await operation();
        } catch (reason) {
            setRequestError(reason instanceof Error ? reason.message : 'Runner request rejected');
        } finally{
            setSubmitting(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        className: "min-w-0 border-l border-slate-200 py-2 pl-3",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex min-w-0 items-start gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "mt-1 size-2 shrink-0 rounded-full bg-slate-400",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-w-0 flex-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-xs font-medium leading-5 break-words text-slate-800",
                            children: task.title
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[11px] text-slate-500",
                            children: states[task.state] ?? 'Unknown'
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, this),
                        task.failure && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "mt-1 text-xs break-words text-rose-700",
                            children: task.failure
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 66,
                            columnNumber: 28
                        }, this),
                        task.events.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "mt-1 text-[11px] text-slate-500",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "cursor-pointer",
                                    children: [
                                        "Recorded events (",
                                        task.events.length,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 69,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                    className: "mt-2 max-h-36 space-y-1 overflow-y-auto",
                                    children: task.events.map((event)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "break-words",
                                            children: [
                                                event.time,
                                                ": ",
                                                event.message
                                            ]
                                        }, event.id, true, {
                                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                            lineNumber: 72,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 68,
                            columnNumber: 13
                        }, this),
                        runId && task.screenshots.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-1 flex flex-wrap gap-2",
                            children: task.screenshots.map((name)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "/api/runs/" + encodeURIComponent(runId) + "/evidence/" + encodeURIComponent(name),
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-xs text-teal-800 underline",
                                    children: [
                                        "Recorded screenshot: ",
                                        name
                                    ]
                                }, name, true, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 80,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 78,
                            columnNumber: 13
                        }, this),
                        live && task.state === 'approval-needed' && onDecision && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-2 flex flex-wrap gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy || submitting,
                                    onClick: ()=>void submit(()=>onDecision(runId, task.checkpointId, true)),
                                    className: "min-h-9 rounded-md border border-teal-700 px-2 text-xs font-semibold text-teal-800 disabled:opacity-50",
                                    children: "Approve"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy || submitting,
                                    onClick: ()=>void submit(()=>onDecision(runId, task.checkpointId, false)),
                                    className: "min-h-9 rounded-md border border-rose-300 px-2 text-xs font-semibold text-rose-800 disabled:opacity-50",
                                    children: "Reject"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 100,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 93,
                            columnNumber: 13
                        }, this),
                        live && task.state === 'input-needed' && onInput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            className: "mt-2 flex min-w-0 flex-wrap gap-2",
                            onSubmit: (event)=>{
                                event.preventDefault();
                                if (input.trim()) void submit(()=>onInput(runId, task.checkpointId, input.trim()));
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "w-full text-[11px] text-slate-600",
                                    htmlFor: "task-answer-" + task.id,
                                    children: "Requested input"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 116,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    id: "task-answer-" + task.id,
                                    value: input,
                                    onChange: (event)=>setInput(event.target.value),
                                    maxLength: 300,
                                    className: "min-w-0 flex-1 rounded-md border border-slate-300 px-2 py-1 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 119,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    disabled: busy || submitting || !input.trim(),
                                    className: "min-h-9 rounded-md bg-slate-900 px-3 text-xs text-white disabled:opacity-50",
                                    children: "Submit"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                    lineNumber: 126,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 109,
                            columnNumber: 13
                        }, this),
                        requestError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "mt-1 text-xs text-rose-700",
                            children: requestError
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                            lineNumber: 133,
                            columnNumber: 28
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
            lineNumber: 61,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(PendingTask, "r35MPG4CF618TqEdY2y6/3l/N0E=");
_c = PendingTask;
function MatorPipelineExecution({ execution, title, busy = false, error, onDecision, onInput }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-testid": "mator-pipeline-execution",
        "aria-label": "Selected workspace execution",
        className: "mx-3 my-2 min-w-0 max-w-[32rem] rounded-xl border border-slate-200 bg-slate-50/80 p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-w-0 space-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs font-semibold break-words text-slate-900",
                        children: title || execution.workflowId
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[11px] text-slate-500",
                        children: "Selected workspace execution · separate from saved conversation history"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "mt-2 text-xs text-rose-700",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                lineNumber: 155,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 max-h-64 space-y-2 overflow-y-auto",
                children: execution.pipelines.map((pipeline)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "min-w-0 rounded-lg border border-slate-200 bg-white",
                        open: [
                            'running',
                            'approval-needed',
                            'input-needed',
                            'blocked',
                            'failed'
                        ].includes(pipeline.state) ? true : undefined,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                className: "flex min-h-11 cursor-pointer flex-wrap items-center gap-x-2 gap-y-1 px-3 py-2 text-xs",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "min-w-0 flex-1 font-semibold break-words text-slate-900",
                                        children: pipeline.title
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                        lineNumber: 161,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-slate-500",
                                        children: [
                                            pipeline.completed,
                                            "/",
                                            pipeline.total,
                                            " recorded"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                        lineNumber: 162,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-full text-[11px] text-slate-600",
                                        children: states[pipeline.state] ?? 'Unknown'
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                        lineNumber: 163,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                lineNumber: 160,
                                columnNumber: 13
                            }, this),
                            pipeline.historyIncomplete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                role: "status",
                                className: "mx-3 text-xs text-amber-800",
                                children: "Journal unavailable or incomplete. Progress may be missing."
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                lineNumber: 166,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                className: "space-y-0 px-3 pb-2",
                                children: pipeline.tasks.map((task)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PendingTask, {
                                        task: task,
                                        runId: pipeline.runId,
                                        busy: busy,
                                        onDecision: onDecision,
                                        onInput: onInput
                                    }, task.id, false, {
                                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                        lineNumber: 170,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                                lineNumber: 168,
                                columnNumber: 13
                            }, this)
                        ]
                    }, pipeline.id, true, {
                        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                        lineNumber: 158,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
                lineNumber: 156,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_c1 = MatorPipelineExecution;
var _c, _c1;
__turbopack_context__.k.register(_c, "PendingTask");
__turbopack_context__.k.register(_c1, "MatorPipelineExecution");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-thread-format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clarifyCount",
    ()=>clarifyCount,
    "threadWhen",
    ()=>threadWhen
]);
function threadWhen(iso) {
    if (!iso) return '';
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return '';
    return date.toLocaleDateString([], {
        month: 'short',
        day: 'numeric'
    });
}
function clarifyCount(questions) {
    return questions.length;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/chat/mator-thread-row.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThreadRow",
    ()=>ThreadRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/message-scroller.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function ThreadRow({ id, anchor = false, side = 'start', children }) {
    _s();
    const reduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerItem"], {
        messageId: id,
        scrollAnchor: anchor,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: reduceMotion ? false : {
                opacity: 0,
                y: 10
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                duration: 0.22,
                ease: 'easeOut'
            },
            "data-message-side": side,
            className: side === 'end' ? 'flex w-full min-w-0 justify-end' : 'w-full min-w-0',
            children: children
        }, void 0, false, {
            fileName: "[project]/apps/frontend/components/mator/chat/mator-thread-row.tsx",
            lineNumber: 22,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/chat/mator-thread-row.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_s(ThreadRow, "yAKkJs7CtWSNDV8HpmqLOOhKJtw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
});
_c = ThreadRow;
var _c;
__turbopack_context__.k.register(_c, "ThreadRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/checkpoint.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Checkpoint",
    ()=>Checkpoint
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$presentation$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/presentation-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
function Checkpoint({ label, runId, time, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "checkpoint",
        "data-testid": "task-checkpoint",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center gap-3 py-1 text-[11px] text-slate-400 select-none', className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "h-px flex-1 bg-slate-200"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/checkpoint.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-1.5 font-medium tracking-wider whitespace-nowrap uppercase",
                children: [
                    label,
                    time ? ` · ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$presentation$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeLabel"])(time)}` : ''
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/elements/checkpoint.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "h-px flex-1 bg-slate-200"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/checkpoint.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            runId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "font-mono text-[10px] text-slate-300",
                children: runId.slice(0, 8)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/checkpoint.tsx",
                lineNumber: 31,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/elements/checkpoint.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = Checkpoint;
var _c;
__turbopack_context__.k.register(_c, "Checkpoint");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/confirmation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Confirmation",
    ()=>Confirmation,
    "useCopyAction",
    ()=>useCopyAction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/check.mjs [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCopy$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/clipboard-copy.mjs [app-client] (ecmascript) <export default as ClipboardCopy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/shield-alert.mjs [app-client] (ecmascript) <export default as ShieldAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/shield-check.mjs [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/alert-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const statusTone = {
    staged: {
        tone: 'orange',
        label: 'Staged · awaiting approval'
    },
    applied: {
        tone: 'teal',
        label: 'Applied'
    },
    rejected: {
        tone: 'rose',
        label: 'Rejected'
    },
    incomplete: {
        tone: 'amber',
        label: 'Incomplete'
    },
    error: {
        tone: 'rose',
        label: 'Failed'
    }
};
function Confirmation({ status, action, text, attachment, onConfirm, onReject, busy, className }) {
    _s();
    const [rejectOpen, setRejectOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const meta = statusTone[status] ?? statusTone.staged;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "confirmation",
        "data-status": status,
        "data-testid": "mator-confirmation",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('min-w-0 max-w-full overflow-hidden rounded-xl border bg-white shadow-sm', status === 'staged' ? 'border-orange-200' : status === 'rejected' ? 'border-rose-200' : status === 'incomplete' ? 'border-amber-200' : status === 'error' ? 'border-rose-300' : 'border-teal-200', className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2 px-3 pt-2.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                        tone: meta.tone,
                        size: "xs",
                        children: status === 'applied' && action === 'run step' ? 'Run started' : meta.label
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this),
                    action && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "truncate text-[11px] text-slate-400",
                        children: action
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            text && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 break-words px-3 text-[13px] leading-relaxed text-slate-800 [overflow-wrap:anywhere]",
                children: text
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this),
            attachment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 px-3",
                children: attachment
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                lineNumber: 84,
                columnNumber: 22
            }, this),
            status === 'staged' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2.5 flex items-center gap-2 border-t border-orange-100 bg-orange-50/50 px-3 py-2.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "flex-1 text-[11px] font-semibold text-orange-900",
                        children: "Confirm to apply, or reject to leave everything untouched."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                        lineNumber: 87,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "data-testid": "mator-stage-reject",
                        disabled: busy,
                        onClick: ()=>setRejectOpen(true),
                        className: "inline-flex min-h-9 cursor-pointer items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-2.5 text-xs font-semibold text-rose-700 hover:bg-rose-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600 disabled:cursor-not-allowed disabled:opacity-40",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__["ShieldAlert"], {
                                className: "size-3.5",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            "Reject"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "data-testid": "mator-stage-confirm",
                        disabled: busy,
                        onClick: ()=>onConfirm?.(),
                        className: "inline-flex min-h-9 cursor-pointer items-center gap-1.5 rounded-xl bg-orange-700 px-2.5 text-xs font-semibold text-white hover:bg-orange-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-orange-700 disabled:cursor-not-allowed disabled:opacity-40",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                className: "size-3.5",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                                lineNumber: 107,
                                columnNumber: 13
                            }, this),
                            "Confirm"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                lineNumber: 86,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialog"], {
                open: rejectOpen,
                onOpenChange: (confirm)=>{
                    setRejectOpen(false);
                    if (confirm) onReject?.();
                },
                title: "Reject this staged change?",
                children: "Nothing has been applied yet. Rejecting marks this proposal as rejected in the thread — no settings, posts, or profile fields change."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
                lineNumber: 112,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_s(Confirmation, "PCPnN88K4doOwWc6JGtUoZLOKYQ=");
_c = Confirmation;
function useCopyAction() {
    _s1();
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const copy = async (text)=>{
        try {
            await navigator.clipboard.writeText(text);
            setCopied(true);
            window.setTimeout(()=>setCopied(false), 2000);
            return true;
        } catch  {
            return false;
        }
    };
    const icon = copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
        className: "size-3.5",
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
        lineNumber: 141,
        columnNumber: 5
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCopy$3e$__["ClipboardCopy"], {
        className: "size-3.5",
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/elements/confirmation.tsx",
        lineNumber: 143,
        columnNumber: 5
    }, this);
    return {
        copied,
        copy,
        icon
    };
}
_s1(useCopyAction, "NE86rL3vg4NVcTTWDavsT0hUBJs=");
var _c;
__turbopack_context__.k.register(_c, "Confirmation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/queue.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Queue",
    ()=>Queue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
function Queue({ active, text = 'Sending…', className }) {
    if (!active) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "status",
        "data-testid": "mator-queue",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center gap-2 px-4 pt-2 text-[11px] font-medium text-slate-500', className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                className: "size-3 animate-spin text-teal-700",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/queue.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            text
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/elements/queue.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c = Queue;
var _c;
__turbopack_context__.k.register(_c, "Queue");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/reasoning.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Reasoning",
    ()=>Reasoning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CircleCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/workflow.mjs [app-client] (ecmascript) <export default as Workflow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function Reasoning({ title, content, defaultOpen = false, onSpeak, speakLabel = 'Read this guidance aloud', className }) {
    _s();
    const reducedMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultOpen);
    const contentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const triggerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "reasoning",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('min-w-0 rounded-xl border border-slate-200 bg-white/70', className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2 px-3 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        id: triggerId,
                        "aria-controls": contentId,
                        "aria-expanded": open,
                        onClick: ()=>setOpen((value)=>!value),
                        className: "flex min-w-0 cursor-pointer items-center gap-2 rounded-lg py-0.5 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__["CircleCheck"], {
                                className: "size-3.5 shrink-0 text-teal-700",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                                lineNumber: 51,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "truncate text-xs font-semibold text-slate-700",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                "aria-hidden": "true",
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('size-3.5 shrink-0 text-slate-400 transition-transform', open && 'rotate-180')
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                                lineNumber: 58,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    onSpeak && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onSpeak,
                        "aria-label": speakLabel,
                        className: "inline-flex size-7 shrink-0 cursor-pointer items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__["Workflow"], {
                                className: "size-3.5",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                                lineNumber: 73,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "sr-only",
                                children: speakLabel
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                                lineNumber: 74,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                initial: false,
                children: open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    id: contentId,
                    role: "region",
                    "aria-labelledby": triggerId,
                    initial: reducedMotion ? {
                        opacity: 0
                    } : {
                        opacity: 0,
                        y: -4
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: reducedMotion ? {
                        opacity: 0
                    } : {
                        opacity: 0,
                        y: -4
                    },
                    transition: {
                        duration: 0.2,
                        ease: 'easeOut'
                    },
                    className: "overflow-hidden border-t border-slate-100 px-3 pt-2 pb-2.5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[13px] leading-relaxed whitespace-pre-wrap text-slate-700",
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                        lineNumber: 91,
                        columnNumber: 13
                    }, this)
                }, "reasoning-content", false, {
                    fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                    lineNumber: 80,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/elements/reasoning.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_s(Reasoning, "7iFglJ3pbfMA6axWwAOx5ABnsUw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Reasoning;
var _c;
__turbopack_context__.k.register(_c, "Reasoning");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/elements/suggestion.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Suggestion",
    ()=>Suggestion
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
function Suggestion({ suggestions, onSelect, disabled, className }) {
    if (suggestions.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-wrap gap-1.5 pb-1', className),
        "data-testid": "mator-suggestions",
        children: suggestions.map((suggestion)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                disabled: disabled,
                onClick: ()=>onSelect(suggestion.prompt),
                className: "min-h-9 cursor-pointer rounded-full border border-slate-200 bg-white px-3 text-xs font-medium text-slate-600 transition-colors hover:border-teal-400 hover:bg-teal-50/60 hover:text-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                children: suggestion.label
            }, suggestion.label, false, {
                fileName: "[project]/apps/frontend/components/mator/elements/suggestion.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/elements/suggestion.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_c = Suggestion;
var _c;
__turbopack_context__.k.register(_c, "Suggestion");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/markdown-reply.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MarkdownReply",
    ()=>MarkdownReply
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
/**
 * Minimal, dependency-free markdown rendering for Mator replies.
 * Mator's text is interpreter- or LLM-generated prose using a small
 * markdown surface: paragraphs, -lists, 1. lists, # headings, **bold**,
 * *italic*, `inline code`, and ``` fenced code. Anything else renders
 * verbatim as plain text — no invented structure.
 */ let keySeed = 0;
function nextKey(prefix) {
    keySeed = (keySeed + 1) % Number.MAX_SAFE_INTEGER;
    return `${prefix}-${keySeed}`;
}
function inline(text) {
    const nodes = [];
    const pattern = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
    let match;
    let last = 0;
    while((match = pattern.exec(text)) !== null){
        if (match.index > last) nodes.push(text.slice(last, match.index));
        const token = match[0];
        if (token.startsWith('**')) {
            nodes.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                className: "font-semibold text-slate-900",
                children: token.slice(2, -2)
            }, nextKey('b'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this));
        } else if (token.startsWith('`')) {
            nodes.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                className: "rounded-md bg-slate-100 px-1 font-mono text-[12px] text-slate-800",
                children: token.slice(1, -1)
            }, nextKey('c'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 33,
                columnNumber: 9
            }, this));
        } else {
            nodes.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                children: token.slice(1, -1)
            }, nextKey('i'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 41,
                columnNumber: 18
            }, this));
        }
        last = match.index + token.length;
    }
    if (last < text.length) nodes.push(text.slice(last));
    return nodes;
}
function MarkdownReply({ text }) {
    const lines = text.split('\n');
    const blocks = [];
    let paragraph = [];
    let list = null;
    let code = null;
    const flushParagraph = ()=>{
        if (paragraph.length === 0) return;
        blocks.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[13px] leading-relaxed text-slate-700",
            children: inline(paragraph.join(' '))
        }, nextKey('p'), false, {
            fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
            lineNumber: 59,
            columnNumber: 7
        }, this));
        paragraph = [];
    };
    const flushList = ()=>{
        if (!list) return;
        const items = list.items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                className: "ml-4 list-outside",
                children: inline(item)
            }, nextKey('li'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this));
        blocks.push(list.ordered ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
            className: "list-decimal space-y-1 text-[13px] leading-relaxed text-slate-700",
            children: items
        }, nextKey('ol'), false, {
            fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
            lineNumber: 77,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "list-disc space-y-1 text-[13px] leading-relaxed text-slate-700",
            children: items
        }, nextKey('ul'), false, {
            fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
            lineNumber: 84,
            columnNumber: 9
        }, this));
        list = null;
    };
    for (const line of lines){
        if (line.trim().startsWith('```')) {
            if (code) {
                blocks.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                    className: "overflow-x-auto rounded-xl bg-slate-900 px-3 py-2.5 text-[12px] leading-5 text-slate-100",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                        className: "font-mono",
                        children: code.join('\n')
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                        lineNumber: 103,
                        columnNumber: 13
                    }, this)
                }, nextKey('pre'), false, {
                    fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                    lineNumber: 99,
                    columnNumber: 11
                }, this));
                code = null;
            } else {
                flushParagraph();
                flushList();
                code = [];
            }
            continue;
        }
        if (code !== null) {
            code.push(line);
            continue;
        }
        if (line.trim().length === 0) {
            flushParagraph();
            flushList();
            continue;
        }
        const bullet = line.match(/^\s*[-*]\s+(.*)$/);
        const ordered = line.match(/^\s*\d+[.)]\s+(.*)$/);
        const heading = line.match(/^(#{1,3})\s+(.*)$/);
        if (bullet) {
            flushParagraph();
            if (!list || list.ordered) {
                flushList();
                list = {
                    ordered: false,
                    items: []
                };
            }
            list.items.push(bullet[1]);
            continue;
        }
        if (ordered) {
            flushParagraph();
            if (!list?.ordered) {
                flushList();
                list = {
                    ordered: true,
                    items: []
                };
            }
            list.items.push(ordered[1]);
            continue;
        }
        if (heading) {
            flushParagraph();
            flushList();
            const level = heading[1].length;
            blocks.push(level === 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm font-bold text-slate-900",
                children: inline(heading[2])
            }, nextKey('h'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 150,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: level === 2 ? 'text-[13px] font-semibold text-slate-800' : 'text-[12px] font-semibold tracking-wide text-slate-700 uppercase',
                children: inline(heading[2])
            }, nextKey('h'), false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 154,
                columnNumber: 11
            }, this));
            continue;
        }
        flushList();
        paragraph.push(line.trim());
    }
    flushParagraph();
    flushList();
    if (code !== null && code.length > 0) {
        blocks.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
            className: "overflow-x-auto rounded-xl bg-slate-900 px-3 py-2.5 text-[12px] leading-5 text-slate-100",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                className: "font-mono",
                children: code.join('\n')
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 179,
                columnNumber: 9
            }, this)
        }, nextKey('pre2'), false, {
            fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
            lineNumber: 175,
            columnNumber: 7
        }, this));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-w-0 flex-col gap-2",
        children: blocks.map((block, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: block
            }, i, false, {
                fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
                lineNumber: 186,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/mator/markdown-reply.tsx",
        lineNumber: 184,
        columnNumber: 5
    }, this);
}
_c = MarkdownReply;
var _c;
__turbopack_context__.k.register(_c, "MarkdownReply");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-chat-state.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eventsToConversation",
    ()=>eventsToConversation,
    "findIncompleteEvent",
    ()=>findIncompleteEvent,
    "findOpenClarify",
    ()=>findOpenClarify,
    "findPendingStage",
    ()=>findPendingStage,
    "formatClarifyReply",
    ()=>formatClarifyReply,
    "mergeMatorEvents",
    ()=>mergeMatorEvents,
    "pendingStageLabel",
    ()=>pendingStageLabel,
    "readClarifyQuestions",
    ()=>readClarifyQuestions,
    "seedConversation",
    ()=>seedConversation,
    "shouldRenderMatorEvent",
    ()=>shouldRenderMatorEvent,
    "shouldSpeakHow",
    ()=>shouldSpeakHow,
    "stageResolution",
    ()=>stageResolution
]);
const SEED_TEXT = 'Message this thread. I can audit a profile, change a headline, add a skill, or draft a post.';
function seedConversation() {
    return [
        {
            id: 'seed',
            sender: 'assistant',
            text: SEED_TEXT
        }
    ];
}
function mergeMatorEvents(existing, incoming) {
    const byId = new Map();
    for (const event of existing)byId.set(event.id, event);
    for (const event of incoming)byId.set(event.id, event);
    return [
        ...byId.values()
    ].sort((a, b)=>a.createdAt.localeCompare(b.createdAt));
}
function eventsToConversation(events, localNotices = []) {
    const fromEvents = [];
    for (const event of events){
        if (!event.text?.trim()) continue;
        if (event.role === 'user' && event.kind === 'message') {
            fromEvents.push({
                id: event.id,
                sender: 'user',
                text: event.text
            });
            continue;
        }
        if (event.role === 'assistant' && (event.kind === 'message' || event.kind === 'how')) {
            fromEvents.push({
                id: event.id,
                sender: 'assistant',
                text: event.text
            });
        }
    }
    const bubbles = fromEvents.length > 0 || localNotices.length > 0 ? [
        ...fromEvents,
        ...localNotices
    ] : seedConversation();
    return bubbles;
}
function stageResolution(events, stagedId) {
    const stagedAt = events.findIndex((event)=>event.id === stagedId && event.status === 'staged');
    if (stagedAt < 0) return null;
    for(let index = stagedAt + 1; index < events.length; index += 1){
        const candidate = events[index];
        if (candidate.status !== 'applied' && candidate.status !== 'rejected') continue;
        if (candidate.resolvesEventId) {
            if (candidate.resolvesEventId === stagedId) return candidate.status;
            continue;
        }
        // Backward compatibility for histories saved before resolvesEventId existed.
        const latestStage = events.slice(0, index).reverse().find((event)=>event.status === 'staged');
        if (latestStage?.id === stagedId) return candidate.status;
    }
    return null;
}
function shouldRenderMatorEvent(events, event) {
    if (event.kind !== 'action') return true;
    const type = isRecord(event.action) ? event.action.type : null;
    if (type === 'noop') return false;
    // Older histories may contain staged explanations; display their text as guidance.
    if (type === 'explain_how') {
        return event.status !== 'applied' && Boolean(event.text?.trim());
    }
    if (event.status !== 'applied' && event.status !== 'rejected') return true;
    const priorStage = event.resolvesEventId ? events.find((candidate)=>candidate.id === event.resolvesEventId) : events.slice(0, events.findIndex((candidate)=>candidate.id === event.id)).reverse().find((candidate)=>candidate.status === 'staged');
    return !(priorStage?.status === 'staged' && stageResolution(events, priorStage.id) === event.status);
}
function isAssistantTerminal(event) {
    if (event.role !== 'assistant') return false;
    if (event.status === 'incomplete' || event.status === 'applied' || event.status === 'rejected' || event.status === 'error' || event.status === 'staged') {
        return true;
    }
    return event.kind === 'message' || event.kind === 'how';
}
function findPendingStage(events) {
    for(let index = events.length - 1; index >= 0; index -= 1){
        const event = events[index];
        if (event?.status !== 'staged' || !shouldRenderMatorEvent(events, event) || isRecord(event.action) && event.action.type === 'explain_how') continue;
        if (!stageResolution(events, event.id)) return event;
    }
    return null;
}
function findIncompleteEvent(events) {
    for(let index = events.length - 1; index >= 0; index -= 1){
        const event = events[index];
        if (!event || !isAssistantTerminal(event)) continue;
        return event.status === 'incomplete' ? event : null;
    }
    return null;
}
function shouldSpeakHow(event, howTtsEnabled) {
    return howTtsEnabled && event.kind === 'how' && event.role === 'assistant' && Boolean(event.text?.trim());
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function readClarifyQuestions(action) {
    if (!isRecord(action) || action.type !== 'clarify') return null;
    if (!Array.isArray(action.questions) || action.questions.length === 0) return null;
    const questions = [];
    for (const item of action.questions){
        if (!isRecord(item) || typeof item.name !== 'string' || typeof item.prompt !== 'string') return null;
        const choices = [];
        if (Array.isArray(item.choices)) {
            for (const choice of item.choices){
                if (!isRecord(choice) || typeof choice.value !== 'string' || typeof choice.label !== 'string') return null;
                choices.push({
                    value: choice.value,
                    label: choice.label,
                    ...typeof choice.description === 'string' ? {
                        description: choice.description
                    } : {}
                });
            }
        }
        const freeformLabel = isRecord(item.freeform) && typeof item.freeform.label === 'string' ? item.freeform.label : typeof item.freeformLabel === 'string' ? item.freeformLabel : undefined;
        questions.push({
            name: item.name,
            prompt: item.prompt,
            required: item.required === true,
            multiple: item.multiple === true,
            choices,
            inputType: item.inputType === 'url' || item.inputType === 'file' ? item.inputType : 'text',
            ...typeof item.description === 'string' ? {
                description: item.description
            } : {},
            ...freeformLabel || item.inputType === 'url' ? {
                freeformLabel: freeformLabel || 'Paste a website URL'
            } : {}
        });
    }
    return questions;
}
function findOpenClarify(events) {
    for(let index = events.length - 1; index >= 0; index -= 1){
        const event = events[index];
        if (!event) continue;
        if (event.role === 'user') return null;
        if (event.kind === 'clarify' && readClarifyQuestions(event.action)) return event;
    }
    return null;
}
function formatClarifyReply(questions, formData) {
    return questions.map((question)=>{
        const values = formData.getAll(question.name).map(String).map((value)=>value.trim()).filter(Boolean);
        const answer = values.length > 0 ? values.join(', ') : 'Skipped';
        return `${question.prompt} ${answer}`;
    }).join('\n');
}
function pendingStageLabel(event) {
    if (!event) return null;
    const action = event.action;
    if (action?.type) return action.type.replaceAll('_', ' ');
    return event.text?.trim() || 'staged action';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-clarify-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatorClarifyForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/questionnaire.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-chat-state.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-composer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function MatorClarifyForm({ questions, disabled = false, onUploadFile, onSubmit, onAnswerData, className }) {
    _s();
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const inFlight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // An input element survives retries even if FormData constructs a new File
    // wrapper (notably in WebKit). Its onChange handler invalidates the cached ID.
    const uploaded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new WeakMap());
    const handleSubmit = (event)=>{
        event.preventDefault();
        if (inFlight.current || disabled) return;
        const formElement = event.currentTarget;
        const form = new FormData(formElement);
        inFlight.current = true;
        setSubmitting(true);
        setError('');
        void (async ()=>{
            try {
                const attachments = [];
                for (const question of questions){
                    const answer = form.get(question.name);
                    if (question.inputType === 'text' && question.required && !form.getAll(question.name).some((value)=>typeof value === 'string' && Boolean(value.trim()))) {
                        throw new Error(`Answer ${question.prompt} before sending.`);
                    }
                    if (question.inputType === 'url') {
                        const value = typeof answer === 'string' ? answer.trim() : '';
                        if (!value && !question.required) continue;
                        let url;
                        try {
                            url = new URL(value);
                        } catch  {
                            throw new Error(`Enter a valid website URL for ${question.prompt}`);
                        }
                        if (![
                            'http:',
                            'https:'
                        ].includes(url.protocol)) throw new Error('Only HTTP and HTTPS website links are supported.');
                        form.set(question.name, url.href);
                    }
                    if (question.inputType === 'file') {
                        const control = formElement.elements.namedItem(question.name);
                        const input = control instanceof HTMLInputElement ? control : null;
                        const file = input?.files?.[0] ?? (answer instanceof File ? answer : null);
                        if (!file?.size) {
                            if (question.required) throw new Error(`Attach a file for ${question.prompt}`);
                            form.delete(question.name);
                            continue;
                        }
                        if (!input) throw new Error('Attachment input is unavailable. Please retry.');
                        if (!onUploadFile) throw new Error('Attachment upload is unavailable. Please try again.');
                        let id = uploaded.current.get(input);
                        if (!id) {
                            id = await onUploadFile(file);
                            if (!id) throw new Error(`Could not upload ${file.name}`);
                            uploaded.current.set(input, id);
                        }
                        attachments.push(id);
                        form.set(question.name, file.name);
                    }
                }
                const answers = {};
                for (const question of questions){
                    answers[question.name] = form.getAll(question.name).filter((value)=>typeof value === 'string').map((value)=>value.trim()).filter(Boolean);
                }
                const sent = onAnswerData ? await onAnswerData(answers, attachments) : await onSubmit?.((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatClarifyReply"])(questions, form), attachments);
                if (sent === false) throw new Error('Mator could not send the answers. Please retry.');
            } catch (cause) {
                setError(cause instanceof Error ? cause.message : 'Could not submit answers.');
            } finally{
                inFlight.current = false;
                setSubmitting(false);
            }
        })();
    };
    // The shadcn questionnaire only registers choices and text inputs as answers.
    // A native file picker cannot satisfy that headless validation contract.
    // For a file request, use a real form and keep the same upload/send handler.
    if (questions.some((question)=>question.inputType === 'file')) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: className ? `flex min-w-0 flex-col gap-3 ${className}` : 'flex min-w-0 flex-col gap-3',
            onSubmit: handleSubmit,
            noValidate: true,
            "data-testid": "mator-clarify-form",
            children: [
                questions.map((question)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                        className: "flex min-w-0 flex-col gap-2 rounded-xl border border-slate-200 p-3",
                        disabled: disabled || submitting,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                className: "px-1 text-sm font-semibold text-slate-900",
                                children: [
                                    question.prompt,
                                    question.required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        "aria-label": "required",
                                        className: "ml-1 text-orange-700",
                                        children: "*"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                        lineNumber: 174,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 171,
                                columnNumber: 13
                            }, this),
                            question.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs leading-relaxed text-slate-600",
                                children: question.description
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 180,
                                columnNumber: 15
                            }, this),
                            question.inputType === 'file' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex min-w-0 flex-col gap-1 text-xs font-medium text-slate-700",
                                children: [
                                    "Select attachment",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        name: question.name,
                                        accept: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ATTACH_ACCEPT"],
                                        "aria-label": question.prompt,
                                        "aria-required": question.required,
                                        onChange: (event)=>uploaded.current.delete(event.currentTarget),
                                        className: "min-h-11 w-full min-w-0 text-xs file:mr-2 file:rounded-lg file:border-0 file:bg-teal-50 file:px-2 file:py-2 file:text-teal-800"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                        lineNumber: 187,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 185,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    question.choices.map((choice)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "flex min-h-10 items-center gap-2 rounded-lg border border-slate-200 px-3 text-xs text-slate-700",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: question.multiple ? 'checkbox' : 'radio',
                                                    name: question.name,
                                                    value: choice.value
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                                    lineNumber: 206,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: choice.label
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                                    lineNumber: 211,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, choice.value, true, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                            lineNumber: 202,
                                            columnNumber: 19
                                        }, this)),
                                    question.freeformLabel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex min-w-0 flex-col gap-1 text-xs font-medium text-slate-700",
                                        children: [
                                            question.freeformLabel,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: question.inputType === 'url' ? 'url' : 'text',
                                                name: question.name,
                                                "aria-label": question.freeformLabel,
                                                className: "min-h-11 w-full min-w-0 rounded-lg border border-slate-200 px-3 text-sm text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                                lineNumber: 217,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                        lineNumber: 215,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, question.name, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, this)),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "rounded-lg border border-rose-200 bg-rose-50 p-2 text-xs text-rose-800",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                    lineNumber: 230,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "submit",
                    disabled: disabled || submitting,
                    className: "inline-flex min-h-11 w-fit items-center justify-center rounded-xl bg-teal-800 px-4 text-xs font-semibold text-white hover:bg-teal-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:opacity-40",
                    children: submitting ? 'Sending…' : 'Send answers'
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
            lineNumber: 155,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Questionnaire"], {
        className: className,
        items: questions.map((question)=>({
                name: question.name,
                required: question.required && question.inputType !== 'file',
                choices: question.choices.map((choice)=>({
                        value: choice.value
                    }))
            })),
        onSubmit: handleSubmit,
        "data-testid": "mator-clarify-form",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireProgress"], {}, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                lineNumber: 261,
                columnNumber: 7
            }, this),
            questions.map((question)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireItem"], {
                    name: question.name,
                    required: question.required && question.inputType !== 'file',
                    multiple: question.multiple,
                    disabled: disabled || submitting,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireTitle"], {
                            children: question.prompt
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                            lineNumber: 270,
                            columnNumber: 11
                        }, this),
                        question.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireDescription"], {
                            children: question.description
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                            lineNumber: 272,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireChoices"], {
                            children: [
                                question.choices.map((choice)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireChoice"], {
                                        value: choice.value,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block",
                                                children: choice.label
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                                lineNumber: 279,
                                                columnNumber: 17
                                            }, this),
                                            choice.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block text-[11px] font-normal text-slate-500",
                                                children: choice.description
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                                lineNumber: 281,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, choice.value, true, {
                                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                        lineNumber: 278,
                                        columnNumber: 15
                                    }, this)),
                                question.inputType === 'file' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex min-w-0 flex-col gap-1 text-xs font-medium text-slate-700",
                                    children: [
                                        "Select attachment",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "file",
                                            name: question.name,
                                            accept: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ATTACH_ACCEPT"],
                                            disabled: disabled || submitting,
                                            "aria-label": question.prompt,
                                            className: "min-h-11 w-full min-w-0 text-xs file:mr-2 file:rounded-lg file:border-0 file:bg-teal-50 file:px-2 file:py-2 file:text-teal-800"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                            lineNumber: 290,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                    lineNumber: 288,
                                    columnNumber: 15
                                }, this) : question.freeformLabel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireInput"], {
                                    type: question.inputType === 'url' ? 'url' : 'text',
                                    "aria-label": question.freeformLabel,
                                    placeholder: question.freeformLabel,
                                    disabled: disabled || submitting
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                    lineNumber: 301,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                            lineNumber: 276,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireError"], {
                            children: "Choose an answer or use skip before moving on."
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                            lineNumber: 310,
                            columnNumber: 11
                        }, this)
                    ]
                }, question.name, true, {
                    fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                    lineNumber: 263,
                    columnNumber: 9
                }, this)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "rounded-lg border border-rose-200 bg-rose-50 p-2 text-xs text-rose-800",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                lineNumber: 316,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireActions"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnairePrevious"], {
                                children: "Back"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 325,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireSkip"], {
                                children: "Skip"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 326,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                        lineNumber: 324,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireNext"], {
                                children: "Next"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 329,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$questionnaire$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuestionnaireSubmit"], {
                                disabled: disabled || submitting,
                                children: submitting ? 'Sending…' : 'Send answers'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                        lineNumber: 328,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
                lineNumber: 323,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/mator-clarify-form.tsx",
        lineNumber: 249,
        columnNumber: 5
    }, this);
}
_s(MatorClarifyForm, "snuMD4hXM45+2Na4R/6iiYoPtK0=");
_c = MatorClarifyForm;
var _c;
__turbopack_context__.k.register(_c, "MatorClarifyForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/operator-chat-panel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OperatorChatPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-alert.mjs [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CircleCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCopy$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/clipboard-copy.mjs [app-client] (ecmascript) <export default as ClipboardCopy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/image.mjs [app-client] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/message-square.mjs [app-client] (ecmascript) <export default as MessageSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw.mjs [app-client] (ecmascript) <export default as RotateCcw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/workflow.mjs [app-client] (ecmascript) <export default as Workflow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/automate-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/bubble.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/message.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/message-scroller.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$assistant$2d$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-assistant-avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$review$2d$image$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-review-image.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$task$2d$block$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-task-block.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$pipeline$2d$execution$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-pipeline-execution.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-thread-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/chat/mator-thread-row.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$checkpoint$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/checkpoint.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$confirmation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/confirmation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$queue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/queue.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$reasoning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/reasoning.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$suggestion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/elements/suggestion.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$markdown$2d$reply$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/markdown-reply.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$preview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-attachment-preview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-chat-state.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$clarify$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-clarify-form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-composer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$listener$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-voice-listener.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const PANE_LABEL = {
    workspace: 'Workspace',
    crafts: 'Craft',
    profile: 'Profile',
    growth: 'Growth',
    memory: 'Memory',
    observer: 'Observer',
    research: 'Research',
    editorial: 'Editorial',
    history: 'History',
    resumes: 'Resumes',
    settings: 'Settings'
};
const START_SUGGESTIONS = [
    {
        label: 'Audit my profile',
        prompt: 'Audit my profile'
    },
    {
        label: 'Change my headline',
        prompt: 'Change my headline to '
    },
    {
        label: 'Add a skill',
        prompt: 'Add a skill called '
    },
    {
        label: 'Draft a post',
        prompt: 'Draft a post about '
    }
];
function OperatorChatPanel({ pane, selectedCraftSlug, mobileChatOpen, showChat, onClose, conversation, events, matorEvents = [], conversations = [], conversationMeta = null, growthExecution = null, growthExecutionTitle, growthExecutionError, growthExecutionBusy = false, onGrowthDecision, onGrowthInput, loading = false, modelId = null, onModelChange, onSettingsSaved, onSwitchConversation, onNewConversation, onRestorePipeline, onSendText, onUploadClarifyFile, attachmentPreviews = {}, onSaveMarkers, onAnnotateDraft, onAnnotateAttachment, annotateChatImageAvailable = false, reviews, platform, normalizedHandle, currentRunId, onAnnotateCapture, onEditReview, onInspectReview, reviewImage, imageError, message, onMessageChange, onSendMessage, onPendingAssetsChange, voice, call, callReady, operatorPendingLabel, onConfirmOperator, onConfirm, onReject, busy = false, incomplete = false, onIncompleteContinue, chatError = null }) {
    _s();
    const reduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const toast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const [threadOpen, setThreadOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [copiedId, setCopiedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OperatorChatPanel.useEffect": ()=>{
            let mounted = true;
            void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorModels"])().then({
                "OperatorChatPanel.useEffect": ({ models: available })=>{
                    if (mounted) setModels(available.filter({
                        "OperatorChatPanel.useEffect": (model)=>model.role === 'chat'
                    }["OperatorChatPanel.useEffect"]));
                }
            }["OperatorChatPanel.useEffect"]).catch({
                "OperatorChatPanel.useEffect": ()=>{
                // Model selection is optional while the engine is unavailable.
                }
            }["OperatorChatPanel.useEffect"]);
            return ({
                "OperatorChatPanel.useEffect": ()=>{
                    mounted = false;
                }
            })["OperatorChatPanel.useEffect"];
        }
    }["OperatorChatPanel.useEffect"], []);
    const showRestore = Boolean(conversationMeta?.boundRevisionId);
    const orderedMatorEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperatorChatPanel.useMemo[orderedMatorEvents]": ()=>[
                ...matorEvents
            ].sort({
                "OperatorChatPanel.useMemo[orderedMatorEvents]": (a, b)=>a.createdAt.localeCompare(b.createdAt)
            }["OperatorChatPanel.useMemo[orderedMatorEvents]"])
    }["OperatorChatPanel.useMemo[orderedMatorEvents]"], [
        matorEvents
    ]);
    const visibleMatorEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperatorChatPanel.useMemo[visibleMatorEvents]": ()=>orderedMatorEvents.filter({
                "OperatorChatPanel.useMemo[visibleMatorEvents]": (event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldRenderMatorEvent"])(orderedMatorEvents, event)
            }["OperatorChatPanel.useMemo[visibleMatorEvents]"])
    }["OperatorChatPanel.useMemo[visibleMatorEvents]"], [
        orderedMatorEvents
    ]);
    const openClarify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findOpenClarify"])(matorEvents);
    const clarifyQuestions = openClarify ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readClarifyQuestions"])(openClarify.action) : null;
    const threadList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperatorChatPanel.useMemo[threadList]": ()=>[
                ...conversations
            ].sort({
                "OperatorChatPanel.useMemo[threadList]": (a, b)=>{
                    if (a.id === conversationMeta?.id) return -1;
                    if (b.id === conversationMeta?.id) return 1;
                    return (b.updatedAt || '').localeCompare(a.updatedAt || '');
                }
            }["OperatorChatPanel.useMemo[threadList]"])
    }["OperatorChatPanel.useMemo[threadList]"], [
        conversations,
        conversationMeta?.id
    ]);
    const threadTitle = conversationMeta?.title || 'New conversation';
    const copyReply = async (event)=>{
        if (!event.text) return;
        try {
            await navigator.clipboard.writeText(event.text);
            setCopiedId(event.id);
            window.setTimeout(()=>setCopiedId(null), 2000);
        } catch  {
            toast('Clipboard unavailable — select the text to copy', 'error');
        }
    };
    const markerDraft = voice.interim?.trim() || (voice.listening ? '' : message.trim()) || '';
    const [annotateAttachmentError, setAnnotateAttachmentError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    /**
   * Open the review studio for a sent attachment, then persist the saved
   * review reference with the asset's current markers. A failed link is
   * reported — the review itself stays real saved evidence.
   */ const annotateAsset = async (asset)=>{
        if (!onAnnotateAttachment) return;
        setAnnotateAttachmentError('');
        try {
            const result = await onAnnotateAttachment(asset.id, markerDraft.slice(0, 1500) || undefined);
            if (result?.reviewId && onSaveMarkers) {
                try {
                    await onSaveMarkers(asset.id, asset.markers ?? [], result.reviewId);
                } catch  {
                    throw new Error(`Saved as review ${result.reviewId} but could not link to the chat message. Re-open the annotation editor to retry.`);
                }
            }
        } catch (cause) {
            setAnnotateAttachmentError(cause instanceof Error ? cause.message : 'Could not open the annotation studio');
        }
    };
    const attachmentFor = (event)=>{
        const assets = event.attachments?.length ? event.attachments : event.attachmentId ? [
            {
                id: event.attachmentId,
                name: 'Image',
                mime: 'image/png',
                markers: event.markers,
                reviewId: event.reviewId
            }
        ] : [];
        if (!assets.length) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-testid": "mator-image-gallery",
            className: "w-full max-w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-3 gap-1.5 sm:grid-cols-4",
                    children: assets.map((asset)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$attachment$2d$preview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            attachmentId: asset.id,
                            filename: asset.name,
                            mime: asset.mime,
                            imageSrc: asset.mime.startsWith('image/') ? attachmentPreviews[asset.id] ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matorAttachmentFileUrl"])(asset.id) : null,
                            markers: asset.markers ?? (asset.id === event.attachmentId ? event.markers ?? [] : []),
                            reviewId: asset.reviewId ?? (asset.id === event.attachmentId ? event.reviewId : undefined),
                            interactive: Boolean(onSaveMarkers),
                            onMarkersChange: onSaveMarkers ? (markers)=>onSaveMarkers(asset.id, markers) : undefined,
                            onAnnotateFull: onAnnotateAttachment && annotateChatImageAvailable && asset.mime.startsWith('image/') ? ()=>annotateAsset(asset) : undefined
                        }, asset.id, false, {
                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                            lineNumber: 358,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                    lineNumber: 356,
                    columnNumber: 9
                }, this),
                annotateAttachmentError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    "data-testid": "mator-annotate-attachment-error",
                    className: "pt-1 text-xs text-rose-700",
                    children: annotateAttachmentError
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                    lineNumber: 394,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
            lineNumber: 355,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-testid": "automation-right-sidebar",
        className: (mobileChatOpen || showChat ? 'flex min-w-0 flex-col ' : 'hidden ') + (mobileChatOpen ? 'fixed inset-0 z-50 h-dvh w-full bg-[#f5f7f8] p-2 ' : '') + (showChat ? 'lg:static lg:z-auto lg:flex lg:h-full lg:min-h-0 lg:w-full lg:overflow-hidden lg:bg-transparent lg:p-0 lg:shadow-none ' : 'lg:hidden ') + (mobileChatOpen ? '' : 'max-lg:hidden'),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "mb-2 inline-flex min-h-10 items-center justify-end gap-2 self-end px-2 text-xs font-semibold text-slate-700 lg:hidden",
                onClick: onClose,
                "aria-label": "Close operator chat",
                children: [
                    "Close",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                        className: "size-4",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 427,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                lineNumber: 420,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                "data-testid": "mator-chat",
                className: "flex min-h-0 flex-1 flex-col overflow-hidden border-slate-200/80 bg-white shadow-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex shrink-0 items-center gap-1 border-b border-slate-100 px-2.5 pt-2.5 pb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                                open: threadOpen,
                                onOpenChange: setThreadOpen,
                                "aria-label": "Thread history",
                                contentClassName: "w-[min(calc(100vw-1.5rem),21rem)]",
                                className: "min-w-0 flex-1",
                                trigger: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "aria-haspopup": "dialog",
                                    "aria-expanded": threadOpen,
                                    "data-testid": "mator-thread-pill",
                                    onClick: ()=>setThreadOpen((value)=>!value),
                                    className: "group flex min-h-11 min-w-0 flex-1 cursor-pointer items-center gap-2 rounded-2xl bg-slate-50 px-3 py-1.5 text-left transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex size-7 shrink-0 items-center justify-center rounded-full bg-white text-teal-800 ring-1 ring-slate-200",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__["MessageSquare"], {
                                                className: "size-3.5",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                lineNumber: 451,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 450,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "min-w-0 flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block truncate text-[13px] leading-4 font-semibold text-slate-800",
                                                    children: threadTitle
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 454,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mt-0.5 flex items-center gap-1.5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                            tone: "outline",
                                                            size: "xs",
                                                            children: PANE_LABEL[pane] ?? 'Thread'
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 458,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "truncate text-[10px] text-slate-400",
                                                            children: threadList.length > 0 ? `${threadList.length} thread${threadList.length === 1 ? '' : 's'}` : 'No earlier threads'
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 461,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 457,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 453,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 442,
                                    columnNumber: 15
                                }, this),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    "aria-label": "Threads in this workflow",
                                    "data-testid": "mator-conversation-switcher",
                                    className: "flex flex-col",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between px-2 pt-1 pb-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[10px] font-bold tracking-wider text-slate-400 uppercase",
                                                    children: "This workflow"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 477,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    "data-testid": "mator-new-conversation",
                                                    disabled: !onNewConversation || busy,
                                                    onClick: ()=>{
                                                        onNewConversation?.();
                                                        setThreadOpen(false);
                                                    },
                                                    className: "inline-flex min-h-11 cursor-pointer items-center gap-1 rounded-full bg-slate-900 px-2.5 text-[11px] font-bold text-white transition-colors hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                            className: "size-3",
                                                            "aria-hidden": "true"
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 490,
                                                            columnNumber: 19
                                                        }, this),
                                                        "New chat"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 480,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 476,
                                            columnNumber: 15
                                        }, this),
                                        threadList.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "px-2 pt-1 pb-2 text-xs text-slate-400",
                                            children: "No threads yet — start the first one below."
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 495,
                                            columnNumber: 17
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "flex max-h-56 flex-col gap-0.5 overflow-y-auto",
                                            children: threadList.map((item)=>{
                                                const current = item.id === conversationMeta?.id;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        "aria-current": current ? 'true' : undefined,
                                                        disabled: !onSwitchConversation || current,
                                                        onClick: ()=>{
                                                            onSwitchConversation?.(item.id);
                                                            setThreadOpen(false);
                                                        },
                                                        className: 'flex w-full items-baseline justify-between gap-3 rounded-xl px-2.5 py-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:opacity-100 motion-reduce:transition-none ' + (current ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:bg-slate-50/80 hover:text-slate-700'),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "min-w-0 flex-1 space-y-0.5",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "block truncate text-[13px] font-medium",
                                                                        children: item.title || 'Conversation'
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 520,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "block text-[10px] text-slate-400",
                                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["threadWhen"])(item.createdAt)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 523,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 519,
                                                                columnNumber: 27
                                                            }, this),
                                                            current ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                tone: "teal",
                                                                size: "xs",
                                                                children: "Now"
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 528,
                                                                columnNumber: 29
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "shrink-0 text-[11px] text-slate-400",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["threadWhen"])(item.updatedAt)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 532,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 504,
                                                        columnNumber: 25
                                                    }, this)
                                                }, item.id, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 503,
                                                    columnNumber: 23
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 499,
                                            columnNumber: 17
                                        }, this),
                                        showRestore && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "border-t border-slate-100 px-2 pt-2 pb-1",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                "data-testid": "mator-restore-pipeline",
                                                disabled: !onRestorePipeline || busy,
                                                onClick: ()=>{
                                                    onRestorePipeline?.();
                                                    setThreadOpen(false);
                                                },
                                                className: "inline-flex min-h-9 w-full cursor-pointer items-center gap-1.5 rounded-xl px-2 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-50 hover:text-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__["RotateCcw"], {
                                                        className: "size-3.5",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 554,
                                                        columnNumber: 21
                                                    }, this),
                                                    "Restore pipeline"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                lineNumber: 544,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 543,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 471,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 435,
                                columnNumber: 11
                            }, this),
                            call.active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$listener$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MatorCallControls"], {
                                call: call
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 561,
                                columnNumber: 27
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onClose,
                                "aria-label": "Hide Mator chat",
                                "data-testid": "mator-hide",
                                className: "inline-flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    className: "size-4",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 569,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 562,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 434,
                        columnNumber: 9
                    }, this),
                    pane === 'growth' && selectedCraftSlug && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        "data-testid": "active-craft-context",
                        className: "shrink-0 px-4 pt-1.5 pb-1.5 text-[11px] text-slate-500",
                        children: [
                            "Craft",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>onMessageChange('/craft help'),
                                className: "cursor-pointer font-mono text-slate-700 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                children: selectedCraftSlug
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 579,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 574,
                        columnNumber: 11
                    }, this),
                    growthExecution && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$pipeline$2d$execution$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MatorPipelineExecution"], {
                        execution: growthExecution,
                        title: growthExecutionTitle,
                        error: growthExecutionError,
                        busy: growthExecutionBusy,
                        onDecision: onGrowthDecision,
                        onInput: onGrowthInput
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 590,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerProvider"], {
                        autoScroll: true,
                        defaultScrollPosition: "end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScroller"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerViewport"], {
                                    "aria-label": "Thread history",
                                    "data-testid": "mator-thread-viewport",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerContent"], {
                                        className: "gap-4 px-3 py-3",
                                        children: [
                                            (()=>{
                                                const rows = [];
                                                let lastRun = null;
                                                let steps = [];
                                                const flush = (key)=>{
                                                    if (steps.length === 0) return;
                                                    const runId = steps[0]?.runId ?? null;
                                                    rows.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$checkpoint$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkpoint"], {
                                                        label: "Run segment",
                                                        runId: runId,
                                                        time: steps[0]?.time ?? null
                                                    }, `checkpoint-${key}`, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 616,
                                                        columnNumber: 23
                                                    }, this));
                                                    // Screenshot evidence stays clickable for the current run.
                                                    const capture = steps.find((event)=>event.kind === 'screenshot' && typeof event.details?.fileName === 'string' && /^[a-zA-Z0-9_-]+\.png$/.test(event.details.fileName) && event.runId === currentRunId);
                                                    rows.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerItem"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$task$2d$block$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TaskBlock"], {
                                                            steps: steps,
                                                            evidence: capture ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScreenshotEvidence, {
                                                                event: capture,
                                                                onAnnotate: onAnnotateCapture
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 637,
                                                                columnNumber: 31
                                                            }, this) : null
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 633,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, `task-${key}`, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 632,
                                                        columnNumber: 23
                                                    }, this));
                                                    steps = [];
                                                };
                                                for (const event of events){
                                                    if (lastRun !== null && event.runId !== lastRun) {
                                                        flush(String(event.id));
                                                    }
                                                    lastRun = event.runId;
                                                    steps.push(event);
                                                }
                                                flush(String(lastRun ?? 'events'));
                                                return rows;
                                            })(),
                                            reviews.filter((r)=>r.platform === platform && r.handle.toLowerCase() === normalizedHandle.toLowerCase()).map((review)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerItem"], {
                                                    messageId: `review-${review.id}`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                className: "bg-teal-800 text-white",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__["Workflow"], {
                                                                        className: "size-4",
                                                                        "aria-hidden": "true"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 673,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 672,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 671,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                className: "max-w-[min(90%,34rem)] min-w-0 [overflow-wrap:anywhere] break-words",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageHeader"], {
                                                                        children: [
                                                                            "Saved visual review · ",
                                                                            review.nodeId,
                                                                            " node"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 677,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        "data-testid": "saved-visual-review",
                                                                        className: "w-fit max-w-[min(100%,18rem)] overflow-hidden rounded-xl border border-teal-200 bg-teal-50/40",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "flex items-center justify-between gap-2 border-b border-teal-100 bg-teal-50/80 px-3 py-2",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                                        tone: "teal",
                                                                                        size: "xs",
                                                                                        children: [
                                                                                            review.regions.length,
                                                                                            " marked region",
                                                                                            review.regions.length === 1 ? '' : 's'
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                        lineNumber: 685,
                                                                                        columnNumber: 31
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                        type: "button",
                                                                                        onClick: ()=>onInspectReview(review),
                                                                                        className: "inline-flex cursor-pointer items-center gap-1 text-[11px] font-bold text-teal-800 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                                                                        children: "Inspect this page"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                        lineNumber: 689,
                                                                                        columnNumber: 31
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 684,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                type: "button",
                                                                                onClick: ()=>onEditReview(review),
                                                                                "aria-label": `Edit annotated image ${review.id}`,
                                                                                className: "relative block w-full cursor-pointer overflow-hidden bg-slate-50 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$review$2d$image$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReviewImage"], {
                                                                                        review: review,
                                                                                        src: reviewImage(review)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                        lineNumber: 704,
                                                                                        columnNumber: 31
                                                                                    }, this),
                                                                                    review.annotations?.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "space-y-1 border-t border-teal-100 bg-white px-3 py-2.5",
                                                                                        children: [
                                                                                            review.annotations.map((a, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                                    className: "text-[11px] text-slate-600",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                            children: [
                                                                                                                index + 1,
                                                                                                                ".",
                                                                                                                ' ',
                                                                                                                a.action.replaceAll('-', ' ')
                                                                                                            ]
                                                                                                        }, void 0, true, {
                                                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                                            lineNumber: 715,
                                                                                                            columnNumber: 39
                                                                                                        }, this),
                                                                                                        a.comment ? ` · ${a.comment}` : ''
                                                                                                    ]
                                                                                                }, a.id, true, {
                                                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                                    lineNumber: 711,
                                                                                                    columnNumber: 37
                                                                                                }, this)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                                className: "pt-1 text-[10px] leading-4 text-slate-400",
                                                                                                children: "Tagged instructions are linked to the workflow; they cannot execute unapproved browser actions."
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                                lineNumber: 722,
                                                                                                columnNumber: 35
                                                                                            }, this)
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                        lineNumber: 709,
                                                                                        columnNumber: 33
                                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "border-t border-teal-100 bg-white px-3 py-2 text-[10px] text-slate-400",
                                                                                        children: "Earlier image review. Click the image to add detailed actions and comments."
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                        lineNumber: 729,
                                                                                        columnNumber: 33
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 697,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 680,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 676,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 670,
                                                        columnNumber: 23
                                                    }, this)
                                                }, `review-${review.id}`, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 666,
                                                    columnNumber: 21
                                                }, this)),
                                            visibleMatorEvents.length === 0 ? loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadSkeleton"], {}, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                lineNumber: 742,
                                                columnNumber: 21
                                            }, this) : conversation.some((item)=>item.id !== 'seed') ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-testid": "mator-empty-thread",
                                                className: "flex min-h-56 flex-col justify-center gap-4 px-3 py-8",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$assistant$2d$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssistantAvatar"], {}, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 749,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-sm font-semibold text-slate-900",
                                                                        children: "What would you like to do?"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 751,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "mt-0.5 text-xs leading-relaxed text-slate-500",
                                                                        children: "Ask Mator for help with this workflow, or start with a suggestion."
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 754,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 750,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 748,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$suggestion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suggestion"], {
                                                        suggestions: START_SUGGESTIONS,
                                                        onSelect: onMessageChange,
                                                        disabled: busy
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 760,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                lineNumber: 744,
                                                columnNumber: 21
                                            }, this) : visibleMatorEvents.map((event)=>{
                                                if (event.kind === 'message' && event.role === 'user') {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        side: "end",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                            align: "end",
                                                            className: "ml-auto w-full justify-end",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                    className: "ml-auto flex w-fit max-w-[min(82%,28rem)] min-w-0 flex-none flex-col items-end",
                                                                    children: [
                                                                        event.text?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bubble"], {
                                                                            variant: "muted",
                                                                            className: "ml-auto w-fit max-w-full text-left [overflow-wrap:anywhere] break-words whitespace-pre-wrap",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BubbleContent"], {
                                                                                children: event.text
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 782,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 778,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        attachmentFor(event)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 776,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                    className: "bg-slate-800 text-white",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                                        children: "ME"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 788,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 787,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 772,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 771,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.kind === 'how') {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: !event.text ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$reasoning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Reasoning"], {
                                                            className: "w-fit max-w-[min(100%,30rem)]",
                                                            title: "Guidance from Mator",
                                                            content: event.text,
                                                            speakLabel: "Read this guidance aloud",
                                                            onSpeak: ()=>voice.speak(event.text, true)
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 799,
                                                            columnNumber: 29
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 797,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.kind === 'message') {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$assistant$2d$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssistantAvatar"], {}, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 815,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                    className: "max-w-[min(90%,34rem)] min-w-0 [overflow-wrap:anywhere] break-words",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageHeader"], {
                                                                            children: "Utomator · Mator"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 817,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$markdown$2d$reply$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkdownReply"], {
                                                                            text: event.text ?? ''
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 818,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageFooter"], {
                                                                            className: "mt-1.5 flex items-center gap-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    type: "button",
                                                                                    onClick: ()=>void copyReply(event),
                                                                                    "aria-label": "Copy reply",
                                                                                    className: "inline-flex h-7 cursor-pointer items-center gap-1 rounded-lg px-1.5 text-[11px] font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                                                                    children: [
                                                                                        copiedId === event.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__["CircleCheck"], {
                                                                                            className: "size-3.5",
                                                                                            "aria-hidden": "true"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                            lineNumber: 827,
                                                                                            columnNumber: 37
                                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$copy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCopy$3e$__["ClipboardCopy"], {
                                                                                            className: "size-3.5",
                                                                                            "aria-hidden": "true"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                            lineNumber: 832,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        copiedId === event.id ? 'Copied' : 'Copy'
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                    lineNumber: 820,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    type: "button",
                                                                                    onClick: ()=>voice.speak(event.text ?? '', true),
                                                                                    "aria-label": "Hear this reply",
                                                                                    className: "inline-flex h-7 cursor-pointer items-center gap-1 rounded-lg px-1.5 text-[11px] font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                                                                            className: "size-3.5",
                                                                                            "aria-hidden": "true"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                            lineNumber: 847,
                                                                                            columnNumber: 35
                                                                                        }, this),
                                                                                        "Hear this"
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                    lineNumber: 839,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 819,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 816,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 814,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 813,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.kind === 'clarify') {
                                                    const questions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readClarifyQuestions"])(event.action);
                                                    const open = openClarify?.id === event.id && questions;
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                    className: "bg-teal-50 text-teal-800 ring-1 ring-teal-200",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__["Workflow"], {
                                                                            className: "size-3.5",
                                                                            "aria-hidden": "true"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 868,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 867,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 866,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                    className: "max-w-[min(90%,34rem)] min-w-0 [overflow-wrap:anywhere] break-words",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageHeader"], {
                                                                            children: "Mator"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 875,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex flex-wrap items-center gap-1.5",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                                tone: open ? 'orange' : 'default',
                                                                                size: "xs",
                                                                                children: open ? `Answers needed · ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clarifyCount"])(questions)} question${(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clarifyCount"])(questions) === 1 ? '' : 's'}` : 'Clarified'
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 877,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 876,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        event.text && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bubble"], {
                                                                            variant: "outline",
                                                                            className: "mt-1 w-fit max-w-full [overflow-wrap:anywhere] break-words",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BubbleContent"], {
                                                                                children: event.text
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 891,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 887,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 874,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 865,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 864,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.kind === 'action' && typeof event.action === 'object' && event.action !== null && 'type' in event.action && event.action.type === 'explain_how') {
                                                    return event.text ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$reasoning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Reasoning"], {
                                                            className: "w-fit max-w-[min(100%,30rem)]",
                                                            title: "Guidance from Mator",
                                                            content: event.text,
                                                            speakLabel: "Read this guidance aloud",
                                                            onSpeak: ()=>voice.speak(event.text, true)
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 909,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 908,
                                                        columnNumber: 25
                                                    }, this) : null;
                                                }
                                                if (event.status || event.action) {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$confirmation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Confirmation"], {
                                                            className: "w-fit max-w-[min(100%,30rem)] min-w-0",
                                                            status: (event.status === 'staged' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stageResolution"])(orderedMatorEvents, event.id) ?? 'staged' : event.status) ?? 'staged',
                                                            action: event.action && typeof event.action === 'object' && 'type' in event.action ? String(event.action.type).replaceAll('_', ' ') : event.text ? event.text.slice(0, 48) : null,
                                                            text: event.action ? event.text : null,
                                                            attachment: attachmentFor(event),
                                                            onConfirm: ()=>onConfirm(event.id),
                                                            onReject: ()=>onReject?.(event.id),
                                                            busy: busy
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 923,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 922,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.attachmentId || event.attachments?.length) {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: attachmentFor(event)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 961,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                if (event.text) {
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThreadRow"], {
                                                        id: event.id,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                    className: event.status === 'error' ? 'bg-rose-700 text-white' : 'bg-slate-700 text-white',
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                                        children: event.status === 'error' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                                                            className: "size-4",
                                                                            "aria-hidden": "true"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 980,
                                                                            columnNumber: 35
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$workflow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Workflow$3e$__["Workflow"], {
                                                                            className: "size-4",
                                                                            "aria-hidden": "true"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 985,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 978,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 971,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                    className: "max-w-[min(90%,34rem)] min-w-0 [overflow-wrap:anywhere] break-words",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageHeader"], {
                                                                            children: (event.kind || 'event').toUpperCase()
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 993,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bubble"], {
                                                                            className: "w-fit max-w-full [overflow-wrap:anywhere] break-words whitespace-pre-wrap",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BubbleContent"], {
                                                                                children: event.text
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                                lineNumber: 997,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                            lineNumber: 996,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 992,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                            lineNumber: 970,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, event.id, false, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 969,
                                                        columnNumber: 25
                                                    }, this);
                                                }
                                                return null;
                                            }),
                                            visibleMatorEvents.length === 0 && conversation.filter((item)=>item.id !== 'seed').map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerItem"], {
                                                    messageId: String(item.id),
                                                    className: item.sender === 'user' ? 'flex w-full justify-end' : 'w-full',
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Message"], {
                                                        align: item.sender === 'user' ? 'end' : 'start',
                                                        className: item.sender === 'user' ? 'ml-auto w-full justify-end' : 'mr-auto w-full justify-start',
                                                        children: [
                                                            item.sender === 'assistant' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$assistant$2d$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AssistantAvatar"], {}, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 1031,
                                                                columnNumber: 59
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageContent"], {
                                                                className: item.sender === 'user' ? 'ml-auto flex w-fit max-w-[min(82%,28rem)] min-w-0 flex-none flex-col items-end' : 'max-w-[min(90%,34rem)] min-w-0',
                                                                children: item.sender === 'user' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bubble"], {
                                                                    variant: "muted",
                                                                    className: "ml-auto w-fit max-w-full text-left [overflow-wrap:anywhere] break-words whitespace-pre-wrap",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$bubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BubbleContent"], {
                                                                        children: item.text
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                        lineNumber: 1044,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 1040,
                                                                    columnNumber: 31
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$markdown$2d$reply$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MarkdownReply"], {
                                                                    text: item.text
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 1047,
                                                                    columnNumber: 31
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 1032,
                                                                columnNumber: 27
                                                            }, this),
                                                            item.sender === 'user' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                                className: "bg-slate-800 text-white",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                                    children: "ME"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                    lineNumber: 1052,
                                                                    columnNumber: 31
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                                lineNumber: 1051,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                        lineNumber: 1023,
                                                        columnNumber: 25
                                                    }, this)
                                                }, item.id, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 1014,
                                                    columnNumber: 23
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                        lineNumber: 607,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 603,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$message$2d$scroller$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MessageScrollerButton"], {}, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 1060,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                            lineNumber: 602,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 601,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                        initial: false,
                        children: openClarify && clarifyQuestions && !call.active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: reduceMotion ? {
                                opacity: 1
                            } : {
                                opacity: 0,
                                y: 12
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            exit: reduceMotion ? {
                                opacity: 1
                            } : {
                                opacity: 0,
                                y: 8
                            },
                            transition: {
                                duration: 0.2,
                                ease: 'easeOut'
                            },
                            "data-testid": "mator-clarify-card",
                            className: "mx-2 mb-1 shrink-0 rounded-2xl border border-orange-200 bg-white shadow-[0_12px_32px_-16px_rgba(0,0,0,.25)]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between gap-2 border-b border-orange-100 bg-orange-50/60 px-3.5 py-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5 text-[11px] font-bold tracking-wide text-orange-900 uppercase",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                                    className: "size-3.5 animate-spin",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                                    lineNumber: 1078,
                                                    columnNumber: 19
                                                }, this),
                                                "Mator needs clarity"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 1077,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                            tone: "orange",
                                            size: "xs",
                                            children: [
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clarifyCount"])(clarifyQuestions),
                                                " question",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$chat$2f$mator$2d$thread$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clarifyCount"])(clarifyQuestions) === 1 ? '' : 's'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                            lineNumber: 1084,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 1076,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "px-3.5 py-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$clarify$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        questions: clarifyQuestions,
                                        disabled: busy,
                                        onUploadFile: onUploadClarifyFile,
                                        onSubmit: (text, attachmentIds)=>onSendText?.(text, attachmentIds)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                        lineNumber: 1090,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 1089,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, "clarify-card", true, {
                            fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                            lineNumber: 1067,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1065,
                        columnNumber: 9
                    }, this),
                    call.active && call.question && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "mator-call-question",
                        role: "group",
                        "aria-label": `Clarification question ${call.question.index} of ${call.question.total}`,
                        className: "mx-2 mb-2 rounded-2xl border border-teal-100 bg-white/75 p-3 backdrop-blur-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-teal-900",
                                children: [
                                    "Question ",
                                    call.question.index,
                                    " of ",
                                    call.question.total
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1110,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm font-medium leading-relaxed text-slate-900",
                                children: call.question.value.prompt
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1113,
                                columnNumber: 13
                            }, this),
                            call.state.phase === 'clarifying-voice' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-xs text-slate-600",
                                children: "Answer aloud. Mator will continue automatically."
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1117,
                                columnNumber: 15
                            }, this),
                            call.state.phase === 'clarifying-form' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$clarify$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    questions: [
                                        call.question.value
                                    ],
                                    onUploadFile: onUploadClarifyFile,
                                    onAnswerData: async (answers, ids)=>{
                                        await call.answerVisual(answers[call.question?.value.name] ?? [], ids);
                                        return true;
                                    }
                                }, call.question.value.name, false, {
                                    fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                    lineNumber: 1123,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1122,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1104,
                        columnNumber: 11
                    }, this),
                    (imageError || chatError) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "alert",
                        "data-testid": "mator-chat-error",
                        className: "mx-3 my-2 flex max-w-[min(100%,30rem)] min-w-0 items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 p-3 text-rose-900",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                className: "mt-0.5 size-4 shrink-0",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1146,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0 text-xs leading-relaxed",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-semibold",
                                        children: "Mator couldn't complete that request"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                        lineNumber: 1151,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 [overflow-wrap:anywhere] break-words",
                                        children: chatError && /\b(400|429|5\d\d|groq|bad request)\b/i.test(chatError) ? 'The AI service could not complete the request. Review your chat settings, then retry. Your draft is preserved.' : chatError || imageError
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                        lineNumber: 1154,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                                lineNumber: 1150,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1141,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$elements$2f$queue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Queue"], {
                        active: busy,
                        className: "px-4 pt-2 pb-0"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        call: call,
                        callReady: callReady,
                        voice: voice,
                        operatorPendingLabel: operatorPendingLabel,
                        onConfirmOperator: onConfirmOperator,
                        message: message,
                        onMessageChange: onMessageChange,
                        onSendMessage: onSendMessage,
                        onUploadFile: onUploadClarifyFile,
                        onSendText: onSendText,
                        onSaveMarkers: onSaveMarkers,
                        onAnnotateDraft: onAnnotateDraft && annotateChatImageAvailable ? onAnnotateDraft : undefined,
                        onPendingAssetsChange: onPendingAssetsChange,
                        busy: busy,
                        incomplete: incomplete,
                        onIncompleteContinue: onIncompleteContinue,
                        emptyThread: false,
                        models: models,
                        modelId: modelId,
                        onSettingsSaved: onSettingsSaved,
                        onModelChange: (selectedModelId)=>{
                            void onModelChange?.(selectedModelId).catch((cause)=>toast(cause instanceof Error ? cause.message : 'Unable to change chat model', 'error'));
                        }
                    }, conversationMeta?.id ?? 'no-conversation', false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1165,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                lineNumber: 429,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
        lineNumber: 407,
        columnNumber: 5
    }, this);
}
_s(OperatorChatPanel, "9rRBx+zF+E1xiR4B4MEbYOC+py8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = OperatorChatPanel;
/* Localized evidence rendering — workflow-screenshot test id stays here. */ function ScreenshotEvidence({ event, onAnnotate }) {
    const fileName = event.details?.fileName ?? '';
    const evidenceUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${event.runId}/evidence/${fileName}`);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        "data-testid": "workflow-screenshot",
        "data-evidence-url": evidenceUrl,
        onClick: ()=>onAnnotate(event.runId, fileName),
        "aria-label": `Annotate captured image: ${fileName}`,
        className: "block w-fit max-w-[min(100%,18rem)] cursor-pointer overflow-hidden rounded-xl border border-slate-200 bg-slate-50 text-left transition-colors hover:border-teal-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                unoptimized: true,
                src: evidenceUrl,
                width: 640,
                height: 400,
                alt: `Actual browser capture: ${event.message}`,
                className: "max-h-44 w-full object-contain"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                lineNumber: 1227,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-2 px-3 py-2 text-[11px] text-slate-500",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                        className: "size-3.5",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                        lineNumber: 1236,
                        columnNumber: 9
                    }, this),
                    fileName,
                    " · Click image to annotate"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
                lineNumber: 1235,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/mator/operator-chat-panel.tsx",
        lineNumber: 1219,
        columnNumber: 5
    }, this);
}
_c1 = ScreenshotEvidence;
var _c, _c1;
__turbopack_context__.k.register(_c, "OperatorChatPanel");
__turbopack_context__.k.register(_c1, "ScreenshotEvidence");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-call-questions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "beginQuestionFlow",
    ()=>beginQuestionFlow,
    "currentQuestion",
    ()=>currentQuestion,
    "provideQuestionAnswer",
    ()=>provideQuestionAnswer,
    "questionFlowSubmission",
    ()=>questionFlowSubmission,
    "requiresVisualAnswer",
    ()=>requiresVisualAnswer,
    "spokenQuestionAnswer",
    ()=>spokenQuestionAnswer
]);
function beginQuestionFlow(eventId, questions) {
    if (!eventId || !questions.length || new Set(questions.map((q)=>q.name)).size !== questions.length) {
        throw new Error('Clarification questions must have distinct IDs.');
    }
    return {
        eventId,
        questions,
        index: 0,
        answers: {},
        attachmentIds: []
    };
}
function currentQuestion(flow) {
    return flow.questions[flow.index] ?? null;
}
function requiresVisualAnswer(question) {
    return question.inputType === 'file' || question.inputType === 'url' || question.multiple || question.choices.length > 4;
}
function provideQuestionAnswer(flow, value, attachmentIds = []) {
    const question = currentQuestion(flow);
    if (!question) throw new Error('All questions were already answered.');
    const answer = value.map((v)=>v.trim()).filter(Boolean);
    if (question.required && answer.length === 0) throw new Error(`Answer ${question.prompt} first.`);
    if (!question.multiple && answer.length > 1) throw new Error('Only one answer is allowed.');
    if (question.choices.length && answer.some((v)=>!question.choices.some((c)=>c.value === v)) && !question.freeformLabel) {
        throw new Error(`Choose one of the listed options for ${question.prompt}.`);
    }
    if (question.inputType === 'url' && answer.length) {
        let url;
        try {
            url = new URL(answer[0]);
        } catch  {
            throw new Error(`Enter a valid URL for ${question.prompt}.`);
        }
        if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('Only HTTP and HTTPS URLs are accepted.');
        answer[0] = url.href;
    }
    if (question.inputType === 'file' && question.required && !attachmentIds.length) {
        throw new Error(`Upload a file for ${question.prompt}.`);
    }
    return {
        ...flow,
        index: flow.index + 1,
        answers: {
            ...flow.answers,
            [question.name]: answer
        },
        attachmentIds: [
            ...new Set([
                ...flow.attachmentIds,
                ...attachmentIds
            ])
        ]
    };
}
function questionFlowSubmission(flow) {
    if (flow.index !== flow.questions.length) throw new Error('The clarification is not complete.');
    const text = flow.questions.map((question)=>{
        const answer = flow.answers[question.name] ?? [];
        return `${question.prompt} ${answer.length ? answer.join(', ') : 'Skipped'}`;
    }).join('\n');
    return {
        text,
        attachmentIds: flow.attachmentIds
    };
}
function spokenQuestionAnswer(question, utterance) {
    const spoken = utterance.trim();
    if (!spoken || /^(skip|pass)$/i.test(spoken) && !question.required) return [];
    if (question.choices.length) {
        const match = question.choices.find((choice)=>choice.label.localeCompare(spoken, undefined, {
                sensitivity: 'base'
            }) === 0 || choice.value.localeCompare(spoken, undefined, {
                sensitivity: 'base'
            }) === 0);
        if (!match) throw new Error(`I didn't recognize a listed choice for ${question.prompt}.`);
        return [
            match.value
        ];
    }
    return [
        spoken
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-call-coordinator.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MatorCallCoordinator",
    ()=>MatorCallCoordinator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-call-questions.ts [app-client] (ecmascript)");
;
function sleep(signal, ms = 120) {
    return new Promise((resolve)=>{
        if (signal.aborted) {
            resolve();
            return;
        }
        const stop = ()=>{
            clearTimeout(t);
            resolve();
        };
        const t = setTimeout(()=>{
            signal.removeEventListener('abort', stop);
            resolve();
        }, ms);
        signal.addEventListener('abort', stop, {
            once: true
        });
    });
}
class MatorCallCoordinator {
    _phase = 'idle';
    _scope = null;
    _active = false;
    _generation = 0;
    _abort = null;
    _micMuted = false;
    _speakerMuted = false;
    _pausedByMute = false;
    _flow = null;
    _blockedStageIds = [];
    _nextAudio = null;
    ports;
    constructor(ports){
        this.ports = ports;
    }
    get phase() {
        return this._phase;
    }
    get active() {
        return this._active;
    }
    get scope() {
        return this._scope;
    }
    get micMuted() {
        return this._micMuted;
    }
    get speakerMuted() {
        return this._speakerMuted;
    }
    get question() {
        return this._flow ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentQuestion"])(this._flow) : null;
    }
    emit(phase, detail = '') {
        this._phase = phase;
        this.ports.onState({
            phase,
            detail,
            scope: this._scope,
            micMuted: this._micMuted,
            speakerMuted: this._speakerMuted
        });
    }
    current(token, signal) {
        return this._active && this._generation === token && !signal.aborted;
    }
    start(scope) {
        if (this._active) return;
        if (!scope.trim()) throw new Error('Select a workflow conversation before calling.');
        this._active = true;
        this._scope = scope;
        this._micMuted = false;
        this._pausedByMute = false;
        this._flow = null;
        this._blockedStageIds = [];
        this._nextAudio = null;
        this.emit('connecting');
        this.beginLoop();
    }
    beginLoop() {
        if (!this._active || this._micMuted || !this._scope) return;
        const token = ++this._generation;
        const controller = new AbortController();
        this._abort = controller;
        void this.loop(token, controller.signal);
    }
    async speak(text, signal) {
        if (!text.trim() || this._speakerMuted) return null;
        this.emit('speaking');
        return await this.ports.speak(text, signal) ?? null;
    }
    async collectSpokenAnswer(signal, initial) {
        const audio = initial ?? await this.ports.capture(signal);
        if (!audio?.size) return '';
        return (await this.ports.transcribe(audio, signal)).trim();
    }
    async handleClarification(flow, token, signal) {
        this._flow = flow;
        while(this.current(token, signal) && this._flow){
            const question = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentQuestion"])(this._flow);
            if (!question) {
                const completed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["questionFlowSubmission"])(this._flow);
                this._flow = null;
                this.ports.onQuestion?.(null, 0, 0);
                this.emit('thinking', 'Sending your clarification…');
                // Exactly one persisted response, even for multiple spoken questions.
                const result = await this.ports.respond(completed.text, {
                    scope: this._scope,
                    signal,
                    attachmentIds: completed.attachmentIds
                });
                if (this.current(token, signal)) this.ports.onTurn?.({
                    transcript: completed.text,
                    result
                });
                return result;
            }
            this.ports.onQuestion?.(question, this._flow.index + 1, this._flow.questions.length);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requiresVisualAnswer"])(question)) {
                this.emit('clarifying-form', `Answer question ${this._flow.index + 1} in the questionnaire.`);
                return null;
            }
            this.emit('clarifying-voice', question.prompt);
            const interrupt = await this.speak(question.prompt, signal);
            if (!this.current(token, signal)) return null;
            this.emit('clarifying-voice', question.prompt);
            let accepted = false;
            for(let attempts = 0; attempts < 2 && !accepted; attempts++){
                const answer = await this.collectSpokenAnswer(signal, attempts === 0 ? interrupt : null);
                if (!this.current(token, signal)) return null;
                try {
                    const values = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["spokenQuestionAnswer"])(question, answer);
                    this._flow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["provideQuestionAnswer"])(this._flow, values);
                    this.ports.onQuestionAnswer?.(question, values.join(', ') || 'Skipped');
                    accepted = true;
                } catch  {
                    if (attempts === 1) {
                        this.emit('error-paused', 'Please answer this question in the visible questionnaire.');
                        return null;
                    }
                    await this.speak('Sorry, could you repeat that?', signal);
                }
            }
        }
        return null;
    }
    async consumeResult(initial, token, signal) {
        let result = initial;
        for(let round = 0; round < 5 && this.current(token, signal); round++){
            if (result.stagedEventIds?.length) {
                this._blockedStageIds = result.stagedEventIds;
                this.emit('awaiting-approval', 'Review each proposed workflow change on screen.');
                return null;
            }
            if (result.clarification) {
                const next = await this.handleClarification((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["beginQuestionFlow"])(result.clarification.eventId, result.clarification.questions), token, signal);
                if (!next || !this.current(token, signal)) return null;
                result = next;
                continue;
            }
            if (result.requiresAttention) {
                this.emit('needs-attention', 'Mator needs your input in the conversation.');
                return null;
            }
            return await this.speak(result.reply, signal);
        }
        if (this.current(token, signal)) this.emit('error-paused', 'Mator asked too many follow-up questions. Review the transcript.');
        return null;
    }
    async loop(token, signal) {
        let pendingAudio = this._nextAudio;
        this._nextAudio = null;
        while(this.current(token, signal)){
            try {
                if (this._micMuted) {
                    this.emit('paused');
                    return;
                }
                let audio = pendingAudio;
                pendingAudio = null;
                if (!audio) {
                    this.emit('listening');
                    audio = await this.ports.capture(signal);
                }
                if (!this.current(token, signal)) return;
                if (!audio?.size) {
                    await sleep(signal);
                    continue;
                }
                this.emit('transcribing');
                const transcript = (await this.ports.transcribe(audio, signal)).trim();
                if (!this.current(token, signal)) return;
                if (!transcript) continue;
                this.ports.onTranscript?.(transcript);
                this.emit('thinking');
                const result = await this.ports.respond(transcript, {
                    scope: this._scope,
                    signal
                });
                if (!this.current(token, signal)) return;
                this.ports.onTurn?.({
                    transcript,
                    result
                });
                pendingAudio = await this.consumeResult(result, token, signal);
                if (!this.current(token, signal)) return;
                if ([
                    'awaiting-approval',
                    'clarifying-form',
                    'needs-attention',
                    'error-paused'
                ].includes(this._phase)) return;
            } catch  {
                if (this.current(token, signal)) this.emit('error-paused', 'Mator could not finish that turn. Check the transcript and retry.');
                return;
            }
        }
    }
    /** Called by the visible one-question structured form only on successful validation. */ async answerVisual(value, attachmentIds = []) {
        if (this._phase !== 'clarifying-form' || !this._flow || !this._scope) return;
        try {
            this._flow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["provideQuestionAnswer"])(this._flow, value, attachmentIds);
            this.ports.onQuestion?.((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentQuestion"])(this._flow), this._flow.index + 1, this._flow.questions.length);
            if (this._micMuted) {
                this.emit('paused', 'Unmute and resume the call to continue.');
                return;
            }
            this.emit('connecting');
            this.beginLoopFromQuestions();
        } catch (error) {
            this.emit('clarifying-form', error instanceof Error ? error.message : 'Check your answer.');
            throw error;
        }
    }
    beginLoopFromQuestions() {
        if (!this._active || this._micMuted) return;
        const token = ++this._generation;
        this._abort?.abort();
        const controller = new AbortController();
        this._abort = controller;
        void (async ()=>{
            try {
                if (!this._flow) return;
                const next = await this.handleClarification(this._flow, token, controller.signal);
                if (!next || !this.current(token, controller.signal)) return;
                const captured = await this.consumeResult(next, token, controller.signal);
                if (!this.current(token, controller.signal)) return;
                if ([
                    'awaiting-approval',
                    'clarifying-form',
                    'needs-attention',
                    'error-paused'
                ].includes(this._phase)) return;
                this._nextAudio = captured;
                this.beginLoop();
            } catch  {
                if (this.current(token, controller.signal)) this.emit('error-paused', 'Clarification could not be submitted. Review your answers.');
            }
        })();
    }
    /** The caller must await actual confirm/reject API success before this signal. */ async stageDecisionSucceeded(eventId, decision) {
        if (!this._active || this._phase !== 'awaiting-approval') return;
        this._blockedStageIds = this._blockedStageIds.filter((id)=>id !== eventId);
        if (this._blockedStageIds.length) return;
        if (this._micMuted) {
            this.emit('paused');
            return;
        }
        const token = ++this._generation;
        this._abort?.abort();
        const controller = new AbortController();
        this._abort = controller;
        try {
            const next = await this.speak(decision === 'confirm' ? 'Change approved.' : 'Change rejected.', controller.signal);
            if (this.current(token, controller.signal)) {
                this._nextAudio = next;
                this.beginLoop();
            }
        } catch  {
            if (this.current(token, controller.signal)) this.emit('error-paused', 'Could not play the confirmation.');
        }
    }
    pause() {
        if (!this._active || this._phase === 'paused') return;
        this._generation++;
        this._abort?.abort();
        this._abort = null;
        this.ports.stopOutput();
        this.emit('paused');
    }
    resume() {
        if (!this._active || this._micMuted || ![
            'paused',
            'error-paused',
            'needs-attention'
        ].includes(this._phase)) return;
        if (this._blockedStageIds.length) {
            this.emit('awaiting-approval', 'Confirm or reject the pending change on screen.');
            return;
        }
        this._pausedByMute = false;
        this.emit('connecting');
        if (this._flow) this.beginLoopFromQuestions();
        else this.beginLoop();
    }
    setMicMuted(muted) {
        if (this._micMuted === muted) return;
        this._micMuted = muted;
        if (!this._active) return;
        if (muted) {
            this._pausedByMute = ![
                'paused',
                'error-paused',
                'needs-attention',
                'awaiting-approval',
                'clarifying-form'
            ].includes(this._phase);
            if (this._pausedByMute) this.pause();
            else this.emit(this._phase);
        } else if (this._pausedByMute) {
            this._pausedByMute = false;
            this.resume();
        } else this.emit(this._phase);
    }
    setSpeakerMuted(muted) {
        this._speakerMuted = muted;
        if (muted && this._phase === 'speaking') {
            this._generation++;
            this._abort?.abort();
            this.ports.stopOutput();
            this.emit('connecting');
            if (this._active && !this._micMuted) this.beginLoop();
        } else if (this._active) this.emit(this._phase);
    }
    interrupt() {
        if (!this._active || this._phase !== 'speaking') return;
        this._generation++;
        this._abort?.abort();
        this.ports.stopOutput();
        if (this._micMuted) this.emit('paused');
        else {
            this.emit('connecting');
            this.beginLoop();
        }
    }
    changeScope(next) {
        if (this._active && this._scope !== next) this.end();
    }
    end() {
        if (!this._active) return;
        this._generation++;
        this._active = false;
        this._abort?.abort();
        this._abort = null;
        this.ports.stopOutput();
        this._scope = null;
        this._flow = null;
        this._blockedStageIds = [];
        this._nextAudio = null;
        this._pausedByMute = false;
        this.ports.onQuestion?.(null, 0, 0);
        this.emit('ended');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-call-capture.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Browser-only, bounded speech-turn capture for Mator AI Call. */ __turbopack_context__.s([
    "VoiceActivityGate",
    ()=>VoiceActivityGate,
    "captureMatorCallTurn",
    ()=>captureMatorCallTurn,
    "sampleRms",
    ()=>sampleRms
]);
class VoiceActivityGate {
    spokenMs = 0;
    quietMs = 0;
    elapsedMs = 0;
    firstVoiceAt = null;
    options;
    constructor(options = {}){
        this.options = {
            threshold: options.threshold ?? 0.018,
            minSpeechMs: options.minSpeechMs ?? 180,
            endSilenceMs: options.endSilenceMs ?? 900,
            maxWaitMs: options.maxWaitMs ?? 12000,
            maxTurnMs: options.maxTurnMs ?? 25000
        };
    }
    feed(level, deltaMs) {
        const elapsed = Math.max(0, Math.min(200, deltaMs));
        this.elapsedMs += elapsed;
        if (level >= this.options.threshold) {
            if (this.firstVoiceAt === null) this.firstVoiceAt = this.elapsedMs;
            this.lastVoiceAt = this.elapsedMs;
            this.spokenMs += elapsed;
            this.quietMs = 0;
        } else if (this.firstVoiceAt !== null) {
            this.quietMs += elapsed;
        }
        if (this.firstVoiceAt === null) {
            return this.elapsedMs >= this.options.maxWaitMs ? 'empty' : 'waiting';
        }
        if (this.elapsedMs - this.firstVoiceAt >= this.options.maxTurnMs) {
            return this.spokenMs >= this.options.minSpeechMs ? 'stop' : 'empty';
        }
        if (this.spokenMs >= this.options.minSpeechMs && this.quietMs >= this.options.endSilenceMs) return 'stop';
        if (this.spokenMs < this.options.minSpeechMs && this.quietMs >= this.options.endSilenceMs) {
            // A click/cough is not a conversational turn.
            this.firstVoiceAt = null;
            this.spokenMs = 0;
            this.quietMs = 0;
        }
        return 'speech';
    }
}
function sampleRms(samples) {
    if (samples.length === 0) return 0;
    let total = 0;
    for(let i = 0; i < samples.length; i++)total += samples[i] * samples[i];
    return Math.sqrt(total / samples.length);
}
function abortError() {
    const error = new Error('Call recording was cancelled.');
    error.name = 'AbortError';
    return error;
}
async function acquireMicrophone(signal) {
    if (signal.aborted) throw abortError();
    const acquire = navigator.mediaDevices.getUserMedia({
        audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
        }
    });
    return new Promise((resolve, reject)=>{
        let settled = false;
        const onAbort = ()=>{
            if (settled) return;
            settled = true;
            reject(abortError());
        };
        signal.addEventListener('abort', onAbort, {
            once: true
        });
        acquire.then((stream)=>{
            signal.removeEventListener('abort', onAbort);
            if (settled || signal.aborted) {
                stream.getTracks().forEach((track)=>track.stop());
                return;
            }
            settled = true;
            resolve(stream);
        }, (error)=>{
            signal.removeEventListener('abort', onAbort);
            if (settled) return;
            settled = true;
            reject(error);
        });
    });
}
async function captureMatorCallTurn(signal, onLevel = ()=>{}) {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || typeof MediaRecorder === 'undefined' || typeof AudioContext === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        throw new Error('Automatic voice calls need microphone and Web Audio support in this browser.');
    }
    const stream = await acquireMicrophone(signal);
    let context = null;
    let source = null;
    let timer = null;
    let recorder = null;
    try {
        if (signal.aborted) return null;
        context = new AudioContext();
        source = context.createMediaStreamSource(stream);
        const analyser = context.createAnalyser();
        analyser.fftSize = 2048;
        source.connect(analyser);
        if (context.state === 'suspended') await context.resume();
        if (signal.aborted) return null;
        const samples = new Float32Array(analyser.fftSize);
        const gate = new VoiceActivityGate();
        const mime = [
            'audio/webm;codecs=opus',
            'audio/mp4',
            'audio/webm'
        ].find((candidate)=>MediaRecorder.isTypeSupported(candidate));
        recorder = mime ? new MediaRecorder(stream, {
            mimeType: mime
        }) : new MediaRecorder(stream);
        const media = recorder;
        const chunks = [];
        let bytes = 0;
        const audio = await new Promise((resolve, reject)=>{
            let settled = false;
            let completeWithAudio = false;
            let prevTime = performance.now();
            const cleanup = ()=>{
                if (timer !== null) {
                    clearInterval(timer);
                    timer = null;
                }
                signal.removeEventListener('abort', onAbort);
            };
            const finish = (includeAudio, error)=>{
                if (settled) return;
                completeWithAudio = includeAudio;
                if (error) {
                    settled = true;
                    cleanup();
                    reject(error);
                }
                if (media.state !== 'inactive') media.stop();
                else media.onstop?.(new Event('stop'));
            };
            const onAbort = ()=>finish(false);
            signal.addEventListener('abort', onAbort, {
                once: true
            });
            media.ondataavailable = (event)=>{
                if (event.data.size > 0) {
                    bytes += event.data.size;
                    chunks.push(event.data);
                }
                if (bytes > 16 * 1024 * 1024) finish(false, new Error('Audio turn exceeded the allowed capture size.'));
            };
            media.onerror = ()=>finish(false, new Error('The microphone recorder encountered an error.'));
            media.onstop = ()=>{
                if (settled) return;
                settled = true;
                cleanup();
                resolve(completeWithAudio && !signal.aborted && bytes > 0 ? new Blob(chunks, {
                    type: media.mimeType || 'audio/webm'
                }) : null);
            };
            try {
                media.start(200);
            } catch (error) {
                finish(false, error instanceof Error ? error : new Error('Could not start microphone recording.'));
                return;
            }
            timer = setInterval(()=>{
                if (signal.aborted) {
                    finish(false);
                    return;
                }
                const now = performance.now();
                analyser.getFloatTimeDomainData(samples);
                const level = sampleRms(samples);
                onLevel(Math.min(1, level / 0.22));
                const verdict = gate.feed(level, now - prevTime);
                prevTime = now;
                if (verdict === 'stop') finish(true);
                else if (verdict === 'empty') finish(false);
            }, 60);
        });
        return audio;
    } finally{
        if (timer !== null) clearInterval(timer);
        source?.disconnect();
        stream.getTracks().forEach((track)=>track.stop());
        if (context) void context.close().catch(()=>{});
        onLevel(0);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-call-near-end.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Classifies near-end speech while far-end TTS is playing.
 * Both streams must come from the same Web Audio context/sample clock.
 * This filter supplements browser AEC; it does not replace device testing.
 */ __turbopack_context__.s([
    "NearEndGate",
    ()=>NearEndGate,
    "bestEchoCorrelation",
    ()=>bestEchoCorrelation,
    "normalizedCorrelation",
    ()=>normalizedCorrelation,
    "rms",
    ()=>rms
]);
function rms(samples) {
    let sum = 0;
    for (const sample of samples)sum += sample * sample;
    return samples.length ? Math.sqrt(sum / samples.length) : 0;
}
function normalizedCorrelation(left, right) {
    const n = Math.min(left.length, right.length);
    if (n === 0) return 0;
    let dot = 0, a = 0, b = 0;
    for(let i = 0; i < n; i++){
        dot += left[i] * right[i];
        a += left[i] ** 2;
        b += right[i] ** 2;
    }
    return a * b > 1e-10 ? Math.abs(dot / Math.sqrt(a * b)) : 0;
}
function bestEchoCorrelation(mic, ref, sampleRate) {
    if (!mic.length || ref.length < mic.length) return 0;
    // Output may reach the mic tens of milliseconds after the browser audio callback.
    const samplesPerStep = Math.max(1, Math.floor(sampleRate * 0.01));
    let best = 0;
    for(let offset = 0; offset + mic.length <= ref.length; offset += samplesPerStep){
        const match = normalizedCorrelation(mic, ref.subarray(offset, offset + mic.length));
        if (match > best) best = match;
    }
    return best;
}
class NearEndGate {
    consecutiveMs = 0;
    minRms;
    minSpeechMs;
    echoLimit;
    constructor(options = {}){
        this.minRms = options.minRms ?? 0.014;
        this.minSpeechMs = options.minSpeechMs ?? 210;
        this.echoLimit = options.echoCorrelationLimit ?? 0.55;
    }
    feed(microphoneRms, farEndRms, correlation, elapsedMs) {
        // The hardware echo canceller usually leaves little far-end audio. Raw
        // output bleed is vetoed when it closely tracks the output samples.
        const echo = farEndRms > 0.008 && correlation >= this.echoLimit;
        const nearEnd = !echo && microphoneRms >= Math.max(this.minRms, farEndRms * 0.065);
        this.consecutiveMs = nearEnd ? this.consecutiveMs + Math.max(0, Math.min(100, elapsedMs)) : 0;
        return this.consecutiveMs >= this.minSpeechMs;
    }
    reset() {
        this.consecutiveMs = 0;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-duplex-audio.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MatorDuplexAudio",
    ()=>MatorDuplexAudio,
    "pcmToWav",
    ()=>pcmToWav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-call-capture.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-call-near-end.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$speech$2d$chunks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-speech-chunks.ts [app-client] (ecmascript)");
;
;
;
;
const FRAME_MS = 40;
const MAX_CAPTURE_BYTES = 12 * 1024 * 1024;
function abortError() {
    const error = new Error('Call was cancelled.');
    error.name = 'AbortError';
    return error;
}
function pcmToWav(frames, sampleRate) {
    const count = frames.reduce((n, chunk)=>n + chunk.length, 0);
    const data = new ArrayBuffer(44 + count * 2);
    const view = new DataView(data);
    const word = (pos, str)=>{
        for(let i = 0; i < str.length; i++)view.setUint8(pos + i, str.charCodeAt(i));
    };
    word(0, 'RIFF');
    view.setUint32(4, 36 + count * 2, true);
    word(8, 'WAVE');
    word(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    word(36, 'data');
    view.setUint32(40, count * 2, true);
    let index = 44;
    for (const frame of frames)for (const sample of frame){
        const clamped = Math.max(-1, Math.min(1, sample));
        view.setInt16(index, clamped < 0 ? clamped * 32768 : clamped * 32767, true);
        index += 2;
    }
    return new Blob([
        data
    ], {
        type: 'audio/wav'
    });
}
class MatorDuplexAudio {
    stream = null;
    ctx = null;
    source = null;
    analyser = null;
    currentSource = null;
    captureTimer = null;
    disposed = false;
    onLevel;
    synthesize;
    constructor(onLevel = ()=>{}, synthesize = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["synthesizeMatorSpeech"]){
        this.onLevel = onLevel;
        this.synthesize = synthesize;
    }
    async ensureReady(signal) {
        if (this.disposed) throw new Error('This call was ended.');
        if (signal.aborted) throw abortError();
        if (this.ctx && this.stream) {
            if (this.stream.getAudioTracks().some((track)=>track.readyState !== 'live')) {
                throw new Error('The microphone was disconnected. End and restart the call.');
            }
            if (this.ctx.state === 'suspended') await this.ctx.resume();
            return;
        }
        if (typeof AudioContext === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
            throw new Error('This browser does not support microphone calls.');
        }
        // Permission begins only after the user presses Start call.
        const pending = navigator.mediaDevices.getUserMedia({
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        });
        const media = await pending;
        if (this.disposed || signal.aborted) {
            media.getTracks().forEach((t)=>t.stop());
            throw abortError();
        }
        const context = new AudioContext({
            latencyHint: 'interactive'
        });
        try {
            const source = context.createMediaStreamSource(media);
            const analyser = context.createAnalyser();
            analyser.fftSize = 2048;
            source.connect(analyser);
            if (context.state === 'suspended') await context.resume();
            if (this.disposed || signal.aborted) throw abortError();
            this.stream = media;
            this.ctx = context;
            this.source = source;
            this.analyser = analyser;
        } catch (err) {
            media.getTracks().forEach((t)=>t.stop());
            await context.close();
            throw err;
        }
    }
    snapshot() {
        if (!this.analyser) throw new Error('The call microphone is not ready.');
        const out = new Float32Array(this.analyser.fftSize);
        this.analyser.getFloatTimeDomainData(out);
        this.onLevel(Math.min(1, (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rms"])(out) / 0.2));
        return out;
    }
    collect(signal, mode, playback, onBargeStart) {
        if (!this.ctx || !this.analyser) return Promise.reject(new Error('Microphone not ready'));
        const ctx = this.ctx;
        const gate = new __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VoiceActivityGate"]({
            minSpeechMs: 210,
            endSilenceMs: 850,
            maxWaitMs: mode === 'listen' ? 15000 : 30000,
            maxTurnMs: 24000
        });
        const nearEnd = new __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NearEndGate"]();
        const frames = [];
        const preroll = [];
        const maxPreroll = Math.ceil(500 / FRAME_MS);
        const sampleRate = ctx.sampleRate;
        let recording = false, bytes = 0, last = performance.now();
        return new Promise((resolve, reject)=>{
            let done = false;
            const finish = (result, error)=>{
                if (done) return;
                done = true;
                if (this.captureTimer !== null) {
                    clearInterval(this.captureTimer);
                    this.captureTimer = null;
                }
                signal.removeEventListener('abort', onAbort);
                this.onLevel(0);
                if (error) reject(error);
                else resolve(result);
            };
            const onAbort = ()=>finish(null);
            if (signal.aborted) {
                finish(null);
                return;
            }
            signal.addEventListener('abort', onAbort, {
                once: true
            });
            this.captureTimer = setInterval(()=>{
                if (this.disposed || signal.aborted) {
                    finish(null);
                    return;
                }
                const now = performance.now(), elapsed = Math.min(100, now - last);
                last = now;
                const chunk = this.snapshot();
                const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rms"])(chunk);
                if (!recording) {
                    preroll.push(chunk);
                    if (preroll.length > maxPreroll) preroll.shift();
                } else {
                    frames.push(chunk);
                    bytes += chunk.byteLength;
                }
                if (bytes > MAX_CAPTURE_BYTES) {
                    finish(null, new Error('Audio turn exceeded the recording limit.'));
                    return;
                }
                if (mode === 'barge' && playback && !recording) {
                    const offset = Math.round((ctx.currentTime - playback.startedAt) * sampleRate);
                    const refChannel = playback.buffer.getChannelData(0);
                    // Probe up to 250ms of historical output for acoustic delay.
                    const from = Math.max(0, offset - Math.round(0.25 * sampleRate));
                    const to = Math.min(refChannel.length, offset + Math.round(0.03 * sampleRate));
                    const ref = refChannel.subarray(from, to);
                    const correlation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bestEchoCorrelation"])(chunk, ref, sampleRate);
                    const farEndLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$near$2d$end$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rms"])(ref);
                    if (nearEnd.feed(level, farEndLevel, correlation, elapsed)) {
                        recording = true;
                        frames.push(...preroll);
                        bytes += preroll.reduce((n, f)=>n + f.byteLength, 0);
                        preroll.length = 0;
                        onBargeStart?.();
                        this.stopOutput();
                        // The buffered speech onset counts toward the turn's end-silence gate.
                        gate.feed(level, Math.max(210, elapsed));
                    }
                    return;
                }
                const verdict = gate.feed(level, elapsed);
                if (!recording && level > 0.018) {
                    recording = true;
                    frames.push(...preroll);
                    bytes += preroll.reduce((n, f)=>n + f.byteLength, 0);
                    preroll.length = 0;
                }
                if (verdict === 'stop') finish(pcmToWav(frames, sampleRate));
                else if (verdict === 'empty') finish(null);
            }, FRAME_MS);
        });
    }
    async capture(signal) {
        await this.ensureReady(signal);
        return this.collect(signal, 'listen');
    }
    /** Returns an interrupted spoken turn, or null when all playback finishes. */ async speakAndCatch(text, signal) {
        await this.ensureReady(signal);
        const ctx = this.ctx;
        for (const chunk of (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$speech$2d$chunks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chunkMatorSpeech"])(text)){
            if (signal.aborted) throw abortError();
            const audio = await this.synthesize(chunk, signal);
            const buffer = await ctx.decodeAudioData(await audio.arrayBuffer());
            if (signal.aborted) throw abortError();
            const output = ctx.createBufferSource();
            output.buffer = buffer;
            output.connect(ctx.destination);
            this.currentSource = output;
            let resolveEnd = ()=>{};
            const finished = new Promise((resolve)=>{
                resolveEnd = resolve;
            });
            output.onended = ()=>resolveEnd();
            const monitorController = new AbortController();
            const cancelBoth = ()=>{
                monitorController.abort();
                this.stopOutput();
            };
            signal.addEventListener('abort', cancelBoth, {
                once: true
            });
            let bargeTriggered = false;
            const startedAt = ctx.currentTime;
            const monitor = this.collect(monitorController.signal, 'barge', {
                buffer,
                startedAt
            }, ()=>{
                bargeTriggered = true;
            });
            output.start();
            try {
                await finished;
                if (bargeTriggered) {
                    const captured = await monitor;
                    if (captured) return captured;
                } else {
                    monitorController.abort();
                    await monitor;
                }
            } finally{
                monitorController.abort();
                signal.removeEventListener('abort', cancelBoth);
                this.currentSource = null;
            }
            if (signal.aborted) throw abortError();
        }
        return null;
    }
    stopOutput() {
        if (!this.currentSource) return;
        const source = this.currentSource;
        this.currentSource = null;
        try {
            source.stop();
        } catch  {
        /* already finished */ }
        source.disconnect();
    }
    close() {
        if (this.disposed) return;
        this.disposed = true;
        if (this.captureTimer !== null) clearInterval(this.captureTimer);
        this.captureTimer = null;
        this.stopOutput();
        this.source?.disconnect();
        this.source = null;
        this.stream?.getTracks().forEach((t)=>t.stop());
        this.stream = null;
        if (this.ctx) void this.ctx.close().catch(()=>{});
        this.ctx = null;
        this.analyser = null;
        this.onLevel(0);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/use-mator-ai-call.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "matorAiCallScope",
    ()=>matorAiCallScope,
    "useMatorAiCall",
    ()=>useMatorAiCall
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$coordinator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-call-coordinator.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$duplex$2d$audio$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-duplex-audio.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const INITIAL = {
    phase: 'idle',
    detail: '',
    scope: null,
    micMuted: false,
    speakerMuted: false
};
function matorAiCallScope(workflowId, conversationId) {
    return workflowId && conversationId ? `${workflowId}:${conversationId}` : null;
}
function useMatorAiCall({ workflowId, conversationId, voiceOnly, voice, sendTurn }) {
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(INITIAL);
    const [lastTurn, setLastTurn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [seconds, setSeconds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [voiceLevel, setVoiceLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [question, setQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lastQuestionAnswer, setLastQuestionAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const startTimeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const lastMeterRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const sessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const voiceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(voice);
    const sendRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(sendTurn);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorAiCall.useEffect": ()=>{
            voiceRef.current = voice;
            sendRef.current = sendTurn;
        }
    }["useMatorAiCall.useEffect"], [
        voice,
        sendTurn
    ]);
    const scope = matorAiCallScope(workflowId, conversationId);
    const active = state.phase !== 'idle' && state.phase !== 'ended';
    const coordinatorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorAiCall.useEffect": ()=>{
            const coordinator = new __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$coordinator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MatorCallCoordinator"]({
                capture: {
                    "useMatorAiCall.useEffect": (signal)=>{
                        if (!sessionRef.current) sessionRef.current = new __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$duplex$2d$audio$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MatorDuplexAudio"]({
                            "useMatorAiCall.useEffect": (level)=>{
                                const now = Date.now();
                                if (now - lastMeterRef.current >= 120 || level === 0) {
                                    lastMeterRef.current = now;
                                    setVoiceLevel(level);
                                }
                            }
                        }["useMatorAiCall.useEffect"]);
                        return sessionRef.current.capture(signal);
                    }
                }["useMatorAiCall.useEffect"],
                transcribe: {
                    "useMatorAiCall.useEffect": (audio, signal)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transcribeMatorAudio"])(audio, signal)
                }["useMatorAiCall.useEffect"],
                respond: {
                    "useMatorAiCall.useEffect": (transcript, { scope: activeScope, signal, attachmentIds })=>sendRef.current(transcript, activeScope, signal, attachmentIds)
                }["useMatorAiCall.useEffect"],
                speak: {
                    "useMatorAiCall.useEffect": (text, signal)=>{
                        if (!sessionRef.current) throw new Error('Microphone session is unavailable.');
                        return sessionRef.current.speakAndCatch(text, signal);
                    }
                }["useMatorAiCall.useEffect"],
                stopOutput: {
                    "useMatorAiCall.useEffect": ()=>sessionRef.current?.stopOutput()
                }["useMatorAiCall.useEffect"],
                onState: {
                    "useMatorAiCall.useEffect": (next)=>{
                        setState(next);
                        if (next.phase === 'ended') {
                            sessionRef.current?.close();
                            sessionRef.current = null;
                            setVoiceLevel(0);
                            setSeconds(0);
                            setQuestion(null);
                            setLastQuestionAnswer(null);
                        }
                    }
                }["useMatorAiCall.useEffect"],
                onQuestion: {
                    "useMatorAiCall.useEffect": (value, index, total)=>setQuestion(value ? {
                            value,
                            index,
                            total
                        } : null)
                }["useMatorAiCall.useEffect"],
                onQuestionAnswer: {
                    "useMatorAiCall.useEffect": (value, answer)=>setLastQuestionAnswer({
                            prompt: value.prompt,
                            answer
                        })
                }["useMatorAiCall.useEffect"],
                onTranscript: {
                    "useMatorAiCall.useEffect": (transcript)=>setLastTurn({
                            transcript,
                            reply: ''
                        })
                }["useMatorAiCall.useEffect"],
                onTurn: {
                    "useMatorAiCall.useEffect": ({ transcript, result })=>setLastTurn({
                            transcript,
                            reply: result.reply
                        })
                }["useMatorAiCall.useEffect"]
            });
            coordinatorRef.current = coordinator;
            return ({
                "useMatorAiCall.useEffect": ()=>{
                    coordinator.end();
                    coordinatorRef.current = null;
                    sessionRef.current?.close();
                    sessionRef.current = null;
                }
            })["useMatorAiCall.useEffect"];
        }
    }["useMatorAiCall.useEffect"], []);
    const end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorAiCall.useCallback[end]": ()=>{
            coordinatorRef.current?.end();
            sessionRef.current?.close();
            sessionRef.current = null;
        }
    }["useMatorAiCall.useCallback[end]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorAiCall.useEffect": ()=>{
            if (!voiceOnly || !scope) end();
            else coordinatorRef.current?.changeScope(scope);
        }
    }["useMatorAiCall.useEffect"], [
        voiceOnly,
        scope,
        end
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorAiCall.useEffect": ()=>{
            const handleVisibility = {
                "useMatorAiCall.useEffect.handleVisibility": ()=>{
                    if (document.hidden) coordinatorRef.current?.pause();
                }
            }["useMatorAiCall.useEffect.handleVisibility"];
            document.addEventListener('visibilitychange', handleVisibility);
            return ({
                "useMatorAiCall.useEffect": ()=>document.removeEventListener('visibilitychange', handleVisibility)
            })["useMatorAiCall.useEffect"];
        }
    }["useMatorAiCall.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorAiCall.useEffect": ()=>{
            if (!active) return;
            const update = {
                "useMatorAiCall.useEffect.update": ()=>setSeconds(Math.floor((Date.now() - startTimeRef.current) / 1000))
            }["useMatorAiCall.useEffect.update"];
            const interval = window.setInterval(update, 1000);
            update();
            return ({
                "useMatorAiCall.useEffect": ()=>window.clearInterval(interval)
            })["useMatorAiCall.useEffect"];
        }
    }["useMatorAiCall.useEffect"], [
        active
    ]);
    const start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorAiCall.useCallback[start]": ()=>{
            if (!scope) return;
            voiceRef.current.cancelPendingTranscript();
            voiceRef.current.stopSpeaking();
            setLastTurn(null);
            setQuestion(null);
            setLastQuestionAnswer(null);
            startTimeRef.current = Date.now();
            setSeconds(0);
            // Mic consent begins synchronously from Start call, not from the mode toggle.
            coordinatorRef.current?.start(scope);
        }
    }["useMatorAiCall.useCallback[start]"], [
        scope
    ]);
    return {
        state,
        active,
        seconds,
        voiceLevel,
        lastTurn,
        question,
        lastQuestionAnswer,
        start,
        end,
        pause: ()=>coordinatorRef.current?.pause(),
        resume: ()=>coordinatorRef.current?.resume(),
        interrupt: ()=>coordinatorRef.current?.interrupt(),
        muteMic: (muted)=>coordinatorRef.current?.setMicMuted(muted),
        muteSpeaker: (muted)=>coordinatorRef.current?.setSpeakerMuted(muted),
        answerVisual: (answers, ids)=>coordinatorRef.current?.answerVisual(answers, ids) ?? Promise.resolve(),
        approvalResolved: (id, decision)=>coordinatorRef.current?.stageDecisionSucceeded(id, decision) ?? Promise.resolve()
    };
}
_s(useMatorAiCall, "Zd7GFU71PwrepHXG/mOBnnV/o04=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-call-contract.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveMatorCallTurn",
    ()=>resolveMatorCallTurn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-chat-state.ts [app-client] (ecmascript)");
;
function resolveMatorCallTurn(events) {
    const eventIds = events.map((event)=>event.id);
    const assistant = events.filter((event)=>event.role === 'assistant');
    const clarify = assistant.find((event)=>event.kind === 'clarify' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readClarifyQuestions"])(event.action));
    const questions = clarify ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readClarifyQuestions"])(clarify.action) : null;
    const stages = assistant.filter((event)=>event.status === 'staged').map((event)=>event.id);
    const error = assistant.some((event)=>event.status === 'incomplete' || event.status === 'error');
    const reply = [
        ...assistant
    ].reverse().find((event)=>(event.kind === 'message' || event.kind === 'how') && ![
            'error',
            'incomplete',
            'staged',
            'rejected'
        ].includes(event.status ?? '') && Boolean(event.text?.trim()))?.text?.trim() ?? '';
    return {
        reply,
        requiresAttention: Boolean(questions?.length || stages.length || error || !reply),
        eventIds,
        ...questions?.length && clarify ? {
            clarification: {
                eventId: clarify.id,
                questions
            }
        } : {},
        ...stages.length ? {
            stagedEventIds: stages
        } : {}
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/mator-send-gate.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Double-send policy for Mator chat:
 * - While a POST is in flight, a second send is a no-op (no second network call).
 * - The Idempotency-Key is allocated on first attempt and reused only after failure
 *   (retry path); it is cleared after success so the next user turn gets a new key.
 */ __turbopack_context__.s([
    "beginMatorSend",
    ()=>beginMatorSend,
    "createMatorSendGate",
    ()=>createMatorSendGate,
    "finishMatorSendFailure",
    ()=>finishMatorSendFailure,
    "finishMatorSendSuccess",
    ()=>finishMatorSendSuccess
]);
function createMatorSendGate() {
    return {
        inFlight: false,
        idempotencyKey: null
    };
}
function beginMatorSend(gate, newKey) {
    if (gate.inFlight) return null;
    const key = gate.idempotencyKey ?? newKey();
    return {
        key,
        next: {
            inFlight: true,
            idempotencyKey: key
        }
    };
}
function finishMatorSendSuccess(_gate) {
    void _gate; // success clears the key regardless of the previous gate state
    return {
        inFlight: false,
        idempotencyKey: null
    };
}
function finishMatorSendFailure(gate) {
    return {
        inFlight: false,
        idempotencyKey: gate.idempotencyKey
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/use-mator-chat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMatorChat",
    ()=>useMatorChat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-call-contract.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-chat-state.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-send-gate.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function newIdempotencyKey() {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
        return crypto.randomUUID();
    }
    return `mator-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function useMatorChat({ workflowId, onSpeakHow, onSpeakReply, voiceOnly = false }) {
    _s();
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [conversations, setConversations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [conversationMeta, setConversationMeta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [events, setEvents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [localNotices, setLocalNotices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pending, setPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [attachmentPreviews, setAttachmentPreviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const sendGateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorSendGate"])());
    const inFlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const howTtsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    const onSpeakHowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onSpeakHow);
    const onSpeakReplyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onSpeakReply);
    const voiceOnlyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(voiceOnly);
    const conversationIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSendPayloadRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const refreshEpoch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorChat.useEffect": ()=>{
            onSpeakHowRef.current = onSpeakHow;
            onSpeakReplyRef.current = onSpeakReply;
            voiceOnlyRef.current = voiceOnly;
        }
    }["useMatorChat.useEffect"], [
        onSpeakHow,
        onSpeakReply,
        voiceOnly
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorChat.useEffect": ()=>{
            howTtsRef.current = settings?.howTtsEnabled ?? true;
        }
    }["useMatorChat.useEffect"], [
        settings?.howTtsEnabled
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorChat.useEffect": ()=>{
            conversationIdRef.current = conversationMeta?.id ?? null;
        }
    }["useMatorChat.useEffect"], [
        conversationMeta?.id
    ]);
    const speakNewHow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[speakNewHow]": (incoming)=>{
            // In voice-only mode, speak the final assistant reply once, not every
            // guidance event followed by the same answer.
            const spokenReply = voiceOnlyRef.current ? [
                ...incoming
            ].reverse().find({
                "useMatorChat.useCallback[speakNewHow]": (event)=>event.role === 'assistant' && event.kind === 'message' && event.status !== 'error' && event.status !== 'incomplete' && Boolean(event.text?.trim())
            }["useMatorChat.useCallback[speakNewHow]"]) : null;
            if (spokenReply?.text) {
                try {
                    onSpeakReplyRef.current?.(spokenReply.text);
                } catch  {
                // Text delivery is authoritative when speech playback fails.
                }
                return;
            }
            if (!howTtsRef.current && !voiceOnlyRef.current) return;
            for (const event of incoming){
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldSpeakHow"])(event, true) && event.text) {
                    try {
                        onSpeakHowRef.current?.(event.text);
                    } catch  {
                    // Speech is optional.
                    }
                }
            }
        }
    }["useMatorChat.useCallback[speakNewHow]"], []);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[refresh]": async ()=>{
            const epoch = ++refreshEpoch.current;
            if (!workflowId) {
                setConversations([]);
                setConversationMeta(null);
                setEvents([]);
                setLocalNotices([]);
                setError(null);
                setLoading(false);
                return;
            }
            setLoading(true);
            setError(null);
            try {
                const [listed, masked] = await Promise.all([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listMatorConversations"])(workflowId),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorSettings"])().catch({
                        "useMatorChat.useCallback[refresh]": ()=>null
                    }["useMatorChat.useCallback[refresh]"])
                ]);
                if (epoch !== refreshEpoch.current) return;
                if (masked) setSettings(masked);
                let currentId = listed.currentId;
                let items = listed.items;
                if (!currentId) {
                    const created = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorConversation"])(workflowId);
                    if (epoch !== refreshEpoch.current) return;
                    currentId = created.id;
                    items = [
                        created,
                        ...items.filter({
                            "useMatorChat.useCallback[refresh]": (item)=>item.id !== created.id
                        }["useMatorChat.useCallback[refresh]"])
                    ];
                }
                setConversations(items);
                const meta = items.find({
                    "useMatorChat.useCallback[refresh]": (item)=>item.id === currentId
                }["useMatorChat.useCallback[refresh]"]) ?? null;
                setConversationMeta(meta);
                const loaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorEvents"])(currentId);
                if (epoch !== refreshEpoch.current) return;
                setEvents(loaded);
                setLocalNotices([]);
            } catch (err) {
                if (epoch !== refreshEpoch.current) return;
                setError(err instanceof Error ? err.message : 'Unable to load chat');
            } finally{
                if (epoch === refreshEpoch.current) setLoading(false);
            }
        }
    }["useMatorChat.useCallback[refresh]"], [
        workflowId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMatorChat.useEffect": ()=>{
            void refresh();
        }
    }["useMatorChat.useEffect"], [
        refresh
    ]);
    const conversation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMatorChat.useMemo[conversation]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventsToConversation"])(events, localNotices)
    }["useMatorChat.useMemo[conversation]"], [
        events,
        localNotices
    ]);
    const staged = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMatorChat.useMemo[staged]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findPendingStage"])(events)
    }["useMatorChat.useMemo[staged]"], [
        events
    ]);
    const incomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMatorChat.useMemo[incomplete]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findIncompleteEvent"])(events)
    }["useMatorChat.useMemo[incomplete]"], [
        events
    ]);
    const settingsToggles = {
        autoApprove: settings?.autoApprove ?? false,
        squashPipelineHistory: settings?.squashPipelineHistory ?? false,
        howTtsEnabled: settings?.howTtsEnabled ?? true,
        modelId: settings?.modelId ?? 'openai/gpt-oss-20b',
        modelName: settings?.modelName ?? 'GPT-OSS 20B',
        modelLabel: settings?.modelLabel ?? 'Fast reasoning chat',
        modelTier: settings?.modelTier ?? 'free'
    };
    const syncSettingsFromComposer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[syncSettingsFromComposer]": (saved)=>{
            setSettings(saved);
        }
    }["useMatorChat.useCallback[syncSettingsFromComposer]"], []);
    const patchSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[patchSettings]": async (patch)=>{
            const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveMatorSettings"])(patch);
            setSettings(next);
            return next;
        }
    }["useMatorChat.useCallback[patchSettings]"], []);
    const chatNotice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[chatNotice]": (text)=>{
            setLocalNotices({
                "useMatorChat.useCallback[chatNotice]": (previous)=>[
                        ...previous,
                        {
                            id: `local-${Date.now()}-${Math.random().toString(16).slice(2)}`,
                            sender: 'assistant',
                            text
                        }
                    ]
            }["useMatorChat.useCallback[chatNotice]"]);
        }
    }["useMatorChat.useCallback[chatNotice]"], []);
    const setConversation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[setConversation]": (next)=>{
            const resolved = typeof next === 'function' ? next((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventsToConversation"])(events, localNotices)) : next;
            const eventIds = new Set(events.map({
                "useMatorChat.useCallback[setConversation]": (event)=>event.id
            }["useMatorChat.useCallback[setConversation]"]));
            setLocalNotices(resolved.filter({
                "useMatorChat.useCallback[setConversation]": (bubble)=>bubble.sender === 'assistant' && !eventIds.has(String(bubble.id)) && bubble.id !== 'seed'
            }["useMatorChat.useCallback[setConversation]"]));
        }
    }["useMatorChat.useCallback[setConversation]"], [
        events,
        localNotices
    ]);
    const send = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[send]": async (text, attachmentIds)=>{
            const request = (text ?? message).trim();
            const ids = attachmentIds?.filter(Boolean) ?? [];
            if (!request && ids.length === 0) return;
            const conversationId = conversationIdRef.current;
            if (!conversationId) {
                setError('Chat is not ready. Wait for the workflow conversation to load, then retry.');
                if (text !== undefined) setMessage(request);
                return false;
            }
            // Only retry the same idempotency key when the payload is unchanged.
            const payloadSignature = JSON.stringify({
                request,
                ids
            });
            if (sendGateRef.current.idempotencyKey && lastSendPayloadRef.current !== payloadSignature) {
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorSendGate"])();
            }
            const started = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["beginMatorSend"])(sendGateRef.current, newIdempotencyKey);
            if (!started) return false;
            sendGateRef.current = started.next;
            lastSendPayloadRef.current = payloadSignature;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            if (text === undefined) setMessage('');
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postMatorMessage"])(conversationId, {
                    ...request ? {
                        text: request
                    } : {},
                    ...ids.length ? {
                        attachmentIds: ids
                    } : {}
                }, started.key);
                setEvents({
                    "useMatorChat.useCallback[send]": (previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeMatorEvents"])(previous, result.events)
                }["useMatorChat.useCallback[send]"]);
                speakNewHow(result.events);
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finishMatorSendSuccess"])(sendGateRef.current);
                lastSendPayloadRef.current = null;
                if (text !== undefined) {
                    setMessage({
                        "useMatorChat.useCallback[send]": (current)=>current.trim() === request ? '' : current
                    }["useMatorChat.useCallback[send]"]);
                }
                return true;
            } catch (err) {
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finishMatorSendFailure"])(sendGateRef.current);
                setMessage({
                    "useMatorChat.useCallback[send]": (current)=>current.trim() ? current : request
                }["useMatorChat.useCallback[send]"]);
                setError(err instanceof Error ? err.message : 'Unable to send message');
                return false;
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[send]"], [
        message,
        speakNewHow
    ]);
    // Call requests reuse the exact Mator event stream and the same send gate,
    // but do not mutate the editable text draft or trigger the chat TTS callback.
    const sendCallTurn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[sendCallTurn]": async (transcript, scope, signal, attachmentIds)=>{
            const id = conversationIdRef.current;
            const request = transcript.trim();
            if (!id || !workflowId || scope !== `${workflowId}:${id}` || !request) {
                throw new Error('The active Mator conversation changed.');
            }
            if (signal.aborted) throw new Error('The call was cancelled.');
            if (inFlightRef.current) throw new Error('Mator is already processing another message.');
            const signature = JSON.stringify({
                request,
                ids: attachmentIds ?? [],
                mode: 'ai_call'
            });
            if (sendGateRef.current.idempotencyKey && lastSendPayloadRef.current !== signature) {
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorSendGate"])();
            }
            const started = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["beginMatorSend"])(sendGateRef.current, newIdempotencyKey);
            if (!started) throw new Error('Mator is processing another message.');
            sendGateRef.current = started.next;
            lastSendPayloadRef.current = signature;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postMatorMessage"])(id, {
                    text: request,
                    ...attachmentIds?.length ? {
                        attachmentIds
                    } : {},
                    interactionMode: 'ai_call'
                }, started.key, signal);
                if (signal.aborted || conversationIdRef.current !== id) {
                    throw new Error('The call conversation changed before its reply arrived.');
                }
                setEvents({
                    "useMatorChat.useCallback[sendCallTurn]": (previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeMatorEvents"])(previous, response.events)
                }["useMatorChat.useCallback[sendCallTurn]"]);
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finishMatorSendSuccess"])(sendGateRef.current);
                lastSendPayloadRef.current = null;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$call$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveMatorCallTurn"])(response.events);
            } catch (cause) {
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finishMatorSendFailure"])(sendGateRef.current);
                if (!signal.aborted && conversationIdRef.current === id) {
                    setError(cause instanceof Error ? cause.message : 'Unable to send call turn');
                }
                throw cause;
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[sendCallTurn]"], [
        workflowId
    ]);
    const uploadForClarify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[uploadForClarify]": async (file)=>{
            const conversationId = conversationIdRef.current;
            if (!conversationId) throw new Error('Select a workflow conversation first.');
            const uploaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadMatorAttachment"])(conversationId, file);
            if (file.type.startsWith('image/')) {
                const previewUrl = URL.createObjectURL(file);
                setAttachmentPreviews({
                    "useMatorChat.useCallback[uploadForClarify]": (previous)=>({
                            ...previous,
                            [uploaded.id]: previewUrl
                        })
                }["useMatorChat.useCallback[uploadForClarify]"]);
            }
            return uploaded.id;
        }
    }["useMatorChat.useCallback[uploadForClarify]"], []);
    const attachFile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[attachFile]": async (file)=>{
            const conversationId = conversationIdRef.current;
            if (!conversationId) {
                setError('Select or create a workflow conversation first');
                return null;
            }
            setError(null);
            try {
                const uploaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadMatorAttachment"])(conversationId, file);
                if (file.type.startsWith('image/')) {
                    const previewUrl = URL.createObjectURL(file);
                    setAttachmentPreviews({
                        "useMatorChat.useCallback[attachFile]": (previous)=>({
                                ...previous,
                                [uploaded.id]: previewUrl
                            })
                    }["useMatorChat.useCallback[attachFile]"]);
                }
                // Uploading prepares the asset; sending happens only on user request.
                return uploaded;
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to upload attachment');
                return null;
            }
        }
    }["useMatorChat.useCallback[attachFile]"], []);
    const saveMarkers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[saveMarkers]": async (attachmentId, markers, reviewId)=>{
            setError(null);
            try {
                const meta = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patchMatorMarkers"])(attachmentId, markers, reviewId);
                setEvents({
                    "useMatorChat.useCallback[saveMarkers]": (previous)=>previous.map({
                            "useMatorChat.useCallback[saveMarkers]": (event)=>event.attachmentId === attachmentId || event.attachments?.some({
                                    "useMatorChat.useCallback[saveMarkers]": (asset)=>asset.id === attachmentId
                                }["useMatorChat.useCallback[saveMarkers]"]) ? {
                                    ...event,
                                    ...event.attachmentId === attachmentId ? {
                                        markers: meta.markers,
                                        reviewId: meta.reviewId ?? undefined
                                    } : {},
                                    attachments: event.attachments?.map({
                                        "useMatorChat.useCallback[saveMarkers]": (asset)=>asset.id === attachmentId ? {
                                                ...asset,
                                                markers: meta.markers,
                                                reviewId: meta.reviewId ?? undefined
                                            } : asset
                                    }["useMatorChat.useCallback[saveMarkers]"])
                                } : event
                        }["useMatorChat.useCallback[saveMarkers]"])
                }["useMatorChat.useCallback[saveMarkers]"]);
                return meta;
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to save markers');
                throw err;
            }
        }
    }["useMatorChat.useCallback[saveMarkers]"], []);
    const sendMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[sendMessage]": (event)=>{
            event.preventDefault();
            void send();
        }
    }["useMatorChat.useCallback[sendMessage]"], [
        send
    ]);
    const incompleteContinue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[incompleteContinue]": async ()=>{
            if (!incomplete) return;
            await send('Continue');
        }
    }["useMatorChat.useCallback[incompleteContinue]"], [
        incomplete,
        send
    ]);
    const confirmStage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[confirmStage]": async (eventId)=>{
            const conversationId = conversationIdRef.current;
            const target = eventId ? events.find({
                "useMatorChat.useCallback[confirmStage]": (event)=>event.id === eventId && event.status === 'staged' && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stageResolution"])(events, event.id)
            }["useMatorChat.useCallback[confirmStage]"]) : staged;
            if (!conversationId || !target || inFlightRef.current) return;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["confirmMatorStage"])(conversationId, target.id);
                setEvents({
                    "useMatorChat.useCallback[confirmStage]": (previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeMatorEvents"])(previous, [
                            result.event
                        ])
                }["useMatorChat.useCallback[confirmStage]"]);
                return true;
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to confirm staged action');
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[confirmStage]"], [
        events,
        staged
    ]);
    const rejectStage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[rejectStage]": async (eventId)=>{
            const conversationId = conversationIdRef.current;
            const target = eventId ? events.find({
                "useMatorChat.useCallback[rejectStage]": (event)=>event.id === eventId && event.status === 'staged' && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stageResolution"])(events, event.id)
            }["useMatorChat.useCallback[rejectStage]"]) : staged;
            if (!conversationId || !target || inFlightRef.current) return;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rejectMatorStage"])(conversationId, target.id);
                setEvents({
                    "useMatorChat.useCallback[rejectStage]": (previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeMatorEvents"])(previous, [
                            result.event
                        ])
                }["useMatorChat.useCallback[rejectStage]"]);
                return true;
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to reject staged action');
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[rejectStage]"], [
        events,
        staged
    ]);
    const newConversation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[newConversation]": async ()=>{
            if (!workflowId || inFlightRef.current) return;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                const created = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorConversation"])(workflowId);
                setConversations({
                    "useMatorChat.useCallback[newConversation]": (previous)=>[
                            created,
                            ...previous.filter({
                                "useMatorChat.useCallback[newConversation]": (item)=>item.id !== created.id
                            }["useMatorChat.useCallback[newConversation]"])
                        ]
                }["useMatorChat.useCallback[newConversation]"]);
                setConversationMeta(created);
                setEvents([]);
                setLocalNotices([]);
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorSendGate"])();
                lastSendPayloadRef.current = null;
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to create conversation');
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[newConversation]"], [
        workflowId
    ]);
    const switchConversation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[switchConversation]": async (conversationId)=>{
            if (!workflowId || inFlightRef.current) return;
            if (conversationId === conversationIdRef.current) return;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["switchMatorConversation"])(workflowId, conversationId);
                const meta = conversations.find({
                    "useMatorChat.useCallback[switchConversation]": (item)=>item.id === conversationId
                }["useMatorChat.useCallback[switchConversation]"]) ?? null;
                setConversationMeta(meta);
                const loaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorEvents"])(conversationId);
                setEvents(loaded);
                setLocalNotices([]);
                sendGateRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$send$2d$gate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMatorSendGate"])();
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to switch conversation');
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[switchConversation]"], [
        conversations,
        workflowId
    ]);
    const restorePipeline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMatorChat.useCallback[restorePipeline]": async (confirmDirty = false)=>{
            const conversationId = conversationIdRef.current;
            if (!conversationId || inFlightRef.current) return;
            inFlightRef.current = true;
            setPending(true);
            setError(null);
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreMatorPipeline"])(conversationId, confirmDirty);
                const loaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorEvents"])(conversationId);
                setEvents(loaded);
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Unable to restore pipeline');
                throw err;
            } finally{
                inFlightRef.current = false;
                setPending(false);
            }
        }
    }["useMatorChat.useCallback[restorePipeline]"], []);
    const voicePolicies = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMatorChat.useMemo[voicePolicies]": ()=>({
                howTtsEnabled: settingsToggles.howTtsEnabled,
                /** Never TTS the user transcript — only assistant `how` when enabled. */ maySpeakUserTranscript: false,
                speakHow: ({
                    "useMatorChat.useMemo[voicePolicies]": (text)=>{
                        if (!howTtsRef.current) return;
                        try {
                            onSpeakHowRef.current?.(text);
                        } catch  {
                        /* optional */ }
                    }
                })["useMatorChat.useMemo[voicePolicies]"]
            })
    }["useMatorChat.useMemo[voicePolicies]"], [
        settingsToggles.howTtsEnabled
    ]);
    return {
        conversation: conversation,
        conversationMeta,
        conversations,
        events,
        message,
        setMessage,
        send,
        sendCallTurn,
        sendMessage,
        confirmStage,
        rejectStage,
        newConversation,
        switchConversation,
        restorePipeline,
        attachFile,
        uploadForClarify,
        saveMarkers,
        attachmentPreviews,
        settings,
        settingsToggles,
        patchSettings,
        syncSettingsFromComposer,
        voicePolicies,
        pending,
        pendingStage: staged,
        pendingLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$chat$2d$state$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pendingStageLabel"])(staged),
        error,
        loading,
        incomplete,
        incompleteContinue,
        chatNotice,
        setConversation,
        refresh
    };
}
_s(useMatorChat, "mT5veHGadA/2JqAaMCSkqAtidfo=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/mator/use-visual-reviews.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "imageDataUrlFromBlob",
    ()=>imageDataUrlFromBlob,
    "useVisualReviews",
    ()=>useVisualReviews
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/visual-review-model.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function imageDataUrlFromBlob(blob, mime) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = ()=>{
            if (typeof reader.result === 'string') {
                resolve(reader.result);
                return;
            }
            reject(new Error('Could not read the chosen image'));
        };
        reader.onerror = ()=>reject(new Error('Could not read the chosen image'));
        // Re-serialize as a data URL carrying the actual file mime.
        const bytes = new Blob([
            blob
        ], {
            type: mime || 'image/png'
        });
        reader.readAsDataURL(bytes);
    });
}
function useVisualReviews({ platform, onCaptureSection, onSelectedNode, onReviewSaved, onInspectReview, onSelectReviewAccount, refresh, annotateChatImage }) {
    _s();
    const [imageDraft, setImageDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [imageError, setImageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Rendered closures are recreated per render; the pending resolver must
    // survive across the annotate → save lifecycle, so it lives in a ref.
    const chatAnnotationResolver = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    async function attachImage(file) {
        if (!file) return;
        const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateReviewImage"])(file);
        if (error) {
            setImageError(error);
            return;
        }
        const reader = new FileReader();
        reader.onload = ()=>{
            if (typeof reader.result === 'string') {
                setImageDraft({
                    kind: 'upload',
                    src: reader.result,
                    imageData: reader.result
                });
                setImageError('');
            }
        };
        reader.onerror = ()=>setImageError('Could not read the selected image');
        reader.readAsDataURL(file);
    }
    function annotateCapture(runId, fileName) {
        const section = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureSection"])(fileName);
        if (section && platform === 'linkedin') onCaptureSection(section);
        const src = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${runId}/evidence/${fileName}`);
        onSelectedNode('annotation');
        setImageDraft({
            kind: 'capture',
            src,
            runId,
            fileName
        });
    }
    /**
   * Open the YAML-driven annotation studio for a chat image. Resolves with
   * the created review id after the operator saves, or null when dismissed.
   */ async function annotateChatAsset(request) {
        if (!annotateChatImage) {
            throw new Error('Full-image annotation is unavailable in this workspace');
        }
        const built = await annotateChatImage(request);
        if (!built) return null;
        return new Promise((resolve)=>{
            chatAnnotationResolver.current = resolve;
            setImageError('');
            setImageDraft({
                kind: 'upload',
                src: built.imageDataUrl,
                imageData: built.imageDataUrl,
                draftNote: request.note
            });
        });
    }
    /**
   * Panel dismiss hook. A pending chat annotation resolves as cancelled —
   * a dismissed studio is never reported as a saved review.
   */ function closeImageDraft() {
        setImageDraft(null);
        if (chatAnnotationResolver.current) {
            const resolve = chatAnnotationResolver.current;
            chatAnnotationResolver.current = null;
            resolve(null);
        }
    }
    async function saveVisualReview(draft) {
        const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('visual-reviews'), {
            method: 'POST',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(draft)
        });
        const json = await response.json();
        if (!response.ok || !json.id) throw new Error(json.error || 'Could not save visual review');
        setImageDraft(null);
        onSelectedNode('annotation');
        onReviewSaved(json.id, draft.annotations.length);
        await refresh();
        if (chatAnnotationResolver.current) {
            const resolve = chatAnnotationResolver.current;
            chatAnnotationResolver.current = null;
            resolve({
                reviewId: json.id
            });
        }
    }
    function inspectReview(review) {
        onInspectReview(review);
    }
    const reviewImage = (review)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`visual-reviews/${review.id}/image`);
    function tagExistingReview(review) {
        onSelectReviewAccount(review);
        setImageDraft({
            kind: 'review',
            src: reviewImage(review),
            reviewId: review.id,
            initialAnnotations: review.annotations
        });
        onSelectedNode('annotation');
    }
    return {
        imageDraft,
        setImageDraft,
        closeImageDraft,
        imageError,
        attachImage,
        annotateCapture,
        annotateChatAsset,
        saveVisualReview,
        inspectReview,
        tagExistingReview,
        reviewImage
    };
}
_s(useVisualReviews, "UFxdbCAcbueP6WY6T8ZgWt8DClI=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_components_mator_0sep9d0._.js.map