(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/components/dashboard/growth/linkedin-growth-capabilities.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Canonical LinkedIn growth capability inventory.
 *
 * This is a product scope registry, NOT an automation registry.
 * A planned or assisted action cannot be dispatched as an API call.
 * "partial" means only the explicitly listed linked existing workflows run.
 */ __turbopack_context__.s([
    "growthCapabilities",
    ()=>growthCapabilities,
    "growthGuardrails",
    ()=>growthGuardrails,
    "growthJourneys",
    ()=>growthJourneys,
    "profileSections",
    ()=>profileSections
]);
const profileSections = [
    'Profile photo',
    'Banner / cover',
    'Full name and pronunciation',
    'Headline',
    'About',
    'Experience',
    'Education',
    'Featured',
    'Skills',
    'Recommendations',
    'Certifications',
    'Projects',
    'Publications',
    'Volunteering',
    'Honors and awards',
    'Services',
    'Contact information',
    'Custom profile URL',
    'Career preferences',
    'Profile verification'
];
const growthCapabilities = [
    {
        id: 'profile',
        title: 'Profile auditing & section optimization',
        priority: 'P0',
        pillar: 'execution',
        status: 'partial',
        summary: 'Grounded, section-by-section profile quality, positioning and evidence review.',
        actions: [
            'Assess every supported profile section independently using a transparent rubric',
            'Review photo framing, banner hierarchy, name and pronunciation accuracy',
            'Audit and rewrite headline, About, Experience, Education and Featured',
            'Review Skills, Recommendations, Certifications, Projects and Publications',
            'Review volunteering, honors, Services, contact links and custom URL',
            'Check job preferences, verification options and career-specific keywords',
            'Compare original versus proposed claims; reject fabricated achievements',
            'Provide role-specific headline/About variations and prioritized improvements',
            'Preserve drafts, change history and verified post-edit reassessment'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'Saved account profiles, selected approval-gated browser workflows, and a manual evidence-based profile planner.',
        requires: 'Additional section extractors, real field-by-field audit rubric, provenance, and supported permission checks.',
        route: '/dashboard/profile'
    },
    {
        id: 'competitors',
        title: 'Creator, competitor & niche intelligence',
        priority: 'P0',
        pillar: 'research',
        status: 'partial',
        summary: 'Explain observed positioning and content patterns without inventing private growth history.',
        actions: [
            'Find relevant peers, creators, founders, recruiters and company pages through permitted sources',
            'Maintain a consented creator/competitor watchlist and comparison cohorts',
            'Compare public positioning, career milestones, content pillars and writing styles',
            'Analyze user-supplied post excerpts, formats, hooks, engagement and visible patterns',
            'Construct sourced career/content timelines and mark unavailable early posts',
            'Distinguish observed metrics from hypotheses about audience and conversion',
            'Identify content gaps and collaboration candidates',
            "Produce testable strategies adapted to the owner's career stage"
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'User-submitted creator research: source-linked reports, positioning comparison and experiment proposals; no automated LinkedIn scraping.',
        requires: 'Permitted discovery sources, explicit watchlist storage and timestamped comparative evidence.',
        route: '/dashboard/research'
    },
    {
        id: 'content',
        title: 'Post creation, publishing & management',
        priority: 'P0',
        pillar: 'execution',
        status: 'partial',
        summary: 'Source-aware editorial workflow from idea and approval to authorized publication and records.',
        actions: [
            'Research questions, trends, problems, original case studies and evidence',
            'Draft educational, personal, project, research and hiring posts',
            'Review hooks, readability, originality, citations, audience fit and calls to action',
            'Save, revise, approve, reopen, archive and delete private drafts',
            'Publish approved text-only member posts with an authorized OAuth grant',
            'Track provider post URNs, failed deliveries and uncertain outcomes',
            'Read, edit and delete owned provider posts only with appropriate permissions',
            'Schedule, repurpose, create media assets and manage articles/polls when supported',
            'Associate post-level performance with a campaign or content pillar'
        ],
        modes: [
            'official-api',
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'Private editorial lifecycle and explicitly confirmed personal text-post publishing; provider receipts and failure-safe states.',
        requires: 'OAuth product access and consent for live publishing; permission-specific provider read/update/delete, media, scheduler and metrics integrations.',
        route: '/dashboard/editorial'
    },
    {
        id: 'engagement',
        title: 'Engagement & community discussions',
        priority: 'P1',
        pillar: 'execution',
        status: 'planned',
        summary: 'Prioritize meaningful replies on owned conversations and avoid manufactured engagement.',
        actions: [
            'Find relevant discussions through permitted evidence',
            'Review and summarize accessible comments on owned content',
            'Prepare context-aware replies and useful contributions',
            'Manage response queue, thread context and moderation requests',
            'React, comment, repost or remove a reaction only with expressly supported provider rights',
            'Track recurring substantive conversations and unanswered requests',
            'Review the quality and outcomes of contributions'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No complete engagement management or automated LinkedIn interaction integration.',
        requires: 'Permissions and policy review for each mutation, owner review, accessible conversation data and a durable response queue.'
    },
    {
        id: 'network',
        title: 'Audience & professional network development',
        priority: 'P1',
        pillar: 'execution',
        status: 'planned',
        summary: 'Grow relevant professional relationships rather than maximize connection totals.',
        actions: [
            'Define ideal followers and high-value professional audiences',
            'Research peers, recruiters, collaborators and relevant communities',
            'Prioritize shared interests and authentic introduction opportunities',
            'Draft personalized connection notes for owner delivery',
            'Track manually sent invitations and replies',
            'Maintain relationship context and sensible follow-ups',
            'Compare meaningful relationships with raw network size'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No invitation delivery, network discovery or persistent relationship workflows.',
        requires: 'Owner-supplied contact context; manual sending; consent and clear restrictions on invitation automation.'
    },
    {
        id: 'company',
        title: 'Company Page & organization growth',
        priority: 'P1',
        pillar: 'execution',
        status: 'planned',
        summary: 'A distinct organization identity and permission model, not a personal-profile clone.',
        actions: [
            'Audit Page description, tagline, logo, banner, website and call-to-action',
            'Check Page administrator roles before each mutation',
            'Coordinate founder and brand calendars without duplicate copy',
            'Publish company announcements with organization-scoped permissions',
            'Review Page conversations, followers, visitors and content metrics when eligible',
            'Compare eligible competitor Page metrics and native benchmarks',
            'Plan employee advocacy, services, events, Showcase Pages and paid promotion'
        ],
        modes: [
            'official-api',
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No Company Page provider authorization or organization publishing.',
        requires: 'Organization OAuth scopes, admin-role checks, approved products, independent organization data model.'
    },
    {
        id: 'branding',
        title: 'Personal positioning & professional authority',
        priority: 'P0',
        pillar: 'execution',
        status: 'partial',
        summary: 'Make expertise recognizable through consistent evidence-backed positioning.',
        actions: [
            'Define career goal, niche, ideal audience and specific professional promise',
            'Select 3–5 sustainable pillars and recognizable voice guidelines',
            'Prioritize verified achievements, projects and proof-of-work',
            'Align profile, Featured items, portfolio, writing and visual identity',
            'Plan credible milestones, guest writing, speaking and collaborations',
            'Detect unsupported claims or contradictory positioning',
            'Measure recognition and qualified opportunity outcomes'
        ],
        modes: [
            'assisted',
            'owner-operated'
        ],
        availableNow: 'Profile planning and creator research can inform positioning, but no unified, persisted brand strategy module.',
        requires: 'Versioned owner goals, approved voice samples, evidence taxonomy and brand strategy reviews.',
        route: '/dashboard/profile'
    },
    {
        id: 'jobs',
        title: 'Job search & career opportunity pipeline',
        priority: 'P1',
        pillar: 'execution',
        status: 'planned',
        summary: 'From job evidence and factual fit scoring to owner-submitted applications and outcomes.',
        actions: [
            'Define target roles, adjacent careers, industries and companies',
            'Record legitimate openings, requirements and source URLs',
            'Match actual qualifications and identify missing skills',
            'Align resume, portfolio and LinkedIn profile for a specific vacancy',
            'Prepare applications, cover letters and interview evidence',
            'Track saved, applied, interviewing, rejected, offer and accepted states',
            'Draft recruiter introductions and respectful follow-ups',
            'Measure application-to-interview and offer outcomes'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'Existing resume workspace supports career documents; there is no integrated job search or application tracker.',
        requires: 'Verified vacancy input, job and application records, user-controlled submission and vacancy freshness checks.'
    },
    {
        id: 'outreach',
        title: 'Outreach, messaging & relationships',
        priority: 'P1',
        pillar: 'execution',
        status: 'planned',
        summary: 'Context-aware relationship assistance with owner-operated LinkedIn messaging.',
        actions: [
            'Research relevant professional context supplied or legitimately accessible',
            'Draft non-generic connection notes, introductions and collaboration requests',
            'Prepare recruiter, mentor, customer and partnership conversations',
            'Summarize user-provided messages and track next steps',
            'Maintain a response queue and follow-up decisions',
            'Offer respectful opt-out and do-not-contact controls',
            'Record meeting outcomes without falsely claiming a message was sent'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No LinkedIn DM integration, outreach queue or automated sending.',
        requires: 'Consent and contact records, explicit human delivery, retained evidence and anti-spam constraints.'
    },
    {
        id: 'leads',
        title: 'Lead, customer & partnership CRM',
        priority: 'P2',
        pillar: 'execution',
        status: 'planned',
        summary: 'Track qualification, conversations, meetings and commercial outcomes.',
        actions: [
            'Define an ideal prospect or partner',
            'Research companies and potential business needs with provenance',
            'Qualify opportunities without inventing buyer intent',
            'Draft proposals and discovery-call agendas',
            'Track discovered, researching, contacted, replied, qualified, meeting, proposal, won and lost',
            'Record do-not-contact preferences and genuine pipeline conversion'
        ],
        modes: [
            'assisted',
            'owner-operated'
        ],
        availableNow: 'No CRM pipeline or lead conversion attribution.',
        requires: 'Tenant-isolated contact records, source provenance and lifecycle transitions.'
    },
    {
        id: 'longform',
        title: 'Newsletters, events & professional communities',
        priority: 'P2',
        pillar: 'execution',
        status: 'planned',
        summary: 'Plan deeper thought leadership and substantive professional participation.',
        actions: [
            'Research newsletter themes, draft article/edition outlines and maintain an editorial calendar',
            'Repurpose supported original work into short-form content',
            'Review eligibility to publish newsletters or articles in LinkedIn',
            'Discover relevant events, groups, talks and community questions',
            'Prepare networking questions, attendance goals and follow-up notes',
            'Measure readership and authentic collaboration outcomes'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No LinkedIn newsletter, event or group management integration.',
        requires: 'Permitted discovery sources, owner-driven participation and eligible publishing features.'
    },
    {
        id: 'analytics',
        title: 'Audience, post & opportunity analytics',
        priority: 'P0',
        pillar: 'measurement',
        status: 'planned',
        summary: 'Establish defensible baselines and demonstrate useful professional outcomes.',
        actions: [
            'Record profile visits, search appearances, impressions and eligible reach',
            'Track relevant followers, reactions, comments, reposts and discussion quality',
            'Import approved LinkedIn native analytics exports and label collection method',
            'Compare weekly, monthly and quarterly baselines',
            'Compute engagement and follower-growth rates with explicit denominators',
            'Analyze pillar, format, audience and time period performance',
            'Attribute interviews, leads, collaborations and meetings only when evidence allows',
            'Export historical reports with missing-data and uncertainty annotations'
        ],
        modes: [
            'official-api',
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'No real LinkedIn audience analytics ingestion or growth baseline dashboard.',
        requires: 'Authorized API access where available or user-uploaded exports, typed metrics and source snapshots.'
    },
    {
        id: 'reputation',
        title: 'Brand reputation, credibility & account health',
        priority: 'P1',
        pillar: 'measurement',
        status: 'planned',
        summary: 'Protect the credibility and security of the professional identity over time.',
        actions: [
            'Review factual claims, stale roles, contradictory dates and inflated accomplishments',
            'Audit public contact surfaces, account settings and authorized integrations',
            'Flag user-reported impersonation or inappropriate discussions for owner review',
            'Review privacy and verification settings without changing them secretly',
            'Maintain evidenced claims and publication history',
            'Avoid artificial engagement and mass-automation tactics'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'Existing evidence/approval checks cover individual profile workflows, not comprehensive reputation monitoring.',
        requires: 'Account health checklist, permission inventory, approved source records and owner review.'
    },
    {
        id: 'experiments',
        title: 'Growth experiments & strategy refinement',
        priority: 'P1',
        pillar: 'measurement',
        status: 'planned',
        summary: 'Test measurable changes with one clear hypothesis and a documented result.',
        actions: [
            'Record account-specific audience and professional goals',
            'Define testable changes to headlines, pillars, formats, hooks or calls to action',
            'Establish baseline, success metric and observation window before changing anything',
            'Track experiment variants, source content and owner approval',
            'Analyze observed changes with caveats about causation and sample size',
            'Choose a justified next iteration based on collected evidence'
        ],
        modes: [
            'assisted',
            'owner-operated'
        ],
        availableNow: 'Creator Research proposes experiments, but does not execute and measure a versioned experiment program.',
        requires: 'Real analytics inputs, experiment store, outcome attribution and user approval for changes.'
    },
    {
        id: 'reporting',
        title: 'Advanced reporting & multi-account governance',
        priority: 'P2',
        pillar: 'measurement',
        status: 'planned',
        summary: 'Separate personal and company ownership, maintain data boundaries and assemble decision-ready reports.',
        actions: [
            'Produce longitudinal multi-module growth reports',
            'Compare personal and company indicators without mixing identity permissions',
            'Export evidence, change receipts and experiment outcomes',
            'Apply tenant and role-scoped access controls for teams',
            'Review connector permissions, audits and data retention',
            'Track which operations were provider-executed versus owner-operated'
        ],
        modes: [
            'assisted',
            'owner-operated',
            'restricted'
        ],
        availableNow: 'Tenant document isolation exists for implemented features, but no shared multi-account reporting product.',
        requires: 'Scoped roles, owner/company data contracts, source governance and reporting validation.'
    }
];
const growthJourneys = [
    {
        id: 'profile',
        title: 'Improve my profile',
        sequence: [
            'profile',
            'competitors',
            'branding',
            'analytics'
        ],
        outcome: 'A prioritized, evidence-backed section revision plan and a measured follow-up.'
    },
    {
        id: 'audience',
        title: 'Grow my professional audience',
        sequence: [
            'branding',
            'competitors',
            'content',
            'engagement',
            'analytics',
            'experiments'
        ],
        outcome: 'An authentic editorial and engagement cycle with real performance evidence.'
    },
    {
        id: 'job',
        title: 'Find a better job',
        sequence: [
            'jobs',
            'profile',
            'outreach',
            'analytics'
        ],
        outcome: 'Verified opportunities, tailored career evidence, tracked owner-submitted applications.'
    },
    {
        id: 'company',
        title: 'Grow my company',
        sequence: [
            'company',
            'branding',
            'content',
            'leads',
            'analytics'
        ],
        outcome: 'A distinct organization presence and attributable leads or partnerships.'
    },
    {
        id: 'relationships',
        title: 'Build valuable relationships',
        sequence: [
            'network',
            'outreach',
            'engagement',
            'leads'
        ],
        outcome: 'Meaningful conversations, follow-up context and genuine collaborations.'
    }
];
const growthGuardrails = [
    'No LinkedIn scraping, bulk invitations, unsolicited mass DMs or artificial engagement.',
    'Public facts, owner-supplied evidence, inference and private analytics must remain distinguishable.',
    'No account or organization action without the exact scope, ownership check and user approval.',
    'Never label a drafted message or internal content revision as an external LinkedIn action.',
    'Permission-restricted modules must fail closed; availability can vary by LinkedIn program.',
    'Reported performance must show source, timeframe, denominator and uncertainty.'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "capabilityForSlug",
    ()=>capabilityForSlug,
    "default",
    ()=>GrowthCapabilityDetails
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-up-right.mjs [app-client] (ecmascript) <export default as ArrowUpRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleHelp$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-question-mark.mjs [app-client] (ecmascript) <export default as CircleHelp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2d$keyhole$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LockKeyhole$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/lock-keyhole.mjs [app-client] (ecmascript) <export default as LockKeyhole>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/shield-check.mjs [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/linkedin-growth-capabilities.ts [app-client] (ecmascript)");
'use client';
;
;
;
function capabilityForSlug(slug) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthCapabilities"].find((item)=>slug === `growth-${item.id}`);
}
function GrowthCapabilityDetails({ slug }) {
    const capability = capabilityForSlug(slug);
    if (!capability) return null;
    const journeys = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthJourneys"].filter((journey)=>journey.sequence.includes(capability.id));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-testid": "growth-capability-details",
        "aria-labelledby": "growth-detail-heading",
        className: "rounded-2xl border border-slate-200 bg-white p-5 sm:p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2 text-xs font-semibold text-slate-600",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded-md border border-slate-200 px-2.5 py-1",
                                children: capability.priority
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded-md border border-slate-200 px-2.5 py-1 capitalize",
                                children: capability.pillar
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 38,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded-md border border-slate-200 px-2.5 py-1",
                                children: capability.status === 'partial' ? 'Partially available' : 'Planned'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs text-slate-500",
                        children: [
                            capability.actions.length,
                            " proposed actions"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                id: "growth-detail-heading",
                className: "mt-5 text-xl font-semibold tracking-tight text-slate-950",
                children: capability.title
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 max-w-3xl text-sm leading-6 text-slate-600",
                children: capability.summary
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-5 grid gap-3 lg:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-xl border border-slate-200 p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "flex items-center gap-2 text-sm font-semibold",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                        className: "size-4 text-teal-700"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 63,
                                        columnNumber: 13
                                    }, this),
                                    "Available today"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm leading-6 text-slate-700",
                                children: capability.availableNow
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this),
                            capability.route && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: capability.route,
                                className: "mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-teal-800 underline underline-offset-4",
                                children: [
                                    "Open existing supported workflow",
                                    ' ',
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__["ArrowUpRight"], {
                                        className: "size-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 75,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this),
                            capability.id === 'profile' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "/dashboard/workspace",
                                className: "mt-2 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-teal-800 underline underline-offset-4",
                                children: [
                                    "Open profile Growth pipelines ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__["ArrowUpRight"], {
                                        className: "size-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 83,
                                        columnNumber: 45
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 79,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-xl border border-slate-200 p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "flex items-center gap-2 text-sm font-semibold",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2d$keyhole$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LockKeyhole$3e$__["LockKeyhole"], {
                                        className: "size-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 89,
                                        columnNumber: 13
                                    }, this),
                                    "Required before full delivery"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm leading-6 text-slate-700",
                                children: capability.requires
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                open: true,
                className: "mt-4 rounded-xl border border-slate-200 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                        className: "cursor-pointer text-sm font-semibold text-slate-900",
                        children: [
                            "Proposed actions and pipeline requirements (",
                            capability.actions.length,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "mt-4 grid gap-3 md:grid-cols-2",
                        children: capability.actions.map((action, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "flex items-start gap-3 text-sm leading-6 text-slate-700",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "shrink-0 font-mono text-xs text-slate-400",
                                        children: String(index + 1).padStart(2, '0')
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 108,
                                        columnNumber: 15
                                    }, this),
                                    action
                                ]
                            }, action, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            capability.id === 'profile' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                open: true,
                className: "mt-4 rounded-xl border border-slate-200 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                        className: "cursor-pointer text-sm font-semibold text-slate-900",
                        children: "20 profile sections requiring independent evidence and coverage"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 118,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-xs leading-5 text-slate-500",
                        children: "Target requirements. These are not claims that all sections have been audited."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["profileSections"].map((section, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-700",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mr-1 text-slate-400",
                                        children: [
                                            index + 1,
                                            "."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                        lineNumber: 131,
                                        columnNumber: 17
                                    }, this),
                                    section
                                ]
                            }, section, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 127,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 117,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-4 flex items-start gap-2 text-xs leading-5 text-slate-600",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleHelp$3e$__["CircleHelp"], {
                        className: "mt-0.5 size-4 shrink-0"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    "Modes:",
                    ' ',
                    capability.modes.map((mode)=>mode.replaceAll('-', ' ')).join(' · '),
                    ". A visual graph never authorizes remote execution."
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 138,
                columnNumber: 7
            }, this),
            journeys.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 text-xs leading-5 text-slate-600",
                children: [
                    "Related journeys:",
                    ' ',
                    journeys.map((journey)=>journey.title).join(' · ')
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 145,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                className: "mt-5 border-t border-slate-100 pt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                        className: "flex cursor-pointer items-center gap-2 text-sm font-semibold text-slate-800",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 152,
                                columnNumber: 11
                            }, this),
                            "Permissions, evidence and operating boundaries"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "mt-3 space-y-2",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthGuardrails"].map((rule)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "text-xs leading-5 text-slate-600",
                                children: [
                                    "• ",
                                    rule
                                ]
                            }, rule, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                                lineNumber: 157,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                        lineNumber: 155,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
                lineNumber: 150,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/growth/growth-capability-details.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c = GrowthCapabilityDetails;
var _c;
__turbopack_context__.k.register(_c, "GrowthCapabilityDetails");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/hooks/use-growth-profile-workflow.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGrowthProfileWorkflow",
    ()=>useGrowthProfileWorkflow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useGrowthProfileWorkflow(platform, templateId, accountId) {
    _s();
    const endpoint = templateId ? `/api/growth/templates/${encodeURIComponent(templateId)}` : '';
    const key = `${platform}/${templateId ?? ''}/${accountId ?? ''}`;
    const [snapshot, setSnapshot] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [errorState, setErrorState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [working, setWorking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const program = snapshot?.key === key ? snapshot.program : null;
    const run = snapshot?.key === key ? snapshot.run : null;
    const error = errorState?.key === key ? errorState.message : '';
    const setRun = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useGrowthProfileWorkflow.useCallback[setRun]": (next)=>{
            setSnapshot({
                "useGrowthProfileWorkflow.useCallback[setRun]": (current)=>current?.key === key ? {
                        ...current,
                        run: next
                    } : current
            }["useGrowthProfileWorkflow.useCallback[setRun]"]);
        }
    }["useGrowthProfileWorkflow.useCallback[setRun]"], [
        key
    ]);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useGrowthProfileWorkflow.useCallback[refresh]": async (signal)=>{
            if (platform !== 'linkedin' || !templateId) return;
            const loaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(endpoint, 'GET', undefined, signal);
            if (signal?.aborted) return;
            if (!accountId) {
                setSnapshot({
                    key,
                    program: loaded,
                    run: null
                });
                setErrorState(null);
                return;
            }
            const runs = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`${endpoint}/runs`, 'GET', undefined, signal);
            if (signal?.aborted) return;
            setSnapshot({
                key,
                program: loaded,
                run: runs.find({
                    "useGrowthProfileWorkflow.useCallback[refresh]": (item)=>item.accountId === accountId
                }["useGrowthProfileWorkflow.useCallback[refresh]"]) ?? null
            });
            setErrorState(null);
        }
    }["useGrowthProfileWorkflow.useCallback[refresh]"], [
        platform,
        templateId,
        accountId,
        endpoint,
        key
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGrowthProfileWorkflow.useEffect": ()=>{
            if (platform !== 'linkedin' || !templateId) return;
            const controller = new AbortController();
            let active = true;
            let inFlight = false;
            const poll = {
                "useGrowthProfileWorkflow.useEffect.poll": async ()=>{
                    if (!active || inFlight) return;
                    inFlight = true;
                    try {
                        await refresh(controller.signal);
                    } catch (reason) {
                        if (active && !controller.signal.aborted) setErrorState({
                            key,
                            message: reason instanceof Error ? reason.message : 'Cannot refresh Growth run'
                        });
                    } finally{
                        inFlight = false;
                    }
                }
            }["useGrowthProfileWorkflow.useEffect.poll"];
            void poll();
            const interval = setInterval({
                "useGrowthProfileWorkflow.useEffect.interval": ()=>void poll()
            }["useGrowthProfileWorkflow.useEffect.interval"], 2500);
            return ({
                "useGrowthProfileWorkflow.useEffect": ()=>{
                    active = false;
                    clearInterval(interval);
                    controller.abort();
                }
            })["useGrowthProfileWorkflow.useEffect"];
        }
    }["useGrowthProfileWorkflow.useEffect"], [
        platform,
        templateId,
        key,
        refresh
    ]);
    async function mutate(fn) {
        if (working) return;
        setWorking(true);
        setErrorState(null);
        try {
            await fn();
            await refresh();
        } catch (reason) {
            setErrorState({
                key,
                message: reason instanceof Error ? reason.message : 'Request failed'
            });
        } finally{
            setWorking(false);
        }
    }
    return {
        endpoint,
        program,
        run,
        setRun,
        error,
        working,
        mutate
    };
}
_s(useGrowthProfileWorkflow, "0Fv/5ecwlkLEU9i9tO0upjHXBYI=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GrowthGraphNodeCard",
    ()=>GrowthGraphNodeCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$react$40$12$2e$12$2e$0_$40$type_0159d66b9a3a8ac5586194ca52c7c517$2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@xyflow+react@12.12.0_@type_0159d66b9a3a8ac5586194ca52c7c517/node_modules/@xyflow/react/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$system$40$0$2e$0$2e$83$2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-alert.mjs [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-up-right.mjs [app-client] (ecmascript) <export default as ArrowUpRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$git$2d$branch$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GitBranch$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/git-branch.mjs [app-client] (ecmascript) <export default as GitBranch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/settings-2.mjs [app-client] (ecmascript) <export default as Settings2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$workflow$2d$step$2d$icons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/workflows/workflow-step-icons.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const statusStyle = {
    completed: 'bg-emerald-100 text-emerald-800',
    running: 'bg-sky-100 text-sky-800',
    started: 'bg-sky-100 text-sky-800',
    failed: 'bg-rose-100 text-rose-800',
    blocked: 'bg-rose-100 text-rose-800',
    paused: 'bg-amber-100 text-amber-900',
    'approval-needed': 'bg-amber-100 text-amber-900',
    'input-needed': 'bg-amber-100 text-amber-900',
    cancelled: 'bg-slate-200 text-slate-700',
    waiting: 'bg-slate-200 text-slate-600'
};
function GrowthGraphNodeCard({ data, selected }) {
    const isPipeline = data.kind === 'pipeline';
    const failed = data.state === 'failed' || data.state === 'blocked';
    const Icon = isPipeline ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$git$2d$branch$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GitBranch$3e$__["GitBranch"] : __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$workflow$2d$step$2d$icons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stepIconFor"][data.stepKind ?? 'note'];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": isPipeline ? `growth-pipeline-node-${data.nodeId}` : `growth-task-node-${data.nodeId}`,
        title: data.label,
        className: 'w-[228px] overflow-hidden rounded-2xl border bg-white shadow-lg transition-[border-color,box-shadow] ' + (failed ? 'border-rose-600 ring-2 ring-rose-200' : selected ? 'border-teal-600 ring-2 ring-teal-300' : 'border-slate-200 hover:border-teal-400'),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$react$40$12$2e$12$2e$0_$40$type_0159d66b9a3a8ac5586194ca52c7c517$2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
                type: "target",
                position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$system$40$0$2e$0$2e$83$2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Left,
                className: "!size-3 !border-white !bg-teal-700"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2 border-b border-slate-100 bg-slate-50 px-3 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-mono text-[10px] font-bold text-slate-500",
                        children: [
                            isPipeline ? 'PIPELINE ' : 'STEP ',
                            String(data.index).padStart(2, '0')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: 'rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ' + (statusStyle[data.state] ?? 'bg-slate-200 text-slate-600'),
                        children: data.state
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-20 gap-3 px-3 py-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "grid size-10 shrink-0 place-items-center rounded-xl bg-slate-950 text-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: "size-5",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "line-clamp-2 text-xs leading-5 font-extrabold text-slate-950",
                                children: data.label
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[11px] leading-4 text-slate-500 capitalize",
                                children: data.subtitle
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            data.failure && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mx-3 mb-3 line-clamp-2 text-[11px] font-semibold text-rose-800",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        className: "mr-1 inline size-3",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    data.failure
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 79,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2 border-t border-slate-100 px-3 py-2 text-[10px] font-semibold",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: data.designOnly ? 'text-amber-800' : 'text-teal-700',
                        children: data.designOnly ? 'PLANNED · NOT EXECUTABLE' : isPipeline ? `OPEN · ${data.stepCount} STEPS` : 'INSPECT · READ ONLY'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    isPipeline ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpRight$3e$__["ArrowUpRight"], {
                        className: "size-3.5 shrink-0 text-slate-400",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 93,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings2$3e$__["Settings2"], {
                        className: "size-3.5 shrink-0 text-slate-400",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                        lineNumber: 98,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$react$40$12$2e$12$2e$0_$40$type_0159d66b9a3a8ac5586194ca52c7c517$2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
                type: "source",
                position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$xyflow$2b$system$40$0$2e$0$2e$83$2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Right,
                className: "!size-3 !border-white !bg-teal-700"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/growth/artboard/growth-graph-node-card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = GrowthGraphNodeCard;
var _c;
__turbopack_context__.k.register(_c, "GrowthGraphNodeCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/growth-graph-model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildGrowthGraph",
    ()=>buildGrowthGraph,
    "getGrowthTaskStates",
    ()=>getGrowthTaskStates
]);
function getGrowthTaskStates(journal, live) {
    const states = new Map();
    for (const entry of journal){
        const id = entry.details?.stepId;
        const stage = entry.details?.stage;
        if (id && stage && [
            'started',
            'completed',
            'failed'
        ].includes(stage)) {
            states.set(id, stage);
        }
    }
    if (live && [
        'failed',
        'blocked'
    ].includes(live.state) && live.currentStepId) {
        states.set(live.currentStepId, 'failed');
    }
    return states;
}
function buildGrowthGraph(program, run, selected, journal, live, projection) {
    if (selected) {
        const taskStates = getGrowthTaskStates(journal, live);
        const projected = projection?.pipelines.find((item)=>item.id === selected.id);
        const taskById = new Map(projected?.tasks.map((task)=>[
                task.id,
                task
            ]) ?? []);
        const nodes = selected.plan.steps.map((step, index)=>({
                id: step.id,
                type: 'growthNode',
                position: step.position ?? {
                    x: 35 + index % 4 * 295,
                    y: 50 + Math.floor(index / 4) * 205
                },
                data: {
                    kind: 'task',
                    nodeId: step.id,
                    index: index + 1,
                    total: selected.plan.steps.length,
                    stepKind: step.kind,
                    designOnly: program.kind === 'GrowthBlueprintWorkflow',
                    label: step.title,
                    subtitle: `${step.kind.replaceAll('-', ' ')} step`,
                    state: taskById.get(step.id)?.state ?? taskStates.get(step.id) ?? 'waiting',
                    failure: taskById.get(step.id)?.failure ?? (taskStates.get(step.id) === 'failed' ? journal.filter((event)=>event.details?.stepId === step.id && event.details?.stage === 'failed').at(-1)?.details?.reason ?? live?.error ?? undefined : undefined)
                }
            }));
        const edges = selected.plan.links.map((link)=>({
                id: `${link.source}-${link.target}`,
                source: link.source,
                target: link.target,
                type: 'smoothstep',
                style: {
                    stroke: '#64748b',
                    strokeWidth: 2
                },
                animated: taskById.get(link.target)?.state === 'running' || !taskById.has(link.target) && taskStates.get(link.target) === 'started'
            }));
        return {
            nodes,
            edges
        };
    }
    const pipelineById = new Map(run?.pipelineRuns.map((item)=>[
            item.id,
            item
        ]) ?? []);
    const projectedById = new Map(projection?.pipelines.map((item)=>[
            item.id,
            item
        ]) ?? []);
    const nodes = program.stages.map((stage, index)=>{
        const state = pipelineById.get(stage.id);
        return {
            id: stage.id,
            type: 'growthNode',
            position: {
                x: 40 + index % 3 * 315,
                y: 55 + Math.floor(index / 3) * 250
            },
            data: {
                kind: 'pipeline',
                nodeId: stage.id,
                index: index + 1,
                total: program.stages.length,
                stepCount: stage.stepCount,
                designOnly: program.kind === 'GrowthBlueprintWorkflow',
                label: stage.title,
                subtitle: stage.stepCount + ' steps · ' + stage.sectionIds.length + ' coverage requirements',
                state: projectedById.get(stage.id)?.state ?? state?.state ?? 'waiting',
                failure: state?.error ?? undefined
            }
        };
    });
    const edges = program.stages.filter((stage)=>stage.dependsOn !== 'none').map((stage)=>({
            id: `${stage.dependsOn}-${stage.id}`,
            source: stage.dependsOn,
            target: stage.id,
            type: 'smoothstep',
            style: {
                stroke: '#64748b',
                strokeWidth: 2
            },
            animated: pipelineById.get(stage.id)?.state === 'running'
        }));
    return {
        nodes,
        edges
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GrowthCoverageList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function GrowthCoverageList({ run, program }) {
    const labels = new Map(program?.coverage.map((section)=>[
            section.id,
            section.label
        ]) ?? []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
        className: "rounded-xl border border-slate-200 p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                className: "cursor-pointer text-sm font-semibold",
                children: [
                    "All ",
                    run.counts.total,
                    " independent coverage records"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "mt-3 grid gap-2 sm:grid-cols-2",
                children: run.coverage.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "flex justify-between gap-2 rounded-lg bg-slate-50 p-3 text-xs text-slate-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: labels.get(item.id) ?? item.id
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
                                lineNumber: 24,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "shrink-0 font-semibold",
                                children: item.status === 'missing' ? 'Missing' : 'Owner reported'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
                                lineNumber: 25,
                                columnNumber: 13
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = GrowthCoverageList;
var _c;
__turbopack_context__.k.register(_c, "GrowthCoverageList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GrowthEvidenceForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function GrowthEvidenceForm({ run, program, endpoint, working, mutate }) {
    _s();
    const [evidenceSection, setEvidenceSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [evidenceText, setEvidenceText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const active = run.currentStage;
    const selectedSections = program?.coverage.filter((section)=>active?.sectionIds.includes(section.id)) ?? [];
    const currentEvidence = run.coverage.find((item)=>item.id === evidenceSection);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        className: "rounded-xl border border-slate-200 p-4",
        onSubmit: (event)=>{
            event.preventDefault();
            if (!evidenceSection) return;
            void mutate(async ()=>{
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`${endpoint}/runs/${run.id}/evidence`, 'POST', {
                    sectionId: evidenceSection,
                    text: evidenceText
                });
                setEvidenceText('');
            });
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-sm font-semibold text-slate-950",
                children: "Record independent section evidence"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-xs leading-5 text-slate-500",
                children: "Owner observations are stored as unverified input, never represented as a verified LinkedIn extraction."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "mt-3 block text-xs font-semibold text-slate-800",
                children: [
                    "Coverage section",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        "aria-label": "Coverage section",
                        required: true,
                        value: evidenceSection,
                        onChange: (event)=>{
                            setEvidenceSection(event.target.value);
                            setEvidenceText('');
                        },
                        className: "mt-1 min-h-10 w-full rounded-lg border border-slate-300 bg-white px-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Choose a section in the current stage"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this),
                            selectedSections.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: section.id,
                                    children: section.label
                                }, section.id, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "mt-3 block text-xs font-semibold text-slate-800",
                children: [
                    "Real owner-supplied observation (10–1500 characters)",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: evidenceText,
                        onChange: (event)=>setEvidenceText(event.target.value),
                        "aria-label": "Section observation",
                        required: true,
                        minLength: 10,
                        maxLength: 1500,
                        className: "mt-1 min-h-24 w-full rounded-lg border border-slate-300 p-3 text-sm"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            currentEvidence?.evidence && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-xs text-slate-500",
                children: [
                    "Previously submitted on",
                    ' ',
                    new Date(currentEvidence.evidence.capturedAt).toLocaleString(),
                    "; this remains owner-supplied, not independently verified."
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 87,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: working || evidenceText.trim().length < 10 || !evidenceSection,
                className: "mt-3 min-h-10 rounded-lg bg-slate-950 px-4 text-xs font-semibold text-white disabled:opacity-50",
                children: "Save source-labelled evidence"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(GrowthEvidenceForm, "p5pdPgUBDIdqjf/OTe14WfRQuQc=");
_c = GrowthEvidenceForm;
var _c;
__turbopack_context__.k.register(_c, "GrowthEvidenceForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/run-controls.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GrowthRunControls
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-right.mjs [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)");
'use client';
;
;
;
function GrowthRunControls({ run, program, busy, working, endpoint, mutate }) {
    const active = run.currentStage;
    const child = run.currentChild;
    const checkpoint = child?.checkpoint;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-xl border border-slate-200 p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-start justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-sm font-semibold text-slate-950",
                                children: [
                                    "Run ",
                                    run.id.slice(0, 8)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-600",
                                children: [
                                    "Current stage: ",
                                    active?.title,
                                    " · ",
                                    run.state
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-semibold text-slate-600",
                        children: [
                            run.counts.ownerSupplied,
                            "/",
                            run.counts.total,
                            " owner-supplied ·",
                            ' ',
                            run.counts.missing,
                            " missing"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            run.currentPageEvidence && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 text-xs leading-5 break-words text-slate-600",
                children: [
                    "Runner page evidence: ",
                    run.currentPageEvidence.url,
                    " · SHA-256",
                    ' ',
                    run.currentPageEvidence.digest.slice(0, 16),
                    "…"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 44,
                columnNumber: 9
            }, this),
            child?.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: `/api/runs/${child.id}/workflow.yaml`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "mt-2 inline-flex min-h-9 items-center gap-1 text-xs font-semibold text-teal-800 underline",
                children: [
                    "Inspect actual Runner YAML ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                        className: "size-3.5"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 56,
                        columnNumber: 38
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 50,
                columnNumber: 9
            }, this),
            child?.state === 'approval-needed' && checkpoint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm font-semibold text-amber-950",
                        children: "Owner evidence approval required"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 61,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-xs leading-5 text-amber-900",
                        children: checkpoint.message
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 flex gap-2",
                        children: [
                            true,
                            false
                        ].map((approved)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                disabled: working,
                                className: "min-h-10 rounded-lg border border-amber-600 px-3 text-xs font-semibold text-amber-950 disabled:opacity-50",
                                onClick: ()=>void mutate(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`/api/runs/${child.id}/decision`, 'POST', {
                                            checkpointId: checkpoint.id,
                                            approved
                                        })),
                                children: approved ? 'Approve evidence' : 'Reject'
                            }, String(approved), false, {
                                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                                lineNumber: 69,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 60,
                columnNumber: 9
            }, this),
            child?.state === 'paused' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                disabled: working,
                className: "mt-3 min-h-10 rounded-lg bg-slate-950 px-4 text-xs font-semibold text-white disabled:opacity-50",
                onClick: ()=>void mutate(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`/api/runs/${child.id}/resume`, 'POST')),
                children: "Resume reviewed Runner stage"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 90,
                columnNumber: 9
            }, this),
            child?.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 text-xs text-rose-700",
                role: "alert",
                children: child.error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 102,
                columnNumber: 9
            }, this),
            run.status === 'active' && child && [
                'running',
                'paused',
                'approval-needed',
                'input-needed'
            ].includes(child.state) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                disabled: working,
                className: "mt-3 ml-2 min-h-10 rounded-lg border border-rose-200 px-3 text-xs font-semibold text-rose-800 disabled:opacity-50",
                onClick: ()=>void mutate(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`/api/runs/${child.id}/cancel`, 'POST')),
                children: "Cancel active Runner pipeline"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 111,
                columnNumber: 11
            }, this),
            run.releasePending && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "mt-3 text-xs text-amber-800",
                children: "The completed Runner is releasing its browser session. The next pipeline becomes available after cleanup."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 123,
                columnNumber: 9
            }, this),
            run.canAdvance && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                disabled: working || busy,
                className: "mt-3 min-h-11 rounded-xl bg-teal-800 px-4 text-sm font-semibold text-white disabled:opacity-50",
                onClick: ()=>void mutate(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`${endpoint}/runs/${run.id}/advance`, 'POST')),
                children: run.activeIndex + 1 === program?.stages.length ? 'Finalize evidence report' : 'Advance to the next dependent pipeline'
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 129,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 text-xs leading-5 text-slate-500",
                children: run.outcomeNotice
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
                lineNumber: 144,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/growth/run-controls.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c = GrowthRunControls;
var _c;
__turbopack_context__.k.register(_c, "GrowthRunControls");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GrowthWorkspaceDialogs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$code$2d$corner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileCode2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/file-code-corner.mjs [app-client] (ecmascript) <export default as FileCode2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/shield-check.mjs [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$coverage$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/coverage-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$evidence$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/evidence-form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$run$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/run-controls.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function GrowthWorkspaceDialogs({ program, run, endpoint, accountId, busy, working, error, journal, journalError, detailsOpen, onDetailsClose, taskOpen, onTaskClose, stage, taskId, selectedAction, onSelectAction, setRun, mutate }) {
    const designOnly = program?.kind === 'GrowthBlueprintWorkflow';
    const task = stage?.plan.steps.find((item)=>item.id === taskId) ?? null;
    const taskEvent = [
        ...journal
    ].reverse().find((event)=>event.details?.stepId === taskId && event.details?.stage);
    const liveStage = run?.pipelineRuns.find((item)=>item.id === stage?.id);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: detailsOpen,
                onDismiss: onDetailsClose,
                title: program?.title ?? 'Growth workflow',
                description: "YAML source, real Runner controls, and independently attributed evidence.",
                size: "wide",
                testId: "growth-workspace-details",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-start justify-between gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "max-w-2xl text-sm leading-6 text-slate-600",
                                    children: program?.objective ?? 'Loading the selected workflow…'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this),
                                program && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: `${endpoint}/yaml`,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "inline-flex min-h-11 items-center gap-2 text-xs font-semibold text-teal-800 underline",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$code$2d$corner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileCode2$3e$__["FileCode2"], {
                                            className: "size-4"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                            lineNumber: 84,
                                            columnNumber: 17
                                        }, this),
                                        " View source YAML"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 78,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "text-sm text-rose-700",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 89,
                            columnNumber: 13
                        }, this),
                        program && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-950",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                    className: "mr-2 inline size-4"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this),
                                designOnly ? 'Planning-only YAML. Tasks and procedures are owner-operated; there is no registered Runner operation for this blueprint.' : 'The compiled pipelines use the existing Runner. Evidence stays unverified until supplied; this template cannot edit a provider profile.'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 94,
                            columnNumber: 13
                        }, this),
                        !designOnly && !accountId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "status",
                            className: "rounded-xl border border-slate-200 p-3 text-sm text-slate-600",
                            children: "Connect and verify a LinkedIn account before starting this workflow."
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 102,
                            columnNumber: 13
                        }, this),
                        !designOnly && accountId && (run?.status !== 'active' || [
                            'failed',
                            'blocked',
                            'cancelled',
                            'unavailable'
                        ].includes(run.state)) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: working || busy || !program,
                            onClick: ()=>void mutate(async ()=>{
                                    setRun(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])(`${endpoint}/runs`, 'POST', {
                                        accountId
                                    }));
                                }),
                            className: "min-h-11 rounded-xl bg-slate-950 px-5 text-sm font-semibold text-white disabled:opacity-50",
                            children: "Start Growth workflow"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 116,
                            columnNumber: 15
                        }, this),
                        !designOnly && run && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$run$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    run: run,
                                    program: program,
                                    busy: busy,
                                    working: working,
                                    endpoint: endpoint,
                                    mutate: mutate
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 135,
                                    columnNumber: 15
                                }, this),
                                run.status === 'active' && run.currentStage?.id !== 'review' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$evidence$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    run: run,
                                    program: program,
                                    endpoint: endpoint,
                                    working: working,
                                    mutate: mutate
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 144,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$coverage$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    run: run,
                                    program: program
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 152,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true),
                        program && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "rounded-xl border border-slate-200 p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "cursor-pointer text-sm font-semibold text-slate-900",
                                    children: [
                                        program.requirements.length,
                                        " requirements and registered actions"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 157,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                    className: "mt-3 list-decimal space-y-2 pl-5 text-xs leading-5 text-slate-600",
                                    children: program.requirements.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: item.text
                                        }, item.id, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                            lineNumber: 163,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 161,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-3 text-xs text-slate-500",
                                    children: program.limitation
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 166,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 grid gap-2 sm:grid-cols-2",
                                    children: program.pipelines.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            disabled: busy || designOnly || !onSelectAction,
                                            onClick: ()=>onSelectAction?.(item.action),
                                            className: 'min-h-11 rounded-lg border p-3 text-left text-xs font-semibold disabled:opacity-50 ' + (selectedAction === item.action ? 'border-teal-600 bg-teal-50' : 'border-slate-200'),
                                            children: item.title
                                        }, item.id, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                            lineNumber: 171,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 169,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 156,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: taskOpen && Boolean(task),
                onDismiss: onTaskClose,
                title: task?.title ?? 'Task details',
                description: stage ? stage.title + (designOnly ? ' · Planning-only task' : ' · Compiled Runner task') : undefined,
                testId: "growth-task-details",
                children: task && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4 text-sm text-slate-700",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs leading-5",
                            children: "Read-only source configuration. Editing these compiled tasks requires a validated, revisioned Growth YAML write API that is not available yet."
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 205,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                            className: "grid grid-cols-[6rem_minmax(0,1fr)] gap-2 text-xs",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                    className: "font-semibold",
                                    children: "Task ID"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 211,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                    className: "font-mono break-all",
                                    children: task.id
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 212,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                    className: "font-semibold",
                                    children: "Step kind"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 213,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                    className: "capitalize",
                                    children: task.kind
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 214,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                    className: "font-semibold",
                                    children: "Recorded state"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 215,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                    children: taskEvent?.details?.stage ?? 'No recorded task execution'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 216,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 210,
                            columnNumber: 13
                        }, this),
                        task.message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xs font-semibold",
                                    children: "Message"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 222,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-xs leading-5 whitespace-pre-wrap",
                                    children: task.message
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 223,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 221,
                            columnNumber: 15
                        }, this),
                        task.expectedText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xs font-semibold",
                                    children: "Expected text"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 230,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-xs leading-5 whitespace-pre-wrap",
                                    children: task.expectedText
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 231,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 229,
                            columnNumber: 15
                        }, this),
                        task.delayMs !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs",
                            children: [
                                "Delay: ",
                                task.delayMs,
                                " ms"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 237,
                            columnNumber: 15
                        }, this),
                        task.inputBindings && Object.entries(task.inputBindings).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xs font-semibold",
                                    children: "Validated input bindings"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 242,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "mt-2 space-y-2",
                                    children: Object.entries(task.inputBindings).map(([field, binding])=>binding ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "rounded-lg border border-slate-200 p-2 text-xs",
                                            children: [
                                                field,
                                                ": ",
                                                binding.stepId,
                                                ".",
                                                binding.field
                                            ]
                                        }, field, true, {
                                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                            lineNumber: 249,
                                            columnNumber: 27
                                        }, this) : null)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 245,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 241,
                            columnNumber: 17
                        }, this),
                        stage && stage.sectionIds.length > 0 && program && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xs font-semibold",
                                    children: "Coverage requirements"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 262,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-xs leading-5",
                                    children: stage.sectionIds.map((id)=>program.coverage.find((item)=>item.id === id)?.label ?? id).join(' · ')
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                                    lineNumber: 263,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 261,
                            columnNumber: 15
                        }, this),
                        taskEvent?.details?.reason && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800",
                            children: taskEvent.details.reason
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 275,
                            columnNumber: 15
                        }, this),
                        liveStage?.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "text-xs text-rose-800",
                            children: liveStage.error
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 283,
                            columnNumber: 15
                        }, this),
                        journalError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "status",
                            className: "text-xs text-amber-800",
                            children: journalError
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 288,
                            columnNumber: 15
                        }, this),
                        liveStage?.childRunId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: `/api/runs/${liveStage.childRunId}/logs`,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "block text-xs font-semibold text-teal-800 underline",
                            children: "Inspect Runner journal"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 293,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: `${endpoint}/yaml`,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "inline-flex min-h-11 items-center text-xs font-semibold text-teal-800 underline",
                            children: "View complete source YAML"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                            lineNumber: 302,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                    lineNumber: 204,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/growth/growth-workspace-dialogs.tsx",
                lineNumber: 191,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = GrowthWorkspaceDialogs;
var _c;
__turbopack_context__.k.register(_c, "GrowthWorkspaceDialogs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_components_dashboard_growth_0j_y1ju._.js.map