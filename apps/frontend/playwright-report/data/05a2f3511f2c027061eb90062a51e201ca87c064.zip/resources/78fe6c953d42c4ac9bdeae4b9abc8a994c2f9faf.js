(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "operationLabels",
    ()=>operationLabels,
    "primaryOperation",
    ()=>primaryOperation,
    "providerMeta",
    ()=>providerMeta
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/svgs/index.tsx [app-client] (ecmascript)");
;
const providerMeta = {
    linkedin: {
        key: 'linkedin',
        name: 'LinkedIn',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkedInIcon"],
        tile: 'bg-[#0a66c2]/10 text-[#0a66c2]',
        blurb: 'Browser-session connector. Sign in inside the isolated Chrome window; MFA stays in that window.'
    },
    x: {
        key: 'x',
        name: 'X',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XIcon"],
        tile: 'bg-slate-950/5 text-slate-950',
        blurb: 'Browser-session connector. Sign in directly with X; passwords are never collected.'
    },
    instagram: {
        key: 'instagram',
        name: 'Instagram',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstagramIcon"],
        tile: 'bg-pink-500/10 text-pink-600',
        blurb: 'Official API connector is required. Browser login is not offered for this network yet.'
    },
    github: {
        key: 'github',
        name: 'GitHub',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GithubIcon"],
        tile: 'bg-slate-100 text-slate-900',
        blurb: 'Official API connector is required. Browser login is not offered for this network yet.'
    },
    devto: {
        key: 'devto',
        name: 'Dev.to',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DevtoIcon"],
        tile: 'bg-slate-950 text-slate-50',
        blurb: 'Official API connector is required. Browser login is not offered for this network yet.'
    }
};
function primaryOperation(status, verifiedAt) {
    if (status === 'connected') {
        const verified = verifiedAt ? Date.parse(verifiedAt) : 0;
        // A day-old verification is treated as stale: the session may have been
        // revoked or expired upstream, so the primary action becomes a sync.
        if (Date.now() - verified > 24 * 60 * 60 * 1000) return 'sync';
        return 'disconnect';
    }
    if (status === 'api-required') return 'unavailable';
    if (status === 'disconnected') return 'connect';
    // sign-in-open / reconnect-required / anything unknown needs synchronization.
    return 'sync';
}
const operationLabels = {
    connect: 'Connect',
    sync: 'Sync',
    disconnect: 'Disconnect',
    unavailable: 'Connector unavailable'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConnectorNetworkPicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)");
'use client';
;
;
function ConnectorNetworkPicker({ network, setNetwork, setSelected, setConfirming, setError, setMessage }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-labelledby": "connector-network-heading",
        "data-testid": "network-picker",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 flex items-center justify-between",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    id: "connector-network-heading",
                    className: "text-sm font-semibold text-slate-900",
                    children: "Select a network"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-label": "Social networks",
                className: "grid grid-cols-2 gap-2",
                children: [
                    'linkedin',
                    'x'
                ].map((key)=>{
                    const Icon = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][key].icon;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "aria-pressed": network === key,
                        onClick: ()=>{
                            setNetwork(key);
                            setSelected(null);
                            setConfirming(false);
                            setError('');
                            setMessage('');
                        },
                        className: 'flex min-h-12 min-w-0 items-center justify-center gap-2 rounded-xl border px-2.5 py-2.5 text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950 ' + (network === key ? 'border-slate-950 bg-slate-950 text-white' : 'border-slate-200 bg-white text-slate-700 hover:border-slate-400 hover:bg-slate-50'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "size-5! shrink-0",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                                lineNumber: 55,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: key === 'x' ? 'sr-only' : 'min-w-0',
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][key].name
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                                lineNumber: 56,
                                columnNumber: 15
                            }, this)
                        ]
                    }, key, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                        lineNumber: 37,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = ConnectorNetworkPicker;
var _c;
__turbopack_context__.k.register(_c, "ConnectorNetworkPicker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConnectorOtherNetworks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)");
'use client';
;
;
function ConnectorOtherNetworks({ network, showOtherNetworks, setShowOtherNetworks, setNetwork, setSelected, setConfirming, setError, setMessage }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-label": "Additional social networks",
        className: "rounded-xl border border-slate-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-expanded": showOtherNetworks,
                "aria-controls": "other-network-options",
                onClick: ()=>setShowOtherNetworks((value)=>!value),
                className: "flex min-h-11 w-full flex-wrap items-center justify-between gap-x-3 gap-y-1 rounded-xl px-4 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Other networks"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-normal text-slate-500",
                        children: "Coming soon"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "other-network-options",
                className: showOtherNetworks ? 'grid grid-cols-1 gap-2 border-t border-slate-200 p-2 sm:grid-cols-3' : 'hidden',
                children: [
                    'instagram',
                    'github',
                    'devto'
                ].map((key)=>{
                    const Icon = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][key].icon;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "aria-pressed": network === key,
                        onClick: ()=>{
                            setNetwork(key);
                            setSelected(null);
                            setConfirming(false);
                            setError('');
                            setMessage('');
                        },
                        className: 'flex min-h-11 items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950 ' + (network === key ? 'border-slate-950 bg-slate-950 text-white' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "size-5! shrink-0",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                                lineNumber: 68,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][key].name
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                                lineNumber: 69,
                                columnNumber: 15
                            }, this)
                        ]
                    }, key, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                        lineNumber: 50,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c = ConnectorOtherNetworks;
var _c;
__turbopack_context__.k.register(_c, "ConnectorOtherNetworks");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/connections/sections/connector-status-notices.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConnectorStatusNotices
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function ConnectorStatusNotices({ error, message }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm leading-6 text-rose-900",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-status-notices.tsx",
                lineNumber: 13,
                columnNumber: 9
            }, this),
            message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "rounded-xl border border-teal-200 bg-teal-50 p-3 text-sm leading-6 text-teal-950",
                children: message
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-status-notices.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_c = ConnectorStatusNotices;
var _c;
__turbopack_context__.k.register(_c, "ConnectorStatusNotices");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConnectorSavedAccount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$status$2d$notices$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/sections/connector-status-notices.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
const button = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0a66c2] disabled:cursor-not-allowed disabled:opacity-50';
const shortDate = (value)=>value ? `Checked ${new Date(value).toLocaleString()}` : 'Not verified';
function ConnectorSavedAccount({ network, ready, available, chosen, activeId, status, oauth, busy, saving, working, workingId, operation, actionText, browserLoginAvailable, canStart, browserSupported, confirming, mobileClient, capabilities, setSelected, setConfirming, setError, setMessage, command, beginNewConnection, authorizePublishing, onSelect, abortRef, onManageProfile, setOpen, error, message }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-label": `${__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][network].name} connection`,
        className: "overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-slate-50 px-4 py-3.5 sm:px-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg leading-7 font-semibold text-slate-950",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][network].name
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-testid": "connector-status",
                        className: 'inline-flex min-h-8 max-w-full items-center rounded-full px-3 py-1 text-xs leading-5 font-semibold ' + (status === 'connected' ? 'bg-emerald-100 text-emerald-900' : status === 'sign-in-open' ? 'bg-amber-100 text-amber-950' : status === 'api-required' || !browserSupported ? 'bg-slate-200 text-slate-700' : 'bg-white text-slate-700 ring-1 ring-slate-200 ring-inset'),
                        children: status === 'connected' ? 'Session connected' : status === 'sign-in-open' ? 'Sign-in in progress' : status === 'api-required' || !browserSupported ? 'Unavailable' : oauth?.connected ? 'Publishing connected' : 'Not connected'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4 p-4 sm:p-5",
                children: !ready ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    className: "py-6 text-center text-sm text-slate-600",
                    children: "Checking your connections..."
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                    lineNumber: 130,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        available.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex flex-col gap-2 text-sm font-medium text-slate-800",
                                    children: [
                                        "Legacy linked accounts",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            "aria-label": "Legacy linked account",
                                            value: chosen?.id || '',
                                            onChange: (e)=>{
                                                setSelected(e.target.value);
                                                setConfirming(false);
                                                setError('');
                                            },
                                            className: "min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3 text-sm",
                                            children: available.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: item.id,
                                                    children: [
                                                        item.label,
                                                        " (@",
                                                        item.handle,
                                                        ")"
                                                    ]
                                                }, item.id, true, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 139,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 137,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "alert",
                                    className: "rounded-xl bg-amber-50 p-3 text-sm leading-5 text-amber-900",
                                    children: "Legacy duplicates detected. Remove the extra identities from your profile before linking a replacement."
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 156,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true),
                        chosen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "min-w-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-base leading-6 font-semibold [overflow-wrap:anywhere] break-words text-slate-950",
                                    children: chosen.label
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 167,
                                    columnNumber: 17
                                }, this),
                                chosen.handle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-sm leading-5 [overflow-wrap:anywhere] break-words text-slate-600",
                                    children: [
                                        "@",
                                        chosen.handle
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 171,
                                    columnNumber: 19
                                }, this),
                                activeId === chosen.id && status === 'connected' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-xs font-semibold text-emerald-800",
                                    children: "In use in your workspace"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 176,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-3 text-sm leading-6 text-slate-600",
                                    title: chosen.verifiedAt || undefined,
                                    children: status === 'connected' ? shortDate(chosen.verifiedAt) : status === 'sign-in-open' ? 'Finish signing in with the provider. We will check for completion automatically.' : 'This account needs a verified session before workflows can run.'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 180,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 166,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-3",
                            children: [
                                browserSupported ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm leading-6 text-slate-600",
                                    children: [
                                        "No ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][network].name,
                                        " account connected. Connect to detect your verified profile automatically."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 194,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "rounded-xl bg-slate-50 p-3 text-sm leading-6 text-slate-700",
                                    children: "Official API connector not available yet. Sync is disabled."
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 199,
                                    columnNumber: 19
                                }, this),
                                browserSupported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy || !canStart,
                                    className: button + ' w-full bg-slate-950 text-white hover:bg-slate-800',
                                    onClick: ()=>void beginNewConnection(network),
                                    children: [
                                        saving ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                            className: "size-4 animate-spin",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 216,
                                            columnNumber: 23
                                        }, this) : null,
                                        "Connect ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][network].name
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 204,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 192,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$status$2d$notices$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            error: error,
                            message: message
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 226,
                            columnNumber: 13
                        }, this),
                        chosen && browserSupported && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-3",
                            children: [
                                browserLoginAvailable ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>void command(chosen.id, operation),
                                    className: button + ' w-full bg-slate-950 text-white hover:bg-slate-800',
                                    children: [
                                        working && workingId === chosen.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                            className: "size-4 animate-spin",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 241,
                                            columnNumber: 23
                                        }, this) : null,
                                        working && workingId === chosen.id ? 'Checking connection...' : actionText
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 231,
                                    columnNumber: 19
                                }, this) : network === 'linkedin' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy || !oauth?.configured,
                                    onClick: ()=>void authorizePublishing(chosen.id),
                                    className: button + ' w-full bg-slate-950 text-white hover:bg-slate-800',
                                    children: oauth?.connected ? 'Renew LinkedIn publishing' : 'Connect LinkedIn for publishing'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 251,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm leading-6 text-amber-900",
                                    children: "Local desktop connector unavailable. This provider cannot use mobile browser cookies."
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 265,
                                    columnNumber: 19
                                }, this),
                                !browserLoginAvailable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm leading-6 text-slate-600",
                                    children: "Browser-based workflows need an interactive connection host. Publishing authorization does not grant browser access."
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 271,
                                    columnNumber: 19
                                }, this),
                                working && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>abortRef.current?.abort(),
                                    className: button + ' w-full border border-slate-200 text-slate-700 hover:bg-slate-50',
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 277,
                                    columnNumber: 19
                                }, this),
                                network === 'linkedin' && status === 'connected' && activeId !== chosen.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>{
                                        onSelect(chosen);
                                        setMessage('LinkedIn is selected for your workspace.');
                                    },
                                    className: button + ' w-full border border-slate-200 bg-white text-slate-800 hover:bg-slate-50',
                                    children: "Use this account"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 291,
                                    columnNumber: 21
                                }, this),
                                status === 'sign-in-open' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            role: "status",
                                            className: "rounded-xl bg-blue-50 p-3 text-sm leading-6 text-blue-950",
                                            children: "Automatically checking sign-in. You can also verify now."
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 308,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            disabled: busy,
                                            onClick: ()=>void command(chosen.id, 'disconnect'),
                                            className: button + ' w-full border border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
                                            children: "Cancel connection"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 314,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true),
                                network === 'linkedin' && browserLoginAvailable && oauth?.configured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                    className: "rounded-xl border border-slate-200 p-3 text-sm text-slate-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                            className: "min-h-11 cursor-pointer py-3 font-medium text-slate-800",
                                            children: [
                                                "Publishing access:",
                                                ' ',
                                                oauth.connected ? 'Authorized' : 'Not authorized'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 331,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            disabled: busy,
                                            onClick: ()=>void authorizePublishing(chosen.id),
                                            className: button + ' mt-2 w-full border border-slate-200 bg-white text-slate-800 hover:bg-slate-50',
                                            children: oauth.connected ? 'Renew publishing access' : 'Authorize publishing'
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 335,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 330,
                                    columnNumber: 21
                                }, this),
                                confirming ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-2 gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            disabled: busy,
                                            onClick: ()=>void command(chosen.id, 'disconnect'),
                                            className: button + ' border border-rose-300 bg-rose-50 px-2 text-rose-900 hover:bg-rose-100',
                                            children: "Confirm disconnect"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 352,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setConfirming(false),
                                            className: button + ' border border-slate-200 px-2 text-slate-800 hover:bg-slate-50',
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                            lineNumber: 363,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 351,
                                    columnNumber: 19
                                }, this) : status === 'connected' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>setConfirming(true),
                                    className: "inline-flex min-h-11 w-full items-center justify-center rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-rose-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950",
                                    children: "Disconnect"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                    lineNumber: 376,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 229,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-xl bg-slate-50 px-3 py-3 text-sm leading-6 text-slate-600",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: mobileClient ? 'Mobile Chrome and Safari cannot share their authenticated tabs with server-side Playwright. Local browser linking requires a desktop session.' : !capabilities?.browserAvailable ? 'This server cannot open an interactive login on your device. Use a local desktop agent or a supported provider authorization.' : capabilities.mode === 'attached' ? 'Local Chrome attachment enabled. Sign-in opens in a new tab in your authorized Chrome profile.' : 'Isolated Chrome mode uses a separate browser profile. To reuse a Chrome login, opt in to local Chrome attachment.'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                                lineNumber: 389,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 388,
                            columnNumber: 13
                        }, this),
                        onManageProfile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                setOpen(false);
                                onManageProfile();
                            },
                            className: button + ' w-full border border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
                            children: "Manage profiles"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                            lineNumber: 400,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
                lineNumber: 128,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx",
        lineNumber: 93,
        columnNumber: 5
    }, this);
}
_c = ConnectorSavedAccount;
var _c;
__turbopack_context__.k.register(_c, "ConnectorSavedAccount");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConnectorOnboarding
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/svgs/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$network$2d$picker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/sections/connector-network-picker.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$other$2d$networks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/sections/connector-other-networks.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$saved$2d$account$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/sections/connector-saved-account.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const path = '/api/connectors';
const button = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0a66c2] disabled:cursor-not-allowed disabled:opacity-50';
function ConnectorOnboarding({ activeId, onSelect, requestedId, hideTrigger = false, openSignal = 0, onManageProfile }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [accounts, setAccounts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [ready, setReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [working, setWorking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [workingId, setWorkingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [confirming, setConfirming] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [network, setNetwork] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('linkedin');
    const [showOtherNetworks, setShowOtherNetworks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [capabilities, setCapabilities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [mobileClient, setMobileClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [oauth, setOauth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const abortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(openSignal);
    const last = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        activeId,
        onSelect,
        accounts
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            last.current = {
                activeId,
                onSelect,
                accounts
            };
        }
    }["ConnectorOnboarding.useEffect"], [
        activeId,
        onSelect,
        accounts
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            setMobileClient(/Android|iPhone|iPad|iPod/i.test(navigator.userAgent));
            let live = true;
            void fetch(`${path}/capabilities`, {
                cache: 'no-store'
            }).then({
                "ConnectorOnboarding.useEffect": async (response)=>{
                    if (!response.ok) throw Error('Capabilities unavailable');
                    return response.json();
                }
            }["ConnectorOnboarding.useEffect"]).then({
                "ConnectorOnboarding.useEffect": (value)=>{
                    if (live) setCapabilities(value);
                }
            }["ConnectorOnboarding.useEffect"]).catch({
                "ConnectorOnboarding.useEffect": ()=>{
                    if (live) setCapabilities({
                        browserAvailable: false,
                        mode: 'isolated',
                        mobileBrowserSession: false
                    });
                }
            }["ConnectorOnboarding.useEffect"]);
            return ({
                "ConnectorOnboarding.useEffect": ()=>{
                    live = false;
                }
            })["ConnectorOnboarding.useEffect"];
        }
    }["ConnectorOnboarding.useEffect"], []);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ConnectorOnboarding.useCallback[refresh]": async ()=>{
            const response = await fetch(path, {
                cache: 'no-store'
            });
            const data = await response.json();
            if (!response.ok || !Array.isArray(data)) throw Error(data.error || 'Social connections unavailable');
            setAccounts(data);
            const linkedin = data.filter({
                "ConnectorOnboarding.useCallback[refresh].linkedin": (item)=>item.platform === 'linkedin'
            }["ConnectorOnboarding.useCallback[refresh].linkedin"]);
            const previous = last.current.accounts.find({
                "ConnectorOnboarding.useCallback[refresh].previous": (item)=>item.id === last.current.activeId
            }["ConnectorOnboarding.useCallback[refresh].previous"]);
            const current = data.find({
                "ConnectorOnboarding.useCallback[refresh].current": (item)=>item.id === last.current.activeId
            }["ConnectorOnboarding.useCallback[refresh].current"]);
            if (current && previous && (current.status !== previous.status || current.verifiedAt !== previous.verifiedAt)) last.current.onSelect(current);
            if (!last.current.activeId) {
                const linked = linkedin.find({
                    "ConnectorOnboarding.useCallback[refresh].linked": (item)=>item.status === 'connected'
                }["ConnectorOnboarding.useCallback[refresh].linked"]);
                if (linked) last.current.onSelect(linked);
            }
            return data;
        }
    }["ConnectorOnboarding.useCallback[refresh]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            let active = true;
            void refresh().catch({
                "ConnectorOnboarding.useEffect": (e)=>{
                    if (active) setError(e instanceof Error ? e.message : 'Unable to load connections');
                }
            }["ConnectorOnboarding.useEffect"]).finally({
                "ConnectorOnboarding.useEffect": ()=>{
                    if (active) setReady(true);
                }
            }["ConnectorOnboarding.useEffect"]);
            // The backend is authoritative even after another browser tab or device
            // updates the connection. This component is mounted across all app panes.
            const timer = setInterval({
                "ConnectorOnboarding.useEffect.timer": ()=>void refresh().catch({
                        "ConnectorOnboarding.useEffect.timer": ()=>undefined
                    }["ConnectorOnboarding.useEffect.timer"])
            }["ConnectorOnboarding.useEffect.timer"], 15000);
            return ({
                "ConnectorOnboarding.useEffect": ()=>{
                    active = false;
                    clearInterval(timer);
                    abortRef.current?.abort();
                }
            })["ConnectorOnboarding.useEffect"];
        }
    }["ConnectorOnboarding.useEffect"], [
        refresh
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            if (openSignal === handled.current) return;
            handled.current = openSignal;
            setOpen(true);
            setConfirming(false);
            setError('');
            setMessage('');
            const target = requestedId || last.current.activeId;
            setSelected(target);
            const match = last.current.accounts.find({
                "ConnectorOnboarding.useEffect.match": (item)=>item.id === target
            }["ConnectorOnboarding.useEffect.match"]);
            if (match) setNetwork(match.platform);
            void refresh().catch({
                "ConnectorOnboarding.useEffect": (e)=>setError(e instanceof Error ? e.message : 'Unable to load connections')
            }["ConnectorOnboarding.useEffect"]);
        }
    }["ConnectorOnboarding.useEffect"], [
        openSignal,
        requestedId,
        refresh
    ]);
    // Check the provider tab without touching it until ownership can be proven.
    const pendingIds = accounts.filter((item)=>item.status === 'sign-in-open').map((item)=>item.id).join(',');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            if (!pendingIds) return;
            let live = true, inFlight = false;
            const check = {
                "ConnectorOnboarding.useEffect.check": async ()=>{
                    if (!live || inFlight) return;
                    inFlight = true;
                    try {
                        for (const id of pendingIds.split(',')){
                            const response = await fetch(`${path}/${encodeURIComponent(id)}/check`, {
                                method: 'POST',
                                headers: {
                                    'content-type': 'application/json'
                                },
                                body: '{}'
                            });
                            if (!response.ok) continue;
                            const result = await response.json();
                            if (result.status === 'connected') {
                                const updated = (await refresh()).find({
                                    "ConnectorOnboarding.useEffect.check.updated": (item)=>item.id === id
                                }["ConnectorOnboarding.useEffect.check.updated"]);
                                if (live && updated?.status === 'connected') {
                                    setSelected(id);
                                    setNetwork(updated.platform);
                                    setMessage(`${__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][updated.platform].name} session verified.`);
                                    onSelect(updated);
                                }
                            }
                        }
                    } catch  {
                    /* Keep waiting on network outages; manual retry remains available. */ } finally{
                        inFlight = false;
                    }
                }
            }["ConnectorOnboarding.useEffect.check"];
            const timer = setInterval({
                "ConnectorOnboarding.useEffect.timer": ()=>void check()
            }["ConnectorOnboarding.useEffect.timer"], 3500);
            return ({
                "ConnectorOnboarding.useEffect": ()=>{
                    live = false;
                    clearInterval(timer);
                }
            })["ConnectorOnboarding.useEffect"];
        }
    }["ConnectorOnboarding.useEffect"], [
        pendingIds,
        refresh,
        onSelect
    ]);
    const available = accounts.filter((item)=>item.platform === network);
    const chosen = available.find((item)=>item.id === selected) || available.find((item)=>item.id === activeId) || available[0] || null;
    async function command(id, operation) {
        if (working || saving) return;
        setError('');
        setMessage('');
        setConfirming(false);
        const controller = new AbortController();
        abortRef.current = controller;
        setWorking(operation);
        setWorkingId(id);
        const timer = setTimeout(()=>controller.abort(), 120000);
        try {
            const response = await fetch(`${path}/${encodeURIComponent(id)}/${operation}`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: '{}',
                signal: controller.signal
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'LinkedIn connection request failed');
            const updated = (await refresh()).find((row)=>row.id === id);
            if (result.status === 'connected') {
                if (updated) onSelect(updated);
                setSelected(id);
                setMessage(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][updated?.platform || network].name + ' session verified.');
            } else if (result.status === 'sign-in-open') {
                setSelected(id);
                setMessage(result.navigationWarning || 'Finish signing in to LinkedIn in the secure window, then select Verify connection.');
            } else if (result.status === 'reconnect-required') {
                setSelected(id);
                setError('LinkedIn sign-in is incomplete or expired. Finish sign-in, then verify again.');
            } else if (result.status === 'temporarily-unavailable') {
                setError('LinkedIn could not be reached. Your previous connection record was preserved.');
            } else if (result.status === 'disconnected') {
                if (updated && activeId === id) onSelect(updated);
                setMessage('LinkedIn disconnected from this workspace.');
            } else throw Error('Unexpected connection response');
        } catch (e) {
            setError(controller.signal.aborted ? 'Connection check stopped. You can retry.' : e instanceof Error ? e.message : 'LinkedIn connection failed');
        } finally{
            clearTimeout(timer);
            abortRef.current = null;
            setWorking(null);
            setWorkingId(null);
        }
    }
    async function beginNewConnection(provider) {
        if (working || saving || !capabilities?.browserAvailable || mobileClient) return;
        setError('');
        setMessage('');
        setSaving(true);
        try {
            const response = await fetch(`${path}/start`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    platform: provider
                })
            });
            const result = await response.json();
            if (!response.ok || !result.accountId) throw Error(result.error || 'Could not open provider sign-in');
            setNetwork(provider);
            setSelected(result.accountId);
            await refresh();
            setMessage(result.navigationWarning || 'Complete provider sign-in in Chrome, then select Verify connection.');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not start connection');
        } finally{
            setSaving(false);
        }
    }
    const busy = Boolean(working) || saving;
    const status = chosen?.status;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConnectorOnboarding.useEffect": ()=>{
            if (!chosen?.id || chosen.platform !== 'linkedin' || chosen.status === 'sign-in-open') {
                setOauth(null);
                return;
            }
            let live = true;
            void fetch(`/api/linkedin/oauth/status?accountId=${encodeURIComponent(chosen.id)}`, {
                cache: 'no-store'
            }).then({
                "ConnectorOnboarding.useEffect": async (response)=>{
                    if (!response.ok) throw Error('Publishing status unavailable');
                    return response.json();
                }
            }["ConnectorOnboarding.useEffect"]).then({
                "ConnectorOnboarding.useEffect": (result)=>{
                    if (live) setOauth(result);
                }
            }["ConnectorOnboarding.useEffect"]).catch({
                "ConnectorOnboarding.useEffect": ()=>{
                    if (live) setOauth(null);
                }
            }["ConnectorOnboarding.useEffect"]);
            return ({
                "ConnectorOnboarding.useEffect": ()=>{
                    live = false;
                }
            })["ConnectorOnboarding.useEffect"];
        }
    }["ConnectorOnboarding.useEffect"], [
        chosen?.id,
        chosen?.platform,
        chosen?.status
    ]);
    async function authorizePublishing(id) {
        if (busy) return;
        setError('');
        setSaving(true);
        try {
            const response = await fetch('/api/linkedin/oauth/start', {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    accountId: id
                })
            });
            const result = await response.json();
            if (!response.ok || !result.authorizationUrl) throw Error(result.error || 'Authorization unavailable');
            window.location.assign(result.authorizationUrl);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Unable to authorize LinkedIn');
            setSaving(false);
        }
    }
    const operation = status === 'connected' || status === 'sign-in-open' ? 'sync' : 'connect';
    const actionText = operation === 'connect' ? `Connect ${__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][network].name}` : status === 'connected' ? 'Check connection' : 'Verify connection';
    const browserLoginAvailable = chosen?.interactiveSignIn !== false && capabilities?.browserAvailable === true && !mobileClient;
    const canStart = Boolean(capabilities?.browserAvailable) && !mobileClient;
    const browserSupported = network === 'linkedin' || network === 'x';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            !hideTrigger && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>{
                    setOpen(true);
                    void refresh().catch((e)=>setError(e instanceof Error ? e.message : 'Unable to load connections'));
                },
                "aria-label": "Manage connected social accounts",
                className: `${button} border border-slate-200 bg-white text-slate-900`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkedInIcon"], {
                        className: "size-5"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                        lineNumber: 392,
                        columnNumber: 11
                    }, this),
                    " LinkedIn",
                    ' ',
                    chosen?.status === 'connected' ? 'connected' : 'connection'
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                lineNumber: 379,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: open,
                onDismiss: ()=>{
                    if (!busy) setOpen(false);
                },
                dismissible: !busy,
                testId: "connector-onboarding-dialog",
                title: "Connect your social accounts",
                titleSize: "prominent",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-testid": "linkedin-connector",
                    className: "mx-auto flex max-w-2xl flex-col gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$network$2d$picker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            network: network,
                            setNetwork: setNetwork,
                            setSelected: setSelected,
                            setConfirming: setConfirming,
                            setError: setError,
                            setMessage: setMessage
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                            lineNumber: 410,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$saved$2d$account$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            network: network,
                            ready: ready,
                            available: available,
                            chosen: chosen,
                            activeId: activeId,
                            status: status,
                            oauth: oauth,
                            busy: busy,
                            saving: saving,
                            working: working,
                            workingId: workingId,
                            operation: operation,
                            actionText: actionText,
                            browserLoginAvailable: browserLoginAvailable,
                            canStart: canStart,
                            browserSupported: browserSupported,
                            confirming: confirming,
                            mobileClient: mobileClient,
                            capabilities: capabilities,
                            setSelected: setSelected,
                            setConfirming: setConfirming,
                            setError: setError,
                            setMessage: setMessage,
                            command: (id, op)=>void command(id, op),
                            beginNewConnection: (provider)=>void beginNewConnection(provider),
                            authorizePublishing: (id)=>void authorizePublishing(id),
                            onSelect: onSelect,
                            abortRef: abortRef,
                            onManageProfile: onManageProfile,
                            setOpen: setOpen,
                            error: error,
                            message: message
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                            lineNumber: 419,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$sections$2f$connector$2d$other$2d$networks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            network: network,
                            showOtherNetworks: showOtherNetworks,
                            setShowOtherNetworks: setShowOtherNetworks,
                            setNetwork: setNetwork,
                            setSelected: setSelected,
                            setConfirming: setConfirming,
                            setError: setError,
                            setMessage: setMessage
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                            lineNumber: 454,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "px-1 text-xs leading-5 text-slate-600",
                            children: "Utomator does not collect your social password. Local Chrome attachment is optional. Hosted and mobile connections require supported provider authorization; workflows still require your review."
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                            lineNumber: 465,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                    lineNumber: 406,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx",
                lineNumber: 396,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ConnectorOnboarding, "kMffUXswXjUPPvntjPKxjZwRa08=");
_c = ConnectorOnboarding;
var _c;
__turbopack_context__.k.register(_c, "ConnectorOnboarding");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditorialDraftForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/file-text.mjs [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw.mjs [app-client] (ecmascript) <export default as RotateCcw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/trash.mjs [app-client] (ecmascript) <export default as Trash2>");
'use client';
;
;
const input = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-offset-2 focus-visible:outline-teal-700';
const button = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-slate-300 px-4 text-xs font-bold hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40';
function EditorialDraftForm({ save, selected, choose, accounts, accountId, setAccountId, research, content, setContent, sourcesText, setSourcesText, selectResearchEvidence, busy, unsaved, oauth, publish, transition }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        "aria-label": "LinkedIn editorial draft",
        onSubmit: (e)=>void save(e),
        className: "space-y-4 rounded-2xl border border-slate-200 bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-sm font-bold",
                        children: selected ? `Edit draft v${selected.version}` : 'New evidence-backed post'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: button,
                        onClick: ()=>choose(null),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this),
                            "New draft"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-4 sm:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-bold",
                        children: [
                            "Saved LinkedIn account",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: input,
                                required: true,
                                disabled: Boolean(selected),
                                value: accountId,
                                onChange: (e)=>setAccountId(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "Select account"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                        lineNumber: 108,
                                        columnNumber: 13
                                    }, this),
                                    accounts.map((account)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: account.id,
                                            children: [
                                                account.label,
                                                " (@",
                                                account.handle,
                                                ")"
                                            ]
                                        }, account.id, true, {
                                            fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                            lineNumber: 110,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 101,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-bold",
                        children: [
                            "Evidence from Creator Research (optional)",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: input,
                                disabled: selected?.status === 'archived',
                                value: content.researchRunId ?? '',
                                onChange: (e)=>selectResearchEvidence(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "No linked research"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, this),
                                    research.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: item.id,
                                            children: [
                                                item.input.niche,
                                                " · ",
                                                item.id.slice(0, 8)
                                            ]
                                        }, item.id, true, {
                                            fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 118,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-bold",
                        children: [
                            "Post goal",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: input,
                                minLength: 8,
                                maxLength: 220,
                                required: true,
                                value: content.goal,
                                onChange: (e)=>setContent((old)=>({
                                            ...old,
                                            goal: e.target.value
                                        }))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-bold",
                        children: [
                            "Content pillar",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: input,
                                minLength: 3,
                                maxLength: 100,
                                required: true,
                                value: content.pillar,
                                onChange: (e)=>setContent((old)=>({
                                            ...old,
                                            pillar: e.target.value
                                        }))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block space-y-1 text-xs font-bold",
                children: [
                    "Post draft",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        rows: 8,
                        className: `${input} resize-y leading-6`,
                        minLength: 20,
                        maxLength: 3000,
                        required: true,
                        value: content.body,
                        onChange: (e)=>setContent((old)=>({
                                    ...old,
                                    body: e.target.value
                                })),
                        placeholder: "Write an original, factual LinkedIn post. Confirm your claims and dates."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 161,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "block text-right text-[11px] font-normal text-slate-500",
                        children: [
                            content.body.length,
                            "/3000"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block space-y-1 text-xs font-bold",
                children: [
                    "Evidence links (one clean HTTPS URL per line; up to eight)",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        rows: 3,
                        className: `${input} resize-y`,
                        value: sourcesText,
                        onChange: (e)=>setSourcesText(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 177,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        disabled: busy || !accountId || Boolean(selected && ![
                            'draft',
                            'approved',
                            'publish-failed'
                        ].includes(selected.status)),
                        className: `${button} border-teal-700 bg-teal-700 text-white hover:bg-teal-800`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 201,
                                columnNumber: 11
                            }, this),
                            busy ? 'Saving…' : selected ? 'Save revision' : 'Create private draft'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this),
                    selected?.status === 'approved' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy || unsaved || !oauth?.connected,
                        className: button + ' border-teal-700 bg-teal-700 text-white hover:bg-teal-800',
                        onClick: ()=>void publish(),
                        children: "Publish approved post to LinkedIn"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 209,
                        columnNumber: 11
                    }, this),
                    selected?.status === 'draft' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy || unsaved,
                        title: unsaved ? 'Save the revised draft before approving' : undefined,
                        className: button,
                        onClick: ()=>void transition('approve'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this),
                            "Approve reviewed draft"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 222,
                        columnNumber: 11
                    }, this),
                    selected?.status === 'draft' && unsaved && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        role: "status",
                        className: "text-xs text-amber-700",
                        children: "Save your edits before approving this revision."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 236,
                        columnNumber: 11
                    }, this),
                    selected?.status === 'approved' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy || unsaved,
                        className: button,
                        onClick: ()=>void transition('reopen'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__["RotateCcw"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 247,
                                columnNumber: 13
                            }, this),
                            "Reopen for edits"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 241,
                        columnNumber: 11
                    }, this),
                    selected?.status === 'archived' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy,
                        className: button,
                        onClick: ()=>void transition('restore'),
                        children: "Restore draft"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 252,
                        columnNumber: 11
                    }, this),
                    selected && [
                        'draft',
                        'approved',
                        'publish-failed'
                    ].includes(selected.status) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy,
                        className: button,
                        onClick: ()=>void transition('archive'),
                        children: "Archive"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 263,
                        columnNumber: 13
                    }, this),
                    selected && [
                        'draft',
                        'approved',
                        'archived',
                        'publish-failed'
                    ].includes(selected.status) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: busy,
                        className: `${button} border-rose-300 text-rose-700`,
                        onClick: ()=>void transition('delete'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 282,
                                columnNumber: 15
                            }, this),
                            "Remove"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 276,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 186,
                columnNumber: 7
            }, this),
            selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-xl bg-slate-50 p-3 text-xs text-slate-700",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "Status: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                className: "capitalize",
                                children: selected.status
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                                lineNumber: 290,
                                columnNumber: 21
                            }, this),
                            " · Revision ",
                            selected.version,
                            " · ",
                            selected.history.length,
                            " persisted events"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 289,
                        columnNumber: 11
                    }, this),
                    selected.publication?.postUrn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        className: "mt-2 block text-teal-800 underline",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        href: 'https://www.linkedin.com/feed/update/' + selected.publication.postUrn + '/',
                        children: "View published LinkedIn post"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 295,
                        columnNumber: 13
                    }, this),
                    selected.status === 'publication-uncertain' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-rose-700",
                        children: "Publication outcome unknown. Check LinkedIn before taking any further action; automatic resubmission is blocked."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                        lineNumber: 309,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
                lineNumber: 288,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_c = EditorialDraftForm;
var _c;
__turbopack_context__.k.register(_c, "EditorialDraftForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditorialDraftList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function EditorialDraftList({ drafts, choose }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-slate-200 bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-sm font-bold",
                        children: "Saved drafts"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                        lineNumber: 17,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs text-slate-500",
                        children: [
                            drafts.length,
                            " private items"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            drafts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-4 text-sm text-slate-600",
                children: "No saved drafts. Create a post above or use research evidence to start one."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                lineNumber: 23,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 grid gap-2",
                children: drafts.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>choose(item),
                        className: "flex min-h-14 flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 text-left hover:border-teal-500",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "block text-xs font-bold",
                                        children: [
                                            item.content.pillar,
                                            " · ",
                                            item.content.goal
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                                        lineNumber: 37,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mt-1 block truncate text-xs text-slate-600",
                                        children: item.content.body.slice(0, 160)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                                        lineNumber: 40,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                                lineNumber: 36,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-teal-800 capitalize",
                                children: [
                                    item.status,
                                    " · v",
                                    item.version
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                                lineNumber: 44,
                                columnNumber: 15
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                        lineNumber: 30,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
                lineNumber: 28,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = EditorialDraftList;
var _c;
__turbopack_context__.k.register(_c, "EditorialDraftList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditorialStudioHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function EditorialStudioHeader() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "rounded-3xl bg-[#111e2b] px-6 py-7 text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs font-bold tracking-widest text-teal-300 uppercase",
                children: "LinkedIn / Editorial workflow"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "mt-3 font-serif text-3xl",
                children: "Draft, review and refine."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 max-w-2xl text-sm leading-6 text-slate-300",
                children: "Prepare posts for your own account, cite research evidence, maintain revision history, approve content and archive old drafts. This is private draft management, not LinkedIn publishing."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
_c = EditorialStudioHeader;
var _c;
__turbopack_context__.k.register(_c, "EditorialStudioHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LinkedInPublishingStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
const button = 'inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-slate-300 px-4 text-xs font-bold hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40';
function LinkedInPublishingStatus({ accountId, oauth, busy, connectPublishing, checkPublishingStatus, disconnectPublishing, setError }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-testid": "linkedin-publishing-connection",
        className: "rounded-2xl border border-slate-200 bg-white p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-sm font-bold",
                children: "LinkedIn API publishing authorization"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-xs leading-5 text-slate-600",
                children: "An authorized OAuth grant is required in addition to a saved profile. Review which LinkedIn member is signed in before publishing."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-xs font-semibold",
                children: [
                    oauth?.connected ? `Authorized member: ${oauth.subject}` : 'Not authorized for publishing',
                    oauth?.expiresAt ? ` · Expires ${new Date(oauth.expiresAt).toLocaleDateString()}` : ''
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 flex flex-wrap gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: button,
                        onClick: ()=>void connectPublishing(),
                        disabled: busy || !oauth?.configured,
                        children: "Authorize with LinkedIn"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: button,
                        onClick: ()=>void checkPublishingStatus(accountId).catch((e)=>setError(String(e))),
                        children: "Refresh authorization"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    oauth?.connected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: button,
                        onClick: ()=>void disconnectPublishing(),
                        children: "Disconnect"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            !oauth?.configured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-xs text-amber-700",
                children: "Publishing is unavailable until LinkedIn developer credentials, an HTTPS callback and an encryption key are configured on the server."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
                lineNumber: 79,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_c = LinkedInPublishingStatus;
var _c;
__turbopack_context__.k.register(_c, "LinkedInPublishingStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LinkedInEditorialStudio
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$draft$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$draft$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/editorial/sections/editorial-draft-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$studio$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/editorial/sections/editorial-studio-header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$linkedin$2d$publishing$2d$status$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/editorial/sections/linkedin-publishing-status.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const blank = ()=>({
        goal: '',
        pillar: '',
        body: '',
        sourceUrls: [],
        researchRunId: null
    });
function LinkedInEditorialStudio() {
    _s();
    const [accounts, setAccounts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]), [accountId, setAccountId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [research, setResearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]), [drafts, setDrafts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(blank());
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''), [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''), [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [sourcesText, setSourcesText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [oauth, setOauth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const refresh = async ()=>{
        const response = await fetch('/api/linkedin/drafts', {
            cache: 'no-store'
        });
        if (!response.ok) throw Error('Editorial drafts are unavailable');
        const rows = await response.json();
        setDrafts(rows);
        return rows;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LinkedInEditorialStudio.useEffect": ()=>{
            let alive = true;
            void Promise.all([
                fetch('/api/account', {
                    cache: 'no-store'
                }),
                fetch('/api/linkedin/research', {
                    cache: 'no-store'
                }),
                fetch('/api/linkedin/drafts', {
                    cache: 'no-store'
                })
            ]).then({
                "LinkedInEditorialStudio.useEffect": async (responses)=>{
                    if (responses.some({
                        "LinkedInEditorialStudio.useEffect": (item)=>!item.ok
                    }["LinkedInEditorialStudio.useEffect"])) throw Error('Unable to load account, research or editorial records');
                    const [account, report, items] = await Promise.all(responses.map({
                        "LinkedInEditorialStudio.useEffect": (r)=>r.json()
                    }["LinkedInEditorialStudio.useEffect"]));
                    if (!alive) return;
                    const linkedIn = account.socialAccounts.filter({
                        "LinkedInEditorialStudio.useEffect.linkedIn": (row)=>row.platform === 'linkedin'
                    }["LinkedInEditorialStudio.useEffect.linkedIn"]);
                    setAccounts(linkedIn);
                    setAccountId(linkedIn[0]?.id ?? '');
                    setResearch(report);
                    setDrafts(items);
                }
            }["LinkedInEditorialStudio.useEffect"]).catch({
                "LinkedInEditorialStudio.useEffect": (e)=>{
                    if (alive) setError(e instanceof Error ? e.message : 'Unable to load editorial studio');
                }
            }["LinkedInEditorialStudio.useEffect"]).finally({
                "LinkedInEditorialStudio.useEffect": ()=>{
                    if (alive) setLoading(false);
                }
            }["LinkedInEditorialStudio.useEffect"]);
            return ({
                "LinkedInEditorialStudio.useEffect": ()=>{
                    alive = false;
                }
            })["LinkedInEditorialStudio.useEffect"];
        }
    }["LinkedInEditorialStudio.useEffect"], []);
    async function checkPublishingStatus(id) {
        const response = await fetch(`/api/linkedin/oauth/status?accountId=${encodeURIComponent(id)}`, {
            cache: 'no-store'
        });
        const result = await response.json();
        if (!response.ok) throw Error(result.error || 'OAuth status unavailable');
        setOauth(result);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LinkedInEditorialStudio.useEffect": ()=>{
            if (!accountId) {
                setOauth(null);
                return;
            }
            void checkPublishingStatus(accountId).catch({
                "LinkedInEditorialStudio.useEffect": (e)=>setError(e instanceof Error ? e.message : 'Unable to read publishing status')
            }["LinkedInEditorialStudio.useEffect"]);
        }
    }["LinkedInEditorialStudio.useEffect"], [
        accountId,
        checkPublishingStatus
    ]);
    async function connectPublishing() {
        if (!accountId) return;
        setError('');
        setFeedback('');
        try {
            const response = await fetch('/api/linkedin/oauth/start', {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    accountId
                })
            });
            const result = await response.json();
            if (!response.ok || !result.authorizationUrl) throw Error(result.error || 'LinkedIn OAuth unavailable');
            window.location.assign(result.authorizationUrl);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not start LinkedIn authorization');
        }
    }
    async function disconnectPublishing() {
        if (!accountId || !window.confirm('Disconnect LinkedIn publishing authorization? Saved drafts will remain.')) return;
        setBusy(true);
        try {
            const response = await fetch('/api/linkedin/oauth/disconnect', {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    accountId
                })
            });
            if (!response.ok) throw Error((await response.json()).error || 'Disconnect failed');
            await checkPublishingStatus(accountId);
            setFeedback('Publishing authorization disconnected.');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Disconnect failed');
        } finally{
            setBusy(false);
        }
    }
    async function publish() {
        if (selected?.status !== 'approved' || unsaved || !oauth?.connected) return;
        if (!window.confirm('Publish this approved text-only draft as LinkedIn member ' + (oauth?.subject || 'unknown') + '? This creates a real public post, not a preview.')) return;
        setBusy(true);
        setError('');
        setFeedback('');
        try {
            const response = await fetch(`/api/linkedin/drafts/${selected.id}/publish`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    expectedVersion: selected.version,
                    confirmed: true
                })
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'LinkedIn publication failed');
            choose(result);
            await refresh();
            setFeedback('LinkedIn accepted this post. The provider ID is stored in your publication receipt.');
        } catch (e) {
            const reason = e instanceof Error ? e.message : 'LinkedIn publication failed';
            await refresh().then((rows)=>{
                const newest = rows.find((item)=>item.id === selected.id);
                if (newest) choose(newest);
            }).catch(()=>undefined);
            setError(reason);
        } finally{
            setBusy(false);
        }
    }
    function choose(draft) {
        setSelected(draft);
        setContent(draft ? {
            ...draft.content
        } : blank());
        setSourcesText(draft?.content.sourceUrls.join('\n') ?? '');
        if (draft) setAccountId(draft.accountId);
        setError('');
        setFeedback('');
    }
    function selectResearchEvidence(id) {
        const run = research.find((item)=>item.id === id);
        if (!run) {
            setContent((old)=>({
                    ...old,
                    researchRunId: null,
                    sourceUrls: []
                }));
            setSourcesText('');
            return;
        }
        const gap = run.output.gaps[0];
        const sourceUrls = (gap?.examples.length ? gap.examples : run.sources.map((s)=>s.url)).slice(0, 5);
        setContent((old)=>({
                ...old,
                researchRunId: run.id,
                pillar: gap?.topic ?? old.pillar,
                goal: old.goal || `Share an evidence-backed insight in ${run.input.niche}`,
                sourceUrls
            }));
        setSourcesText(sourceUrls.join('\n'));
    }
    function payload() {
        return {
            ...content,
            sourceUrls: sourcesText.split('\n').map((row)=>row.trim()).filter(Boolean)
        };
    }
    const unsaved = Boolean(selected && JSON.stringify(payload()) !== JSON.stringify(selected.content));
    async function command(url, method, body) {
        const response = await fetch(url, {
            method,
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(body)
        });
        const result = await response.json();
        if (!response.ok) throw Error(result.error || 'Editorial action failed');
        return result;
    }
    async function save(e) {
        e.preventDefault();
        setBusy(true);
        setError('');
        setFeedback('');
        try {
            if (!accountId) throw Error('Save a LinkedIn account in Profile before creating a draft');
            const result = selected ? await command(`/api/linkedin/drafts/${selected.id}`, 'PUT', {
                expectedVersion: selected.version,
                content: payload()
            }) : await command('/api/linkedin/drafts', 'POST', {
                accountId,
                content: payload()
            });
            choose(result);
            await refresh();
            setFeedback('Draft saved to your private workspace. No LinkedIn post was published.');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not save draft');
        } finally{
            setBusy(false);
        }
    }
    async function transition(action) {
        if (!selected) return;
        if (action === 'delete' && !window.confirm('Remove this internal draft from the list? It will not delete any LinkedIn post.')) return;
        setBusy(true);
        setError('');
        setFeedback('');
        try {
            const updated = await command(`/api/linkedin/drafts/${selected.id}/transition`, 'POST', {
                expectedVersion: selected.version,
                action,
                confirm: action === 'delete'
            });
            if (action === 'delete') {
                choose(null);
                setFeedback('Draft removed from your workspace list.');
            } else {
                choose(updated);
                setFeedback('Draft is now ' + updated.status + '. No LinkedIn post was published.');
            }
            await refresh();
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not change draft state');
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "linkedin-editorial-studio",
        className: "mx-auto max-w-5xl space-y-5 pb-16",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$studio$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 365,
                columnNumber: 7
            }, this),
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "text-sm text-slate-600",
                children: "Loading editorial records…"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 367,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 372,
                columnNumber: 9
            }, this),
            feedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "rounded-xl border border-teal-200 bg-teal-50 p-3 text-sm text-teal-900",
                children: feedback
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 380,
                columnNumber: 9
            }, this),
            !loading && accounts.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm",
                children: [
                    "Add your LinkedIn profile in",
                    ' ',
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        className: "font-bold underline",
                        href: "/dashboard/profile/connections",
                        children: "Profile / Connections"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                        lineNumber: 390,
                        columnNumber: 11
                    }, this),
                    ' ',
                    "to associate drafts with the correct account. No LinkedIn login is required for private draft preparation."
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 388,
                columnNumber: 9
            }, this),
            accountId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$linkedin$2d$publishing$2d$status$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                accountId: accountId,
                oauth: oauth,
                busy: busy,
                connectPublishing: ()=>void connectPublishing(),
                checkPublishingStatus: checkPublishingStatus,
                disconnectPublishing: ()=>void disconnectPublishing(),
                setError: setError
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 401,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$draft$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                save: save,
                selected: selected,
                choose: choose,
                accounts: accounts,
                accountId: accountId,
                setAccountId: setAccountId,
                research: research,
                content: content,
                setContent: setContent,
                sourcesText: sourcesText,
                setSourcesText: setSourcesText,
                selectResearchEvidence: selectResearchEvidence,
                busy: busy,
                unsaved: unsaved,
                oauth: oauth,
                publish: ()=>void publish(),
                transition: (action)=>void transition(action)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 411,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$sections$2f$editorial$2d$draft$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                drafts: drafts,
                choose: choose
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 430,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs leading-6 text-slate-600",
                children: "Approval confirms your internal editorial review only. These drafts are not automatically posted or scheduled. Source links identify user-submitted evidence, not verified LinkedIn analytics."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
                lineNumber: 431,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx",
        lineNumber: 361,
        columnNumber: 5
    }, this);
}
_s(LinkedInEditorialStudio, "QGSZ7HxwoJNtjjn0zoL8QlMZ2+w=");
_c = LinkedInEditorialStudio;
var _c;
__turbopack_context__.k.register(_c, "LinkedInEditorialStudio");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResearchHistoryList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-right.mjs [app-client] (ecmascript) <export default as ArrowRight>");
'use client';
;
;
function ResearchHistoryList({ history, setActive }) {
    if (history.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-slate-200 bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-sm font-bold",
                children: "Saved research reports"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 space-y-2",
                children: history.map((run)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setActive(run),
                        className: "flex min-h-11 w-full justify-between gap-3 rounded-xl border border-slate-200 p-3 text-left text-xs hover:bg-slate-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    run.input.niche,
                                    " · ",
                                    new Date(run.createdAt).toLocaleString()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
                                lineNumber: 24,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
                                lineNumber: 27,
                                columnNumber: 13
                            }, this)
                        ]
                    }, run.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
                        lineNumber: 18,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = ResearchHistoryList;
var _c;
__turbopack_context__.k.register(_c, "ResearchHistoryList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResearchInputForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-right.mjs [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/trash.mjs [app-client] (ecmascript) <export default as Trash2>");
'use client';
;
;
const field = 'min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-950 outline-teal-700';
function ResearchInputForm({ submit, niche, setNiche, objective, setObjective, ownerHeadline, setOwnerHeadline, creators, setCreators, updateCreator, updatePost, blank, saving }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        "aria-label": "Creator research inputs",
        onSubmit: (e)=>void submit(e),
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "grid gap-3 rounded-2xl border border-slate-200 bg-white p-5 sm:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-semibold",
                        children: [
                            "Your niche",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                required: true,
                                minLength: 3,
                                maxLength: 100,
                                className: field,
                                value: niche,
                                onChange: (e)=>setNiche(e.target.value),
                                placeholder: "Software education"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-semibold",
                        children: [
                            "Research objective",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                required: true,
                                minLength: 8,
                                maxLength: 400,
                                className: field,
                                value: objective,
                                onChange: (e)=>setObjective(e.target.value),
                                placeholder: "Build a more relevant audience"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "space-y-1 text-xs font-semibold sm:col-span-2",
                        children: [
                            "Your current LinkedIn headline",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                required: true,
                                minLength: 5,
                                maxLength: 300,
                                className: field,
                                value: ownerHeadline,
                                onChange: (e)=>setOwnerHeadline(e.target.value)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 84,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            creators.map((creator, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "space-y-3 rounded-2xl border border-slate-200 bg-white p-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-sm font-bold",
                                    children: [
                                        "Creator ",
                                        i + 1,
                                        ": observed source"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 100,
                                    columnNumber: 13
                                }, this),
                                creators.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "aria-label": `Remove creator ${i + 1}`,
                                    onClick: ()=>setCreators((rows)=>rows.filter((_, index)=>index !== i)),
                                    className: "inline-flex items-center gap-1 text-xs text-rose-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                            className: "size-4"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                            lineNumber: 112,
                                            columnNumber: 17
                                        }, this),
                                        "Remove"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 104,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-3 sm:grid-cols-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "space-y-1 text-xs font-semibold",
                                    children: [
                                        "Creator name",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            required: true,
                                            minLength: 2,
                                            maxLength: 120,
                                            className: field,
                                            value: creator.name,
                                            onChange: (e)=>updateCreator(i, {
                                                    name: e.target.value
                                                })
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "space-y-1 text-xs font-semibold",
                                    children: [
                                        "LinkedIn profile URL",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            required: true,
                                            type: "url",
                                            className: field,
                                            value: creator.profileUrl,
                                            onChange: (e)=>updateCreator(i, {
                                                    profileUrl: e.target.value
                                                }),
                                            placeholder: "https://www.linkedin.com/in/..."
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 129,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "space-y-1 text-xs font-semibold sm:col-span-2",
                                    children: [
                                        "Observed headline",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            required: true,
                                            minLength: 5,
                                            maxLength: 300,
                                            className: field,
                                            value: creator.headline,
                                            onChange: (e)=>updateCreator(i, {
                                                    headline: e.target.value
                                                })
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                            lineNumber: 144,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 142,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, this),
                        creator.posts.map((post, j)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2 rounded-xl bg-slate-50 p-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs font-bold",
                                                children: [
                                                    "Post example ",
                                                    j + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                                lineNumber: 157,
                                                columnNumber: 17
                                            }, this),
                                            creator.posts.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                "aria-label": `Remove post ${j + 1}`,
                                                onClick: ()=>updateCreator(i, {
                                                        posts: creator.posts.filter((_, k)=>k !== j)
                                                    }),
                                                className: "text-xs text-rose-700",
                                                children: "Remove"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                                lineNumber: 159,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                        lineNumber: 156,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block space-y-1 text-xs font-semibold",
                                        children: [
                                            "Post permalink",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                required: true,
                                                type: "url",
                                                className: field,
                                                value: post.url,
                                                onChange: (e)=>updatePost(i, j, 'url', e.target.value),
                                                placeholder: "https://www.linkedin.com/posts/..."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                                lineNumber: 175,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                        lineNumber: 173,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block space-y-1 text-xs font-semibold",
                                        children: [
                                            "Exact post excerpt",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                required: true,
                                                minLength: 20,
                                                maxLength: 3000,
                                                rows: 3,
                                                className: `${field} resize-y`,
                                                value: post.text,
                                                onChange: (e)=>updatePost(i, j, 'text', e.target.value)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                                lineNumber: 186,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                        lineNumber: 184,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, j, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this)),
                        creator.posts.length < 5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>updateCreator(i, {
                                    posts: [
                                        ...creator.posts,
                                        {
                                            url: '',
                                            text: ''
                                        }
                                    ]
                                }),
                            className: "inline-flex min-h-10 items-center gap-1 text-xs font-bold text-teal-800",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                    className: "size-4"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                    lineNumber: 208,
                                    columnNumber: 15
                                }, this),
                                "Add evidenced post"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                            lineNumber: 199,
                            columnNumber: 13
                        }, this)
                    ]
                }, i, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: creators.length >= 5,
                        onClick: ()=>setCreators((current)=>[
                                    ...current,
                                    blank()
                                ]),
                        className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-xs font-bold disabled:opacity-40",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 221,
                                columnNumber: 11
                            }, this),
                            "Add creator"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                        lineNumber: 215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        disabled: saving,
                        className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-teal-700 px-5 text-xs font-bold text-white disabled:opacity-50",
                        children: [
                            saving ? 'Analyzing…' : 'Run evidenced comparison',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                                lineNumber: 230,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                        lineNumber: 224,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
                lineNumber: 214,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_c = ResearchInputForm;
var _c;
__turbopack_context__.k.register(_c, "ResearchInputForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResearchReportPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/external-link.mjs [app-client] (ecmascript) <export default as ExternalLink>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/shield-check.mjs [app-client] (ecmascript) <export default as ShieldCheck>");
'use client';
;
;
function ResearchReportPanel({ active }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-testid": "creator-research-report",
        className: "space-y-4 rounded-2xl border border-slate-200 bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs font-bold text-teal-800",
                        children: "Completed read-only research"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "mt-1 font-serif text-2xl",
                        children: "Evidence-linked results"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-slate-600",
                children: [
                    "Objective: ",
                    active.input.objective
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-slate-600",
                children: [
                    active.output.profiles.length,
                    " profiles · ",
                    active.stages.length,
                    ' ',
                    "executed pipeline steps · ",
                    active.output.gaps.length,
                    " possible topics"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-sm font-bold",
                children: "Potential topics not present in your headline"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            active.output.gaps.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-slate-500",
                children: "No difference found in supplied excerpts."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-3",
                children: active.output.gaps.map((gap)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "rounded-xl bg-slate-50 p-3 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-bold capitalize",
                                children: gap.topic
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                lineNumber: 53,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-600",
                                children: [
                                    "Observed in ",
                                    gap.observedIn.join(', ')
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                lineNumber: 54,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 flex flex-wrap gap-3",
                                children: gap.examples.map((url)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: url,
                                        rel: "noopener noreferrer",
                                        target: "_blank",
                                        className: "inline-flex items-center gap-1 text-xs text-teal-800 underline",
                                        children: [
                                            "Evidence post",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                className: "size-3"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                                lineNumber: 67,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, url, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                        lineNumber: 59,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                lineNumber: 57,
                                columnNumber: 15
                            }, this)
                        ]
                    }, gap.topic, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                        lineNumber: 52,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 50,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-sm font-bold",
                children: "Experiments to evaluate"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                className: "space-y-2",
                children: active.output.experiments.map((experiment, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "rounded-xl border border-slate-200 p-3 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: [
                                    index + 1,
                                    ". ",
                                    experiment.hypothesis
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                lineNumber: 82,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-600",
                                children: experiment.measure
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                                lineNumber: 85,
                                columnNumber: 13
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                        lineNumber: 78,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "flex items-start gap-2 text-xs leading-6 text-slate-600",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                        className: "mt-1 size-4 shrink-0 text-teal-700"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    active.output.limitation
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c = ResearchReportPanel;
var _c;
__turbopack_context__.k.register(_c, "ResearchReportPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResearchStudioHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function ResearchStudioHeader() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "rounded-3xl bg-[#111e2b] px-6 py-7 text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs font-bold tracking-widest text-teal-300 uppercase",
                children: "LinkedIn / Research pipeline"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "mt-3 font-serif text-3xl",
                children: "Creator and niche intelligence"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 max-w-2xl text-sm leading-6 text-slate-300",
                children: "Compare documented examples you supply. Utomator checks source scope, extracts recurring topics, compares positioning, and proposes small experiments. It does not scrape profiles or invent growth metrics."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
_c = ResearchStudioHeader;
var _c;
__turbopack_context__.k.register(_c, "ResearchStudioHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LinkedInResearchStudio
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$history$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/research/sections/research-history-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$input$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/research/sections/research-input-form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$report$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/research/sections/research-report-panel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$studio$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/research/sections/research-studio-header.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const blank = ()=>({
        name: '',
        profileUrl: '',
        headline: '',
        posts: [
            {
                url: '',
                text: ''
            }
        ]
    });
function LinkedInResearchStudio() {
    _s();
    const [niche, setNiche] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''), [objective, setObjective] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [ownerHeadline, setOwnerHeadline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [creators, setCreators] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        blank()
    ]);
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [active, setActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''), [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LinkedInResearchStudio.useEffect": ()=>{
            let mounted = true;
            void fetch('/api/linkedin/research', {
                cache: 'no-store'
            }).then({
                "LinkedInResearchStudio.useEffect": async (response)=>{
                    if (!response.ok) throw Error('Research history unavailable');
                    const rows = await response.json();
                    if (mounted) {
                        setHistory(rows);
                        setActive(rows[0] ?? null);
                    }
                }
            }["LinkedInResearchStudio.useEffect"]).catch({
                "LinkedInResearchStudio.useEffect": (e)=>{
                    if (mounted) setError(e instanceof Error ? e.message : 'Unable to load research');
                }
            }["LinkedInResearchStudio.useEffect"]);
            return ({
                "LinkedInResearchStudio.useEffect": ()=>{
                    mounted = false;
                }
            })["LinkedInResearchStudio.useEffect"];
        }
    }["LinkedInResearchStudio.useEffect"], []);
    const updateCreator = (index, patch)=>setCreators((rows)=>rows.map((creator, i)=>index === i ? {
                    ...creator,
                    ...patch
                } : creator));
    const updatePost = (index, p, key, value)=>setCreators((rows)=>rows.map((creator, i)=>index !== i ? creator : {
                    ...creator,
                    posts: creator.posts.map((post, j)=>p === j ? {
                            ...post,
                            [key]: value
                        } : post)
                }));
    async function submit(event) {
        event.preventDefault();
        setError('');
        setSaving(true);
        try {
            const response = await fetch('/api/linkedin/research', {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    niche,
                    objective,
                    ownerHeadline,
                    creators
                })
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'Research pipeline failed');
            setActive(result);
            setHistory((previous)=>[
                    result,
                    ...previous
                ]);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Research failed');
        } finally{
            setSaving(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "linkedin-creator-research",
        className: "mx-auto max-w-5xl space-y-5 pb-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$studio$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$input$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                submit: submit,
                niche: niche,
                setNiche: setNiche,
                objective: objective,
                setObjective: setObjective,
                ownerHeadline: ownerHeadline,
                setOwnerHeadline: setOwnerHeadline,
                creators: creators,
                setCreators: setCreators,
                updateCreator: updateCreator,
                updatePost: updatePost,
                blank: blank,
                saving: saving
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
                lineNumber: 141,
                columnNumber: 9
            }, this),
            active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$report$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                active: active
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
                lineNumber: 148,
                columnNumber: 18
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$sections$2f$research$2d$history$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                history: history,
                setActive: (run)=>setActive(run)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
                lineNumber: 149,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
}
_s(LinkedInResearchStudio, "wfpBPk+WO8qNoaHRTPRl23mls80=");
_c = LinkedInResearchStudio;
var _c;
__turbopack_context__.k.register(_c, "LinkedInResearchStudio");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/reviews/annotation-voice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "matchAnnotationAction",
    ()=>matchAnnotationAction,
    "mergeSpokenComment",
    ()=>mergeSpokenComment
]);
const ACTION_PATTERNS = [
    {
        action: 'add-skill',
        pattern: /\badd(?:\s+(?:a|the))?\s+skill\b/i
    },
    {
        action: 'edit-profile',
        pattern: /\bedit\s+(?:my\s+)?(?:headline|profile)\b/i
    },
    {
        action: 'inspect',
        pattern: /\binspect\b/i
    }
];
function matchAnnotationAction(utterance, allowed) {
    const found = ACTION_PATTERNS.find((item)=>item.pattern.test(utterance));
    if (!found || !allowed.includes(found.action)) return null;
    return found.action;
}
function mergeSpokenComment(current, utterance) {
    const next = utterance.trim();
    if (!next) return current;
    const existing = current.trim();
    if (!existing) return next;
    if (existing.toLowerCase().includes(next.toLowerCase())) return existing;
    return `${existing} ${next}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VisualReviewSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/tag.mjs [app-client] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/trash.mjs [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-composer.tsx [app-client] (ecmascript)");
'use client';
;
;
;
const actionOptions = [
    {
        value: 'inspect',
        label: 'Read this location'
    },
    {
        value: 'suggest',
        label: 'Suggest a change'
    },
    {
        value: 'audit-page',
        label: 'Inspect selected page'
    },
    {
        value: 'edit-profile',
        label: 'Prepare profile edit'
    },
    {
        value: 'edit-experience',
        label: 'Prepare experience edit'
    },
    {
        value: 'compose-post',
        label: 'Prepare a post'
    },
    {
        value: 'add-skill',
        label: 'Prepare skill update'
    },
    {
        value: 'edit-website',
        label: 'Prepare website change'
    },
    {
        value: 'edit-services',
        label: 'Prepare services change'
    },
    {
        value: 'add-project',
        label: 'Prepare project entry'
    },
    {
        value: 'add-featured',
        label: 'Prepare Featured entry'
    },
    {
        value: 'pin-post',
        label: 'Prepare post pin'
    },
    {
        value: 'delete-post',
        label: 'Prepare post deletion'
    },
    {
        value: 'upload-banner',
        label: 'Prepare banner update'
    }
];
function VisualReviewSidebar({ annotations, selectedId, setSelectedId, selected, allowedActions, updateAnnotation, setAnnotations, record, removeSelected, commentVoice, error, saving, tag }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-w-0 flex-col gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-sm font-extrabold text-slate-900",
                        children: "Location actions"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 text-xs leading-5 text-slate-500",
                        children: "Select a numbered mark to link an action and optional comment. Actions are plans, not automatic website clicks."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-h-[270px] space-y-1 overflow-y-auto",
                "aria-label": "Annotated locations",
                children: annotations.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "rounded-xl border border-dashed border-slate-200 p-3 text-xs text-slate-500",
                    children: "Choose Circle, Rectangle, or Draw, then mark the screenshot."
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                    lineNumber: 86,
                    columnNumber: 11
                }, this) : annotations.map((a, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setSelectedId(a.id),
                        "aria-pressed": a.id === selectedId,
                        className: 'flex min-h-11 w-full items-center gap-3 rounded-xl border px-3 text-left text-xs font-semibold ' + (selectedId === a.id ? 'border-teal-600 bg-teal-50 text-teal-900' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "flex size-6 items-center justify-center rounded-full bg-slate-900 text-[10px] text-white",
                                children: i + 1
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 103,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "min-w-0 flex-1 truncate",
                                children: [
                                    a.action.replaceAll('-', ' '),
                                    " · ",
                                    a.shape
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 106,
                                columnNumber: 15
                            }, this)
                        ]
                    }, a.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 91,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "selected-annotation",
                className: "space-y-3 rounded-xl border border-teal-200 bg-teal-50/50 p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-xs font-bold text-slate-800",
                        children: [
                            "Action",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                "aria-label": "Annotation action",
                                value: selected.action,
                                onChange: (e)=>updateAnnotation({
                                        ...selected,
                                        action: e.target.value
                                    }, 'action'),
                                className: "mt-1.5 min-h-11 w-full rounded-lg border border-slate-200 bg-white px-2 text-xs",
                                children: actionOptions.filter((option)=>allowedActions.includes(option.value)).map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: option.value,
                                        children: option.label
                                    }, option.value, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                        lineNumber: 137,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 118,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "annotation-comment",
                                        className: "text-xs font-bold text-slate-800",
                                        children: "Comment"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                        lineNumber: 145,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$composer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VoiceMicButton"], {
                                        size: "md",
                                        listening: commentVoice.listening,
                                        disabled: commentVoice.support === 'unsupported',
                                        onClick: commentVoice.toggleListen,
                                        label: "Speak a comment"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                        lineNumber: 151,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 144,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                id: "annotation-comment",
                                "aria-label": "Annotation comment",
                                rows: 3,
                                maxLength: 800,
                                value: selected.comment,
                                onChange: (e)=>setAnnotations((prev)=>prev.map((item)=>item.id === selected.id ? {
                                                ...item,
                                                comment: e.target.value
                                            } : item)),
                                onBlur: ()=>record('comment', selected.id, annotations.find((item)=>item.id === selected.id)),
                                placeholder: "Say what Mator should review here, or type it.",
                                className: "w-full resize-y rounded-lg border border-slate-200 bg-white p-2 text-base"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 159,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "aria-live": "polite",
                                className: "text-sm text-slate-700",
                                children: commentVoice.interim || (commentVoice.support === 'unsupported' ? 'Voice needs Chrome or Edge on this machine. Type a comment instead.' : 'Tap the mic to speak this comment.')
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 184,
                                columnNumber: 13
                            }, this),
                            commentVoice.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                role: "alert",
                                className: "text-xs text-rose-700",
                                children: commentVoice.error
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 191,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 143,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-mono text-[10px] text-slate-500",
                        children: [
                            "x ",
                            selected.x.toFixed(3),
                            " · y ",
                            selected.y.toFixed(3),
                            " · w",
                            ' ',
                            selected.width.toFixed(3),
                            " · h ",
                            selected.height.toFixed(3)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 196,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: removeSelected,
                        className: "inline-flex items-center gap-1 text-xs font-semibold text-rose-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 205,
                                columnNumber: 13
                            }, this),
                            "Remove mark"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 200,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                lineNumber: 114,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-auto space-y-2 border-t border-slate-200 pt-3",
                children: [
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "alert",
                        className: "text-xs text-rose-700",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 212,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: !annotations.length || saving,
                        onClick: ()=>void tag(),
                        className: "flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-slate-950 px-3 text-xs font-bold text-white hover:bg-teal-900 disabled:opacity-40",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                                lineNumber: 222,
                                columnNumber: 11
                            }, this),
                            saving ? 'Saving annotation YAML…' : 'Tag to Chat & Workflow'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[10px] leading-4 text-slate-500",
                        children: "Saves the original image, mark geometry, actions, comments, and edit history. Any external edit still requires live inspection and approval."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
                lineNumber: 210,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
_c = VisualReviewSidebar;
var _c;
__turbopack_context__.k.register(_c, "VisualReviewSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VisualReviewPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Circle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle.mjs [app-client] (ecmascript) <export default as Circle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/eraser.mjs [app-client] (ecmascript) <export default as Eraser>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mouse$2d$pointer$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MousePointer2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/mouse-pointer-2.mjs [app-client] (ecmascript) <export default as MousePointer2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/pen-line.mjs [app-client] (ecmascript) <export default as PenLine>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rectangle$2d$horizontal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rectangle-horizontal.mjs [app-client] (ecmascript) <export default as RectangleHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw.mjs [app-client] (ecmascript) <export default as RotateCcw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/use-voice-session.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$annotation$2d$voice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/reviews/annotation-voice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$sections$2f$visual$2d$review$2d$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/reviews/sections/visual-review-sidebar.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const clamp = (value)=>Math.max(0, Math.min(1, value));
const tools = [
    {
        kind: 'ellipse',
        label: 'Circle',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Circle$3e$__["Circle"]
    },
    {
        kind: 'rectangle',
        label: 'Rectangle',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rectangle$2d$horizontal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RectangleHorizontal$3e$__["RectangleHorizontal"]
    },
    {
        kind: 'freehand',
        label: 'Draw',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__["PenLine"]
    }
];
function geometry(start, end) {
    const x = Math.min(start.x, end.x), y = Math.min(start.y, end.y);
    const width = Math.max(0.012, Math.abs(start.x - end.x));
    const height = Math.max(0.012, Math.abs(start.y - end.y));
    return {
        x: Math.min(x, 1 - width),
        y: Math.min(y, 1 - height),
        width,
        height
    };
}
function outline(item, selected) {
    const stroke = selected ? '#0891b2' : '#0f766e';
    if (item.shape === 'freehand') return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
        points: (item.points ?? []).map((p)=>`${p.x * 1000},${p.y * 1000}`).join(' '),
        fill: "none",
        stroke: stroke,
        strokeWidth: selected ? 6 : 4,
        strokeLinecap: "round",
        strokeLinejoin: "round"
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
        lineNumber: 69,
        columnNumber: 7
    }, this);
    const x = item.x * 1000, y = item.y * 1000, width = item.width * 1000, height = item.height * 1000;
    return item.shape === 'ellipse' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ellipse", {
        cx: x + width / 2,
        cy: y + height / 2,
        rx: width / 2,
        ry: height / 2,
        fill: stroke,
        fillOpacity: 0.09,
        stroke: stroke,
        strokeWidth: selected ? 5 : 3
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
        lineNumber: 85,
        columnNumber: 5
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
        x: x,
        y: y,
        width: width,
        height: height,
        rx: 5,
        fill: stroke,
        fillOpacity: 0.09,
        stroke: stroke,
        strokeWidth: selected ? 5 : 3
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
function VisualReviewPanel({ source, platform, handle, pageUrl, nodeId, onClose, onSave }) {
    _s();
    const imageRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(1);
    const [tool, setTool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('ellipse');
    const [gesture, setGesture] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [annotations, setAnnotations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(source.kind === 'review' ? source.initialAnnotations ?? [] : []);
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [events, setEvents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedId, setSelectedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const selected = annotations.find((a)=>a.id === selectedId);
    const allowedActions = [
        'inspect',
        'suggest',
        'audit-page',
        ...platform === 'x' ? [
            'edit-profile',
            'compose-post',
            'pin-post',
            'delete-post',
            'upload-banner'
        ] : [
            'edit-profile',
            'edit-experience',
            'edit-website',
            'edit-services',
            'add-project',
            'add-featured',
            'add-skill'
        ]
    ].filter(Boolean);
    const record = (kind, annotationId, annotation)=>setEvents((previous)=>[
                ...previous,
                {
                    kind,
                    annotationId,
                    at: new Date().toISOString(),
                    annotation
                }
            ]);
    const position = (event)=>{
        const bounds = imageRef.current?.getBoundingClientRect();
        if (!bounds?.width || !bounds.height) return null;
        return {
            x: clamp((event.clientX - bounds.left) / bounds.width),
            y: clamp((event.clientY - bounds.top) / bounds.height)
        };
    };
    function pointerDown(event) {
        if (event.button !== 0 || saving || annotations.length >= 15) return;
        const p = position(event);
        if (!p) return;
        setGesture({
            start: p,
            end: p,
            points: [
                p
            ]
        });
        event.currentTarget.setPointerCapture(event.pointerId);
    }
    function pointerMove(event) {
        if (!gesture) return;
        const p = position(event);
        if (!p) return;
        setGesture((prev)=>prev ? {
                ...prev,
                end: p,
                points: tool === 'freehand' && prev.points.length < 250 ? [
                    ...prev.points,
                    p
                ] : prev.points
            } : prev);
    }
    function pointerUp(event) {
        if (!gesture) return;
        const p = position(event) ?? gesture.end;
        const points = tool === 'freehand' ? [
            ...gesture.points,
            p
        ].slice(0, 250) : undefined;
        const box = tool === 'freehand' ? geometry({
            x: Math.min(...points?.map((q)=>q.x)),
            y: Math.min(...points?.map((q)=>q.y))
        }, {
            x: Math.max(...points?.map((q)=>q.x)),
            y: Math.max(...points?.map((q)=>q.y))
        }) : geometry(gesture.start, p);
        if (tool === 'freehand' && points?.length < 2) {
            setGesture(null);
            return;
        }
        const annotation = {
            id: `mark-${Date.now().toString(36)}-${nextId.current++}`,
            shape: tool,
            ...box,
            ...points ? {
                points
            } : {},
            action: 'inspect',
            comment: ''
        };
        setHistory((prev)=>[
                ...prev,
                annotations
            ]);
        setAnnotations((prev)=>[
                ...prev,
                annotation
            ]);
        record('draw', annotation.id, annotation);
        setSelectedId(annotation.id);
        setGesture(null);
        setError('');
    }
    function updateAnnotation(next, kind) {
        setHistory((prev)=>[
                ...prev,
                annotations
            ]);
        setAnnotations((prev)=>prev.map((a)=>a.id === next.id ? next : a));
        record(kind, next.id, next);
    }
    const commentVoice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceSession"])({
        onFinal: {
            "VisualReviewPanel.useVoiceSession[commentVoice]": (utterance)=>{
                const current = annotations.find({
                    "VisualReviewPanel.useVoiceSession[commentVoice].current": (item)=>item.id === selectedId
                }["VisualReviewPanel.useVoiceSession[commentVoice].current"]);
                if (!current) return;
                const action = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$annotation$2d$voice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchAnnotationAction"])(utterance, allowedActions);
                updateAnnotation({
                    ...current,
                    comment: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$annotation$2d$voice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeSpokenComment"])(current.comment, utterance),
                    ...action ? {
                        action: action
                    } : {}
                }, 'comment');
            }
        }["VisualReviewPanel.useVoiceSession[commentVoice]"]
    });
    function removeSelected() {
        if (!selected) return;
        setHistory((prev)=>[
                ...prev,
                annotations
            ]);
        setAnnotations((prev)=>prev.filter((a)=>a.id !== selected.id));
        record('remove', selected.id, selected);
        setSelectedId(null);
    }
    function undo() {
        if (!history.length) return;
        const prior = history[history.length - 1];
        setHistory((prev)=>prev.slice(0, -1));
        setAnnotations(prior);
        record('undo', selectedId ?? 'all');
        if (!prior.some((a)=>a.id === selectedId)) setSelectedId(null);
    }
    async function tag() {
        if (!annotations.length) {
            setError('Circle, box, or draw at least one location.');
            return;
        }
        setSaving(true);
        setError('');
        try {
            await onSave({
                platform,
                handle,
                pageUrl,
                nodeId,
                note: source.kind === 'upload' ? source.draftNote ?? '' : '',
                annotations,
                editEvents: [
                    ...events,
                    {
                        kind: 'tag',
                        annotationId: 'all',
                        at: new Date().toISOString()
                    }
                ],
                source: source.kind === 'capture' ? {
                    kind: 'capture',
                    runId: source.runId,
                    fileName: source.fileName
                } : source.kind === 'upload' ? {
                    kind: 'upload',
                    imageData: source.imageData
                } : {
                    kind: 'review',
                    reviewId: source.reviewId
                }
            });
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not tag the annotated image');
        } finally{
            setSaving(false);
        }
    }
    const draft = gesture ? {
        id: 'preview',
        shape: tool,
        ...geometry(gesture.start, gesture.end),
        ...tool === 'freehand' ? {
            points: gesture.points
        } : {},
        action: 'inspect',
        comment: ''
    } : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: true,
        title: "Image annotation studio",
        description: "Draw directly on the captured image, assign an action to each mark, then tag it to Mator and the workflow.",
        onDismiss: onClose,
        size: "wide",
        testId: "visual-review-dialog",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1fr)_250px]",
            "data-testid": "annotation-editor",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-w-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            role: "toolbar",
                            "aria-label": "Annotation drawing tools",
                            className: "mb-3 flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-slate-50 p-1.5",
                            children: [
                                tools.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "aria-label": item.label,
                                        "aria-pressed": tool === item.kind,
                                        onClick: ()=>setTool(item.kind),
                                        className: 'inline-flex min-h-10 items-center gap-2 rounded-lg px-3 text-xs font-bold ' + (tool === item.kind ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-white'),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.Icon, {
                                                className: "size-4"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                lineNumber: 352,
                                                columnNumber: 17
                                            }, this),
                                            item.label
                                        ]
                                    }, item.kind, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                        lineNumber: 339,
                                        columnNumber: 15
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ml-auto flex gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            "aria-label": "Undo annotation",
                                            disabled: !history.length,
                                            onClick: undo,
                                            className: "inline-flex size-10 items-center justify-center rounded-lg text-slate-600 hover:bg-white disabled:opacity-30",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__["RotateCcw"], {
                                                className: "size-4"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                lineNumber: 364,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                            lineNumber: 357,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            "aria-label": "Remove selected annotation",
                                            disabled: !selected,
                                            onClick: removeSelected,
                                            className: "inline-flex size-10 items-center justify-center rounded-lg text-rose-700 hover:bg-rose-50 disabled:opacity-30",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__["Eraser"], {
                                                className: "size-4"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                lineNumber: 373,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                            lineNumber: 366,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                    lineNumber: 356,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                            lineNumber: 333,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: imageRef,
                            "data-testid": "annotation-image",
                            className: "relative w-full cursor-crosshair touch-none overflow-hidden rounded-xl border border-slate-200 bg-slate-100 select-none",
                            onPointerDown: pointerDown,
                            onPointerMove: pointerMove,
                            onPointerUp: pointerUp,
                            onPointerCancel: ()=>setGesture(null),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    unoptimized: true,
                                    src: source.src,
                                    alt: "Captured image ready for annotation",
                                    width: 1200,
                                    height: 800,
                                    className: "pointer-events-none block h-auto w-full",
                                    draggable: false
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                    lineNumber: 386,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "pointer-events-none absolute inset-0 size-full",
                                    viewBox: "0 0 1000 1000",
                                    preserveAspectRatio: "none",
                                    "aria-hidden": "true",
                                    children: [
                                        annotations.map((a, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                children: [
                                                    outline(a, a.id === selectedId),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                        cx: a.x * 1000 + 12,
                                                        cy: a.y * 1000 + 12,
                                                        r: "13",
                                                        fill: "#0f172a",
                                                        stroke: "white",
                                                        strokeWidth: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                        lineNumber: 404,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                                        x: a.x * 1000 + 12,
                                                        y: a.y * 1000 + 17,
                                                        textAnchor: "middle",
                                                        fontSize: "17",
                                                        fontWeight: "bold",
                                                        fill: "white",
                                                        children: i + 1
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                        lineNumber: 412,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, a.id, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                                lineNumber: 402,
                                                columnNumber: 17
                                            }, this)),
                                        draft && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                            opacity: 0.8,
                                            children: outline(draft, true)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                            lineNumber: 424,
                                            columnNumber: 25
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                    lineNumber: 395,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                            lineNumber: 377,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-2 flex items-center justify-between text-xs text-slate-500",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mouse$2d$pointer$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MousePointer2$3e$__["MousePointer2"], {
                                            className: "mr-1 inline size-3.5"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                            lineNumber: 429,
                                            columnNumber: 15
                                        }, this),
                                        "Drag to mark a precise location · normalized coordinates"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                    lineNumber: 428,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        annotations.length,
                                        "/15"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                                    lineNumber: 432,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                            lineNumber: 427,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                    lineNumber: 332,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$sections$2f$visual$2d$review$2d$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    annotations: annotations,
                    selectedId: selectedId,
                    setSelectedId: setSelectedId,
                    selected: selected,
                    allowedActions: allowedActions,
                    updateAnnotation: updateAnnotation,
                    setAnnotations: setAnnotations,
                    record: record,
                    removeSelected: removeSelected,
                    commentVoice: commentVoice,
                    error: error,
                    saving: saving,
                    tag: tag
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
                    lineNumber: 435,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
            lineNumber: 328,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx",
        lineNumber: 320,
        columnNumber: 5
    }, this);
}
_s(VisualReviewPanel, "AdF2yeiFXipGRE67pcF6jOkx9JE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceSession"]
    ];
});
_c = VisualReviewPanel;
var _c;
__turbopack_context__.k.register(_c, "VisualReviewPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/dashboard-shell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/message-square.mjs [app-client] (ecmascript) <export default as MessageSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$home$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-home.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$career$2f$career$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/career/career-studio.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$career$2f$intelligence$2f$activity$2d$intelligence$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/career/intelligence/activity-intelligence.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$connector$2d$onboarding$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/connector-onboarding.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$crafts$2f$crafts$2d$library$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/crafts/crafts-library.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$linkedin$2d$editorial$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/editorial/linkedin-editorial-studio.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$linkedin$2d$research$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/research/linkedin-research-studio.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$visual$2d$review$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/reviews/visual-review-panel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$run$2d$speech$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-run-speech.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-voice-preference.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$operator$2d$chat$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/operator-chat-panel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$hooks$2f$use$2d$growth$2d$profile$2d$workflow$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/hooks/use-growth-profile-workflow.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$hooks$2f$use$2d$growth$2d$execution$2d$projection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/hooks/use-growth-execution-projection.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$ai$2d$call$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/use-mator-ai-call.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$chat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/use-mator-chat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$visual$2d$reviews$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/use-visual-reviews.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/use-voice-session.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/svgs/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$build$2d$run$2d$payload$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/build-run-payload.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$checkpoint$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$bottom$2d$nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$pipeline$2d$workspace$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$history$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$dashboard$2d$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/use-dashboard-navigation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$operator$2d$commands$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/use-operator-commands.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$run$2d$monitor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/use-run-monitor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$workflow$2d$workspace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/use-workflow-workspace.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/visual-review-model.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workflow-catalog.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function DashboardShell({ initialPane = 'workspace' }) {
    _s();
    const { pathname, pane, setPane, selectedCraftId, selectedCraftSlug, libraryView, navigate, navigatePane, navigateSubpage, navigateCraft, navigateCraftView } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$dashboard$2d$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDashboardNavigation"])(initialPane);
    const [activeConnector, setActiveConnector] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [connectorRequest, setConnectorRequest] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [connectorOpenSignal, setConnectorOpenSignal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [chatVisible, setChatVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [configRequest, setConfigRequest] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [mobileChatOpen, setMobileChatOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [craftsRevision, setCraftsRevision] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [, setSelectedNode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('inspect');
    const [scopeSection, setScopeSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('profile');
    const [runFormError, setRunFormError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const setConversationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        "DashboardShell.useRef[setConversationRef]": ()=>{}
    }["DashboardShell.useRef[setConversationRef]"]);
    const { available, runs, active, events, checkpoint, checkpointError, inputReply, setInputReply, reviews, currentRunId, refresh, startMonitoredRun, selectRun, pauseRun, resumeRun, act, cancelRun } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$run$2d$monitor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRunMonitor"])({
        "DashboardShell.useRunMonitor": (text)=>setConversationRef.current({
                "DashboardShell.useRunMonitor": (previous)=>[
                        ...previous,
                        {
                            id: Date.now(),
                            sender: 'assistant',
                            text
                        }
                    ]
            }["DashboardShell.useRunMonitor"])
    }["DashboardShell.useRunMonitor"], {
        "DashboardShell.useRunMonitor": (text)=>setRunFormError(text)
    }["DashboardShell.useRunMonitor"]);
    const busy = Boolean(active && [
        'running',
        'paused',
        'input-needed',
        'approval-needed'
    ].includes(active.state));
    const { platform, setPlatform, handle, setHandle, action, setAction, form, setForm, workflowPlan, setWorkflowPlan, templatePlans, selectedGrowthTemplateId, setSelectedGrowthTemplateId, workspaceOpen, setWorkspaceOpen, savedWorkflows, beginNewWorkflow, openActionWorkflow, selectSavedWorkflow, closeWorkspace, activeWorkflow, setActiveWorkflow, loadingWorkflow, planDirty, setPlanDirty, planSaving, formDirty, saveWorkflowPlan, applyGrowthTemplate, applyTemplate, invalidateWorkflowSelection } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$workflow$2d$workspace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkflowWorkspace"])({
        busy,
        setRunFormError
    });
    const workspaceGrowth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$hooks$2f$use$2d$growth$2d$profile$2d$workflow$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGrowthProfileWorkflow"])(platform, selectedGrowthTemplateId, activeConnector?.status === 'connected' && activeConnector.platform === 'linkedin' ? activeConnector.id : undefined);
    const { projection: workspaceExecution, error: workspaceJournalError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$hooks$2f$use$2d$growth$2d$execution$2d$projection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGrowthExecutionProjection"])(workspaceGrowth.run);
    async function submitWorkspaceCheckpoint(runId, checkpointId, type, payload) {
        const child = workspaceGrowth.run?.currentChild;
        if (!child || child.id !== runId || child.checkpoint?.id !== checkpointId || type === 'decision' && child.state !== 'approval-needed' || type === 'input' && child.state !== 'input-needed') throw Error('Checkpoint is no longer pending for this workspace');
        await workspaceGrowth.mutate(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$profile$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["request"])('/api/runs/' + encodeURIComponent(runId) + '/' + type, 'POST', {
                checkpointId,
                ...payload
            }));
    }
    function selectSocialAccount(account) {
        setConnectorRequest(account.id);
        setConnectorOpenSignal((value)=>value + 1);
    }
    const selected = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workflows"][platform].find((workflow)=>workflow.id === action) || __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workflows"][platform][0];
    const normalizedHandle = handle.trim().replace(/^@/, '');
    const profilePage = activeConnector?.platform === platform && activeConnector.handle.toLowerCase() === normalizedHandle.toLowerCase() ? activeConnector.profileUrl : '';
    const selectedPage = profilePage && platform === 'linkedin' && scopeSection !== 'profile' ? `${profilePage.replace(/\/$/, '')}/details/${scopeSection}/` : profilePage;
    const pageOptions = platform === 'linkedin' ? [
        'profile',
        'experience',
        'skills',
        'projects',
        'featured'
    ] : [
        'profile'
    ];
    const connectorReady = activeConnector?.platform === platform && activeConnector.status === 'connected';
    const PlatformIcon = platform === 'linkedin' ? __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkedInIcon"] : __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$svgs$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TwitterIcon"];
    const platformLabel = platform === 'linkedin' ? 'LinkedIn' : 'X';
    const submitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        "DashboardShell.useRef[submitRef]": ()=>{}
    }["DashboardShell.useRef[submitRef]"]);
    const pendingAssetsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const voice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceSession"])({
        onFinal: {
            "DashboardShell.useVoiceSession[voice]": (text)=>submitRef.current(text, 'voice')
        }["DashboardShell.useVoiceSession[voice]"]
    });
    const voiceOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceOnlyPreference"])();
    const callActiveRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const voiceScopeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const spokenRunRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        runId: null,
        seen: new Set()
    });
    const { message, setMessage, conversation, setConversation, chatNotice, send, sendCallTurn, sendMessage: sendMatorMessage, confirmStage, rejectStage, newConversation, switchConversation, restorePipeline, uploadForClarify, saveMarkers, attachmentPreviews, loading: matorLoading, settingsToggles, patchSettings, syncSettingsFromComposer, conversations: matorConversations, conversationMeta, events: matorEvents, incomplete, incompleteContinue, error: matorError, pending: matorPending } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$chat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMatorChat"])({
        workflowId: activeWorkflow?.id ?? null,
        onSpeakHow: {
            "DashboardShell.useMatorChat": (text)=>{
                if (!callActiveRef.current) voice.speak(text);
            }
        }["DashboardShell.useMatorChat"],
        onSpeakReply: {
            "DashboardShell.useMatorChat": (text)=>{
                if (!callActiveRef.current) voice.speak(text);
            }
        }["DashboardShell.useMatorChat"],
        voiceOnly
    });
    const aiCall = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$ai$2d$call$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMatorAiCall"])({
        workflowId: activeWorkflow?.id ?? null,
        conversationId: conversationMeta?.id ?? null,
        voiceOnly,
        voice,
        sendTurn: sendCallTurn
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardShell.useEffect": ()=>{
            callActiveRef.current = aiCall.active;
        }
    }["DashboardShell.useEffect"], [
        aiCall.active
    ]);
    // A reply from a previous workflow/thread must never be delivered in the new scope.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardShell.useEffect": ()=>{
            const scope = `${activeWorkflow?.id ?? ''}:${conversationMeta?.id ?? ''}`;
            if (voiceScopeRef.current !== null && voiceScopeRef.current !== scope) {
                voice.cancelPendingTranscript();
            }
            voiceScopeRef.current = scope;
        }
    }["DashboardShell.useEffect"], [
        activeWorkflow?.id,
        conversationMeta?.id,
        voice
    ]);
    // Runner SSE events, not the YAML plan, are the authority for spoken status.
    // Changes of run identity seed the history so navigating to an old run is silent.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardShell.useEffect": ()=>{
            const tracker = spokenRunRef.current;
            if (!currentRunId) {
                tracker.runId = null;
                tracker.seen.clear();
                return;
            }
            if (tracker.runId !== currentRunId) {
                tracker.runId = currentRunId;
                tracker.seen = new Set(events.filter({
                    "DashboardShell.useEffect": (item)=>item.runId === currentRunId
                }["DashboardShell.useEffect"]).map({
                    "DashboardShell.useEffect": (item)=>item.id
                }["DashboardShell.useEffect"]));
                return;
            }
            const summaries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$run$2d$speech$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collectRunSpeechUpdates"])(events, currentRunId, tracker.seen);
            if (voiceOnly && !aiCall.active && settingsToggles.howTtsEnabled && summaries.length) {
                voice.speak(summaries.join(' '));
            }
        }
    }["DashboardShell.useEffect"], [
        currentRunId,
        events,
        voiceOnly,
        aiCall.active,
        settingsToggles.howTtsEnabled,
        voice
    ]);
    const { sendMessage: sendOperatorMessage, submitUtterance, confirmPending, pendingLabel: operatorPendingLabel, handleCraftCommand } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$operator$2d$commands$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOperatorCommands"])({
        message,
        setMessage,
        setConversation,
        chatNotice,
        // Operator craft/memory replies may speak; Mator how TTS is separate via onSpeakHow.
        onSpeak: voice.speak,
        platform,
        accountId: activeConnector?.id ?? null,
        selectedCraftId,
        selectedPage,
        navigatePane,
        navigateCraft,
        setCraftsRevision,
        setSelectedNode,
        onStageWorkflow: openActionWorkflow
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardShell.useEffect": ()=>{
            setConversationRef.current = setConversation;
        }
    }["DashboardShell.useEffect"], [
        setConversation
    ]);
    const routeUtterance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardShell.useCallback[routeUtterance]": (text, source)=>{
            const request = text.trim();
            if (!request) return;
            // The text-mode mic only dictates. AI Call owns its separate turn loop.
            if (source === 'voice') {
                setMessage({
                    "DashboardShell.useCallback[routeUtterance]": (current)=>[
                            current.trim(),
                            request
                        ].filter(Boolean).join(' ')
                }["DashboardShell.useCallback[routeUtterance]"]);
                return;
            }
            // Never TTS the user transcript (voice or typed).
            if (request.startsWith('/craft') || request === 'crafts' || request === 'memory' || request.startsWith('inspect')) {
                submitUtterance(request, source);
                return;
            }
            // The call's microphone does not come through this text-input route.
            void send(request);
        }
    }["DashboardShell.useCallback[routeUtterance]"], [
        send,
        setMessage,
        submitUtterance
    ]);
    const sendMessage = (event)=>{
        event.preventDefault();
        if (matorPending) return;
        if (message.trim().startsWith('/craft') || [
            'crafts',
            'memory'
        ].includes(message.trim()) || message.trim().startsWith('inspect')) {
            sendOperatorMessage(event);
            return;
        }
        sendMatorMessage(event);
    };
    const confirmChat = (eventId)=>{
        if (eventId) void confirmStage(eventId).then((ok)=>{
            if (ok) void aiCall.approvalResolved(eventId, 'confirm');
        });
    };
    const rejectChat = (eventId)=>{
        if (eventId) void rejectStage(eventId).then((ok)=>{
            if (ok) void aiCall.approvalResolved(eventId, 'reject');
        });
    };
    const restoreMatorPipelineUi = async ()=>{
        try {
            await restorePipeline(false);
        } catch (err) {
            const text = err instanceof Error ? err.message : '';
            if (/dirty|409|confirm/i.test(text)) {
                const ok = ("TURBOPACK compile-time value", "object") !== 'undefined' && window.confirm('Live pipeline has unsaved changes. Restore this conversation’s pipeline anyway?');
                if (ok) await restorePipeline(true);
                return;
            }
            throw err;
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardShell.useEffect": ()=>{
            submitRef.current = routeUtterance;
        }
    }["DashboardShell.useEffect"], [
        routeUtterance
    ]);
    const onConnectorSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardShell.useCallback[onConnectorSelect]": (account)=>{
            if (account.platform !== 'linkedin') return;
            // Connecting or resyncing the same account must not discard a template
            // that the user already loaded and configured offline.
            const switchingAccount = Boolean(activeConnector?.id && activeConnector.id !== account.id);
            const switchingPlatform = platform !== account.platform;
            setActiveConnector(account);
            setPlatform(account.platform);
            setHandle(account.handle);
            if (!switchingAccount && !switchingPlatform) return;
            // Switching identities or platforms intentionally resets any account-specific form.
            invalidateWorkflowSelection();
            setActiveWorkflow(null);
            setWorkspaceOpen(false);
            setSelectedGrowthTemplateId(null);
            setAction('audit');
            setForm({});
            setScopeSection('profile');
            setConnectorRequest(null);
        }
    }["DashboardShell.useCallback[onConnectorSelect]"], [
        activeConnector,
        platform,
        invalidateWorkflowSelection,
        setAction,
        setActiveWorkflow,
        setWorkspaceOpen,
        setSelectedGrowthTemplateId,
        setForm,
        setHandle,
        setPlatform
    ]);
    function choosePlatform(next) {
        invalidateWorkflowSelection();
        setActiveWorkflow(null);
        setWorkspaceOpen(false);
        setSelectedGrowthTemplateId(null);
        setPlatform(next);
        setAction('audit');
        setForm({});
        setScopeSection('profile');
        setActiveConnector(null);
        setHandle('');
    }
    function chooseAction(next) {
        void openActionWorkflow(next).catch((reason)=>{
            const message = reason instanceof Error ? reason.message : 'Unable to load action workflow';
            setRunFormError(message);
            chatNotice(message);
        });
        navigatePane('workspace');
    }
    async function startRun() {
        if (!workspaceOpen || selectedGrowthTemplateId) {
            throw Error('Choose an executable workflow before starting a run');
        }
        const payload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$build$2d$run$2d$payload$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildRunPayload"])({
            loadingWorkflow,
            activeWorkflow,
            planDirty,
            formDirty,
            activeConnector,
            platform,
            action,
            workflowPlan,
            form,
            selectedPage,
            fields: selected.fields
        });
        await startMonitoredRun(payload, action, platform);
    }
    async function launchRun() {
        setRunFormError('');
        try {
            await startRun();
        } catch (error) {
            const detail = error instanceof Error ? error.message : 'Unable to start run';
            setRunFormError(detail);
            chatNotice(detail);
        }
    }
    /** Reads chat image bytes and guards the pipeline page scope for the review studio. */ async function buildChatAnnotationSource(request) {
        if (!normalizedHandle.trim() || !selectedPage.trim()) {
            throw new Error('Open a pipeline account page before annotating chat images as YAML reviews');
        }
        if (request.file) {
            const invalid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateReviewImage"])(request.file);
            if (invalid) throw new Error(invalid);
            return new Promise((resolve, reject)=>{
                const reader = new FileReader();
                reader.onload = ()=>{
                    if (typeof reader.result === 'string') {
                        resolve({
                            imageDataUrl: reader.result
                        });
                        return;
                    }
                    reject(new Error('Could not read the chosen image'));
                };
                reader.onerror = ()=>reject(new Error('Could not read the chosen image'));
                reader.readAsDataURL(request.file);
            });
        }
        if (request.attachmentId) {
            const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matorAttachmentFileUrl"])(request.attachmentId));
            if (!response.ok) {
                throw new Error('Attachment bytes are unavailable for annotation');
            }
            const blob = await response.blob();
            const invalid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateReviewImage"])({
                size: blob.size,
                type: blob.type || ''
            });
            if (invalid) throw new Error(invalid);
            return {
                imageDataUrl: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$visual$2d$reviews$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["imageDataUrlFromBlob"])(blob, blob.type)
            };
        }
        throw new Error('Choose an image to annotate');
    }
    const { imageDraft, closeImageDraft, imageError, annotateCapture, annotateChatAsset, saveVisualReview, inspectReview, tagExistingReview, reviewImage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$visual$2d$reviews$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVisualReviews"])({
        platform,
        annotateChatImage: buildChatAnnotationSource,
        onCaptureSection: setScopeSection,
        onSelectedNode: setSelectedNode,
        onReviewSaved: {
            "DashboardShell.useVisualReviews": (id, annotationCount)=>{
                setPlanDirty(true);
                setWorkflowPlan({
                    "DashboardShell.useVisualReviews": (previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendVisualReviewStep"])(previous, id, annotationCount)
                }["DashboardShell.useVisualReviews"]);
                setChatVisible(true);
                setConversation({
                    "DashboardShell.useVisualReviews": (previous)=>[
                            ...previous,
                            {
                                id: Date.now(),
                                sender: 'assistant',
                                text: 'Tagged ' + annotationCount + ' annotation(s) to this image and workflow. Review ' + id + ' links each location to its selected action and optional comment. This is an operator-authored plan; no AI model or website action has run. Inspect the live page and explicitly approve any supported edit.'
                            }
                        ]
                }["DashboardShell.useVisualReviews"]);
            }
        }["DashboardShell.useVisualReviews"],
        onInspectReview: {
            "DashboardShell.useVisualReviews": (review)=>{
                choosePlatform(review.platform);
                setHandle(review.handle);
                setScopeSection((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reviewSection"])(review.pageUrl));
                invalidateWorkflowSelection();
                setActiveWorkflow(null);
                setAction('audit-page');
                setSelectedNode('inspect');
                setConfigRequest({
                    "DashboardShell.useVisualReviews": (value)=>value + 1
                }["DashboardShell.useVisualReviews"]);
                navigatePane('workspace');
            }
        }["DashboardShell.useVisualReviews"],
        onSelectReviewAccount: {
            "DashboardShell.useVisualReviews": (review)=>{
                choosePlatform(review.platform);
                setHandle(review.handle);
                setScopeSection((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$visual$2d$review$2d$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reviewSection"])(review.pageUrl));
            }
        }["DashboardShell.useVisualReviews"],
        refresh
    });
    // Full YAML-driven annotation entry points for chat images. The studio
    // resolves with the created review id; linking to the chat asset happens
    // through the standard markers PATCH (evidence is the saved review).
    const annotateMatorDraft = async (file, note)=>annotateChatAsset({
            file,
            note
        });
    const annotateMatorAttachment = async (attachmentId, note)=>annotateChatAsset({
            attachmentId,
            note
        });
    const showChat = chatVisible && pane !== 'profile' && pane !== 'settings' && pane !== 'resumes' && (pane !== 'growth' || libraryView !== 'catalog');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-automate": true,
        className: "flex min-h-dvh flex-col bg-[#f5f7f8] font-sans text-slate-900 lg:fixed lg:inset-0 lg:z-40 lg:h-dvh lg:overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                available: available,
                onRefresh: ()=>void refresh(),
                onOpenHistory: ()=>navigatePane('history'),
                onOpenAccount: ()=>navigatePane('profile')
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 637,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: 'mx-auto grid w-full max-w-[1920px] grid-cols-1 gap-5 px-4 pt-5 pb-28 md:px-6 lg:min-h-0 lg:flex-1 lg:overflow-hidden lg:pb-5 ' + (showChat ? 'lg:grid-cols-[220px_minmax(0,1.7fr)_minmax(16rem,1fr)] xl:grid-cols-[232px_minmax(0,1.7fr)_minmax(16rem,1fr)]' : 'lg:grid-cols-[220px_minmax(0,1fr)] xl:grid-cols-[232px_minmax(0,1fr)]'),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        pane: pane,
                        onNavigate: navigatePane
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                        lineNumber: 651,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        "data-testid": "automation-main-scroll",
                        className: "min-w-0 space-y-5 lg:min-h-0 lg:overflow-y-auto lg:overscroll-contain lg:pr-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$connector$2d$onboarding$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                activeId: activeConnector?.id || null,
                                onSelect: onConnectorSelect,
                                requestedId: connectorRequest,
                                onManageProfile: ()=>navigateSubpage('/dashboard/profile/connections'),
                                hideTrigger: true,
                                openSignal: connectorOpenSignal
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 656,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$pipeline$2d$workspace$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                pane: pane,
                                workflowPlan: workflowPlan,
                                templatePlans: templatePlans,
                                selectedGrowthTemplateId: selectedGrowthTemplateId,
                                workspaceOpen: workspaceOpen,
                                savedWorkflows: savedWorkflows,
                                beginNewWorkflow: beginNewWorkflow,
                                selectSavedWorkflow: selectSavedWorkflow,
                                closeWorkspace: closeWorkspace,
                                connectorReady: connectorReady,
                                activeConnector: activeConnector,
                                applyGrowthTemplate: applyGrowthTemplate,
                                chooseAction: chooseAction,
                                platform: platform,
                                action: action,
                                events: events,
                                active: active,
                                busy: busy,
                                planDirty: planDirty,
                                formDirty: formDirty,
                                planSaving: planSaving,
                                activeWorkflow: activeWorkflow,
                                configRequest: configRequest,
                                setWorkflowPlan: setWorkflowPlan,
                                setPlanDirty: setPlanDirty,
                                applyTemplate: applyTemplate,
                                saveWorkflowPlan: saveWorkflowPlan,
                                cancelRun: cancelRun,
                                runFormError: runFormError,
                                annotateCapture: annotateCapture,
                                form: form,
                                setForm: setForm,
                                selected: selected,
                                scopeSection: scopeSection,
                                setScopeSection: setScopeSection,
                                pageOptions: pageOptions,
                                selectedPage: selectedPage,
                                profilePage: profilePage,
                                setSelectedNode: setSelectedNode,
                                platformLabel: platformLabel,
                                available: available,
                                loadingWorkflow: loadingWorkflow,
                                launchRun: launchRun,
                                resumeRun: resumeRun,
                                pauseRun: pauseRun,
                                setConnectorOpenSignal: setConnectorOpenSignal,
                                PlatformIcon: PlatformIcon
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 666,
                                columnNumber: 11
                            }, this),
                            pane === 'history' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$history$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                runs: runs,
                                onSelect: (run)=>{
                                    selectRun(run);
                                    navigatePane('workspace');
                                }
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 716,
                                columnNumber: 13
                            }, this),
                            pane === 'growth' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$crafts$2f$crafts$2d$library$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                selectedId: selectedCraftId,
                                onSelected: navigateCraft,
                                view: libraryView,
                                onView: navigateCraftView,
                                onBack: ()=>navigatePane('growth'),
                                onChat: (text)=>{
                                    if (text.startsWith('/craft')) {
                                        void handleCraftCommand(text);
                                    } else chatNotice(text);
                                },
                                revision: craftsRevision
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 725,
                                columnNumber: 13
                            }, this),
                            (pane === 'profile' || pane === 'settings') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$home$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                pathname: pathname,
                                pane: pane,
                                available: available,
                                selectedAccount: activeConnector ? {
                                    platform: activeConnector.platform,
                                    label: activeConnector.label,
                                    handle: activeConnector.handle,
                                    profileUrl: activeConnector.profileUrl,
                                    status: activeConnector.status
                                } : null,
                                onNavigate: navigateSubpage,
                                onSelectAccount: selectSocialAccount,
                                linkedAccountId: activeConnector?.id,
                                onConnect: ()=>{
                                    setConnectorRequest(null);
                                    setConnectorOpenSignal((value)=>value + 1);
                                }
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 740,
                                columnNumber: 13
                            }, this),
                            pane === 'resumes' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$career$2f$career$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                mode: pathname === '/dashboard/resumes/profile' ? 'profile' : 'resumes',
                                onNavigate: navigateSubpage
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 765,
                                columnNumber: 13
                            }, this),
                            (pane === 'memory' || pane === 'observer') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$career$2f$intelligence$2f$activity$2d$intelligence$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                initialView: pane,
                                onNavigate: (path)=>{
                                    navigate(path);
                                    setPane(path.endsWith('/dashboard/observer') ? 'observer' : 'memory');
                                }
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 775,
                                columnNumber: 13
                            }, this),
                            pane === 'research' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$research$2f$linkedin$2d$research$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 785,
                                columnNumber: 35
                            }, this),
                            pane === 'editorial' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$editorial$2f$linkedin$2d$editorial$2d$studio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                                lineNumber: 786,
                                columnNumber: 36
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                        lineNumber: 652,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$operator$2d$chat$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        pane: pane,
                        selectedCraftSlug: selectedCraftSlug,
                        mobileChatOpen: mobileChatOpen,
                        showChat: showChat,
                        onClose: ()=>{
                            aiCall.end();
                            voice.cancelPendingTranscript();
                            setChatVisible(false);
                            setMobileChatOpen(false);
                        },
                        conversation: conversation,
                        events: events,
                        matorEvents: matorEvents,
                        conversations: matorConversations,
                        conversationMeta: conversationMeta,
                        growthExecution: pane === 'workspace' && selectedGrowthTemplateId ? workspaceExecution : null,
                        growthExecutionTitle: workspaceGrowth.program?.title,
                        growthExecutionError: workspaceJournalError || workspaceGrowth.error,
                        growthExecutionBusy: workspaceGrowth.working,
                        onGrowthDecision: (runId, checkpointId, approved)=>submitWorkspaceCheckpoint(runId, checkpointId, 'decision', {
                                approved
                            }),
                        onGrowthInput: (runId, checkpointId, value)=>submitWorkspaceCheckpoint(runId, checkpointId, 'input', {
                                value
                            }),
                        loading: matorLoading,
                        modelId: settingsToggles.modelId ?? null,
                        onModelChange: (modelId)=>patchSettings({
                                modelId
                            }),
                        onSettingsSaved: syncSettingsFromComposer,
                        onSwitchConversation: (id)=>{
                            aiCall.end();
                            voice.cancelPendingTranscript();
                            void switchConversation(id);
                        },
                        onNewConversation: ()=>{
                            aiCall.end();
                            voice.cancelPendingTranscript();
                            void newConversation();
                        },
                        onRestorePipeline: ()=>void restoreMatorPipelineUi(),
                        onSendText: (text, attachmentIds)=>send(text, attachmentIds),
                        onUploadClarifyFile: uploadForClarify,
                        attachmentPreviews: attachmentPreviews,
                        onSaveMarkers: (attachmentId, markers, reviewId)=>{
                            return saveMarkers(attachmentId, markers, reviewId);
                        },
                        reviews: reviews,
                        platform: platform,
                        normalizedHandle: normalizedHandle,
                        selectedPage: selectedPage,
                        annotateChatImageAvailable: Boolean(selectedPage && normalizedHandle),
                        onAnnotateDraft: annotateMatorDraft,
                        onAnnotateAttachment: annotateMatorAttachment,
                        currentRunId: currentRunId,
                        onAnnotateCapture: annotateCapture,
                        onEditReview: tagExistingReview,
                        onInspectReview: inspectReview,
                        reviewImage: reviewImage,
                        imageError: imageError,
                        message: message,
                        onMessageChange: setMessage,
                        onSendMessage: sendMessage,
                        onPendingAssetsChange: (count)=>{
                            pendingAssetsRef.current = count > 0;
                        },
                        checkpoint: checkpoint,
                        voice: voice,
                        call: aiCall,
                        callReady: Boolean(activeWorkflow?.id && conversationMeta?.id),
                        operatorPendingLabel: operatorPendingLabel,
                        onConfirmOperator: confirmPending,
                        onConfirm: confirmChat,
                        onReject: rejectChat,
                        busy: matorPending,
                        incomplete: Boolean(incomplete),
                        onIncompleteContinue: ()=>void incompleteContinue(),
                        chatError: matorError
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                        lineNumber: 788,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 643,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$bottom$2d$nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                pane: pane,
                onNavigate: navigatePane,
                showRun: pane === 'workspace' && !selectedGrowthTemplateId,
                active: active,
                platform: platform,
                action: action,
                busy: busy,
                available: available,
                connectorReady: connectorReady,
                loadingWorkflow: loadingWorkflow,
                workflowPlan: workflowPlan,
                activeWorkflow: activeWorkflow,
                planDirty: planDirty,
                formDirty: formDirty,
                resumeRun: resumeRun,
                pauseRun: pauseRun,
                launchRun: launchRun,
                cancelRun: cancelRun,
                chatOpen: mobileChatOpen
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 868,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$checkpoint$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                checkpoint: checkpoint,
                checkpointError: checkpointError,
                inputReply: inputReply,
                onInputChange: setInputReply,
                onDecision: act,
                onCancel: cancelRun
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 890,
                columnNumber: 7
            }, this),
            pane !== 'profile' && pane !== 'resumes' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": "Open Mator",
                onClick: ()=>{
                    setChatVisible(true);
                    setMobileChatOpen(true);
                },
                className: mobileChatOpen ? 'hidden' : 'fixed right-4 bottom-32 z-30 inline-flex min-h-12 items-center gap-2 rounded-full bg-slate-950 px-5 text-sm font-bold text-white shadow-2xl ring-2 ring-white/80 hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-teal-600 lg:bottom-5 ' + (showChat ? 'lg:hidden' : ''),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__["MessageSquare"], {
                        className: "size-5",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                        lineNumber: 913,
                        columnNumber: 11
                    }, this),
                    "Mator"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 899,
                columnNumber: 9
            }, this),
            imageDraft && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$reviews$2f$visual$2d$review$2d$panel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                source: imageDraft,
                platform: platform,
                handle: normalizedHandle,
                pageUrl: selectedPage,
                nodeId: "annotation",
                onClose: closeImageDraft,
                onSave: saveVisualReview
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
                lineNumber: 918,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/dashboard-shell.tsx",
        lineNumber: 633,
        columnNumber: 5
    }, this);
}
_s(DashboardShell, "PBbBRTWBtmbBoD0zkLVD+L6XNQo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$dashboard$2d$navigation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDashboardNavigation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$run$2d$monitor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRunMonitor"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$workflow$2d$workspace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkflowWorkspace"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$hooks$2f$use$2d$growth$2d$profile$2d$workflow$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGrowthProfileWorkflow"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$hooks$2f$use$2d$growth$2d$execution$2d$projection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGrowthExecutionProjection"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$voice$2d$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceSession"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$voice$2d$preference$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVoiceOnlyPreference"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$chat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMatorChat"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$mator$2d$ai$2d$call$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMatorAiCall"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$use$2d$operator$2d$commands$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOperatorCommands"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$use$2d$visual$2d$reviews$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVisualReviews"]
    ];
});
_c = DashboardShell;
var _c;
__turbopack_context__.k.register(_c, "DashboardShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_components_dashboard_0q4r0hf._.js.map