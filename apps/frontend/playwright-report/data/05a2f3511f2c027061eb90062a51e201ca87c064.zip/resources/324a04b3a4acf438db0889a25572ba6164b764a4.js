(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$7$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tailwind-merge@3.7.0/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$7$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/lib/growth-profile-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "request",
    ()=>request
]);
async function request(url, method = 'GET', body, signal) {
    const response = await fetch(url, {
        method,
        cache: 'no-store',
        signal,
        ...body === undefined ? {} : {
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(body)
        }
    });
    const data = await response.json();
    if (!response.ok) throw Error(data.error || 'Growth workflow request failed');
    return data;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/lib/growth-run-journal.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchGrowthRunJournal",
    ()=>fetchGrowthRunJournal,
    "fetchGrowthRunJournalPage",
    ()=>fetchGrowthRunJournalPage
]);
async function fetchGrowthRunJournalPage(childRunId, signal) {
    const response = await fetch(`/api/runs/${encodeURIComponent(childRunId)}/logs`, {
        cache: 'no-store',
        signal
    });
    if (!response.ok) {
        throw Error(`Runner event journal unavailable (HTTP ${response.status})`);
    }
    const entries = await response.json();
    if (!Array.isArray(entries)) throw Error('Invalid Runner journal');
    return {
        entries: entries,
        truncated: response.headers?.get('x-run-journal-truncated') === 'true'
    };
}
async function fetchGrowthRunJournal(childRunId, signal) {
    return (await fetchGrowthRunJournalPage(childRunId, signal)).entries;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/lib/growth-execution-projection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** A read-only projection of a pinned Growth release and observed child Runner history. */ __turbopack_context__.s([
    "orderedGrowthEvents",
    ()=>orderedGrowthEvents,
    "projectGrowthExecution",
    ()=>projectGrowthExecution
]);
const terminal = new Set([
    'completed',
    'failed',
    'blocked',
    'cancelled'
]);
const lifecycle = new Set([
    'started',
    'completed',
    'failed'
]);
const screenshotName = /^[a-zA-Z0-9_-]+\.png$/;
const validStepId = /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/;
function asRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function orderedGrowthEvents(runId, events) {
    const byId = new Map();
    const conflicts = new Set();
    for (const event of events){
        if (event.runId !== runId || !Number.isSafeInteger(event.id) || event.id < 1 || typeof event.time !== 'string' || !Number.isFinite(Date.parse(event.time)) || typeof event.message !== 'string') continue;
        if (conflicts.has(event.id)) continue;
        const prior = byId.get(event.id);
        if (prior && JSON.stringify(prior) !== JSON.stringify(event)) {
            byId.delete(event.id);
            conflicts.add(event.id);
        } else if (!prior) {
            byId.set(event.id, event);
        }
    }
    return {
        entries: [
            ...byId.values()
        ].sort((a, b)=>a.id - b.id),
        conflicts: conflicts.size > 0
    };
}
function projectGrowthExecution(run, journals) {
    if (!run.programId || !run.sourceDigest || !Number.isSafeInteger(run.programVersion)) throw Error('Growth execution has no pinned source identity');
    const stageIds = new Set();
    for (const stage of run.stages){
        if (!stage.id || stageIds.has(stage.id)) throw Error('Missing or duplicate pipeline ID');
        stageIds.add(stage.id);
        const ids = new Set();
        if (!stage.plan?.steps?.length) throw Error('Growth pipeline has no pinned tasks');
        for (const task of stage.plan.steps){
            if (!validStepId.test(task.id) || ids.has(task.id)) throw Error('Invalid or duplicate pinned task ID');
            ids.add(task.id);
        }
    }
    const byStage = new Map(run.pipelineRuns.map((stage)=>[
            stage.id,
            stage
        ]));
    return {
        workflowId: run.programId,
        workflowRevision: run.programVersion,
        sourceDigest: run.sourceDigest,
        pipelines: run.stages.map((stage, index)=>{
            const summary = byStage.get(stage.id);
            const matches = Boolean(summary && summary.childRunId === stage.childRunId);
            const runId = matches ? stage.childRunId : null;
            const snapshot = runId ? journals[runId] : undefined;
            const journalMatches = Boolean(snapshot && snapshot.runId === runId);
            const ordered = journalMatches ? orderedGrowthEvents(runId, snapshot.events) : {
                entries: [],
                conflicts: false
            };
            const incomplete = Boolean(stage.childRunId) && (!matches || !journalMatches || !snapshot?.complete || ordered.conflicts);
            const recognized = new Set(stage.plan.steps.map((task)=>task.id));
            const perTask = new Map();
            let unattributedCount = 0;
            for (const event of ordered.entries){
                const id = asRecord(event.details)?.stepId;
                if (typeof id !== 'string' || !recognized.has(id)) {
                    unattributedCount++;
                    continue;
                }
                const list = perTask.get(id) ?? [];
                list.push(event);
                perTask.set(id, list);
            }
            const childState = !stage.childRunId ? 'waiting' : matches ? summary.state : 'unavailable';
            const tasks = stage.plan.steps.map((task)=>{
                const events = perTask.get(task.id) ?? [];
                let state = 'waiting';
                let failure;
                const screenshots = new Set();
                for (const event of events){
                    const data = asRecord(event.details);
                    const phase = data?.stage;
                    if (event.kind === 'step' && typeof phase === 'string' && lifecycle.has(phase)) {
                        state = phase === 'started' ? 'running' : phase === 'completed' ? 'completed' : 'failed';
                        if (phase === 'failed') failure = typeof data?.reason === 'string' ? data.reason.slice(0, 400) : 'Task failed';
                    }
                    if (event.kind === 'screenshot' && typeof data?.fileName === 'string' && screenshotName.test(data.fileName)) screenshots.add(data.fileName);
                }
                const current = matches && summary?.currentStepId === task.id;
                if (current && !terminal.has(childState)) {
                    if ([
                        'approval-needed',
                        'input-needed',
                        'paused'
                    ].includes(childState)) state = childState;
                    else if (childState === 'running' && state === 'waiting') state = 'running';
                }
                if (current && [
                    'failed',
                    'blocked',
                    'cancelled'
                ].includes(childState)) {
                    state = childState;
                    if (summary?.error) failure = summary.error.slice(0, 400);
                }
                const checkpoint = run.currentChild?.id === runId && current ? run.currentChild.checkpoint?.id : undefined;
                return {
                    id: task.id,
                    title: task.title,
                    kind: task.kind,
                    state,
                    events,
                    screenshots: [
                        ...screenshots
                    ],
                    ...failure ? {
                        failure
                    } : {},
                    ...checkpoint && [
                        'approval-needed',
                        'input-needed'
                    ].includes(childState) ? {
                        checkpointId: checkpoint
                    } : {}
                };
            });
            let state = [
                'running',
                'approval-needed',
                'input-needed',
                'paused',
                'completed',
                'failed',
                'blocked',
                'cancelled',
                'waiting'
            ].includes(childState) ? childState : 'unavailable';
            if (state === 'completed') {
                const proof = Boolean(stage.pageEvidence?.digest) || run.status !== 'active' && index === run.activeIndex;
                if (!proof || run.releasePending) state = 'finalizing';
            }
            return {
                id: stage.id,
                title: stage.title,
                dependsOn: stage.dependsOn,
                runId,
                state,
                tasks,
                completed: tasks.filter((t)=>t.state === 'completed').length,
                total: tasks.length,
                historyIncomplete: incomplete,
                unattributedCount
            };
        })
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/hooks/use-growth-execution-projection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGrowthExecutionProjection",
    ()=>useGrowthExecutionProjection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$run$2d$journal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-run-journal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$execution$2d$projection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-execution-projection.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useGrowthExecutionProjection(run) {
    _s();
    const childIds = run?.stages?.flatMap((stage)=>stage.childRunId ? [
            stage.childRunId
        ] : []) ?? [];
    const key = (run?.id ?? '') + ':' + childIds.join(',');
    const [snapshot, setSnapshot] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        key: '',
        journals: {},
        error: ''
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGrowthExecutionProjection.useEffect": ()=>{
            if (childIds.length === 0) return;
            const controller = new AbortController();
            let busy = false;
            const refresh = {
                "useGrowthExecutionProjection.useEffect.refresh": async ()=>{
                    if (busy || controller.signal.aborted) return;
                    busy = true;
                    const journals = {};
                    const errors = [];
                    await Promise.all(childIds.map({
                        "useGrowthExecutionProjection.useEffect.refresh": async (runId)=>{
                            try {
                                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$run$2d$journal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchGrowthRunJournalPage"])(runId, controller.signal);
                                journals[runId] = {
                                    runId,
                                    events: result.entries,
                                    complete: !result.truncated
                                };
                            } catch  {
                                journals[runId] = {
                                    runId,
                                    events: [],
                                    complete: false
                                };
                                errors.push('Journal unavailable for a pipeline');
                            }
                        }
                    }["useGrowthExecutionProjection.useEffect.refresh"]));
                    if (!controller.signal.aborted) setSnapshot({
                        key,
                        journals,
                        error: errors.join('; ')
                    });
                    busy = false;
                }
            }["useGrowthExecutionProjection.useEffect.refresh"];
            void refresh();
            const timer = setInterval({
                "useGrowthExecutionProjection.useEffect.timer": ()=>void refresh()
            }["useGrowthExecutionProjection.useEffect.timer"], 2500);
            return ({
                "useGrowthExecutionProjection.useEffect": ()=>{
                    clearInterval(timer);
                    controller.abort();
                }
            })["useGrowthExecutionProjection.useEffect"];
        }
    }["useGrowthExecutionProjection.useEffect"], [
        key
    ]);
    const projection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useGrowthExecutionProjection.useMemo[projection]": ()=>{
            if (!run?.stages?.length || !run.programId || !Number.isSafeInteger(run.programVersion) || !run.sourceDigest) return null;
            try {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$execution$2d$projection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectGrowthExecution"])(run, snapshot.key === key ? snapshot.journals : {});
            } catch  {
                return null;
            }
        }
    }["useGrowthExecutionProjection.useMemo[projection]"], [
        run,
        key,
        snapshot
    ]);
    return {
        projection,
        error: snapshot.key === key ? snapshot.error : ''
    };
}
_s(useGrowthExecutionProjection, "CBVVB2iDuP3nlSWuKP1v3nPJtPc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/hooks/use-growth-run-journal.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGrowthRunJournal",
    ()=>useGrowthRunJournal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$run$2d$journal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/lib/growth-run-journal.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useGrowthRunJournal(childRunId) {
    _s();
    const [result, setResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        runId: '',
        entries: [],
        error: ''
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGrowthRunJournal.useEffect": ()=>{
            if (!childRunId) return;
            const controller = new AbortController();
            let active = true;
            let inFlight = false;
            const refresh = {
                "useGrowthRunJournal.useEffect.refresh": async ()=>{
                    if (!active || inFlight) return;
                    inFlight = true;
                    try {
                        const page = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$lib$2f$growth$2d$run$2d$journal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchGrowthRunJournalPage"])(childRunId, controller.signal);
                        if (active) setResult({
                            runId: childRunId,
                            entries: page.entries,
                            error: page.truncated ? 'Earlier Runner events were omitted. Task history is incomplete.' : ''
                        });
                    } catch (error) {
                        if (active && !controller.signal.aborted) {
                            setResult({
                                runId: childRunId,
                                entries: [],
                                error: error instanceof Error ? error.message : 'Journal unavailable'
                            });
                        }
                    } finally{
                        inFlight = false;
                    }
                }
            }["useGrowthRunJournal.useEffect.refresh"];
            void refresh();
            const interval = setInterval({
                "useGrowthRunJournal.useEffect.interval": ()=>void refresh()
            }["useGrowthRunJournal.useEffect.interval"], 2500);
            return ({
                "useGrowthRunJournal.useEffect": ()=>{
                    active = false;
                    clearInterval(interval);
                    controller.abort();
                }
            })["useGrowthRunJournal.useEffect"];
        }
    }["useGrowthRunJournal.useEffect"], [
        childRunId
    ]);
    return childRunId && result.runId === childRunId ? {
        journal: result.entries,
        logError: result.error
    } : {
        journal: [],
        logError: ''
    };
}
_s(useGrowthRunJournal, "pb47S5MjPCZDA6hEsIWA1A+3nco=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_11yb~4v._.js.map