(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// The dashboard uses one API path convention for requests and event streams.
__turbopack_context__.s([
    "apiPost",
    ()=>apiPost,
    "getApi",
    ()=>getApi
]);
const getApi = (path)=>`/api/${path}`;
async function apiPost(path, data = {}) {
    const response = await fetch(getApi(path), {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || 'Unable to submit request');
    return body;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/presentation-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "short",
    ()=>short,
    "stateLabel",
    ()=>stateLabel,
    "timeLabel",
    ()=>timeLabel
]);
function stateLabel(state) {
    return state.replaceAll('-', ' ');
}
function timeLabel(time) {
    return new Date(time).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}
function short(id) {
    return id.slice(0, 8);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/visual-review-model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "REVIEW_IMAGE_ERROR",
    ()=>REVIEW_IMAGE_ERROR,
    "appendVisualReviewStep",
    ()=>appendVisualReviewStep,
    "captureSection",
    ()=>captureSection,
    "reviewSection",
    ()=>reviewSection,
    "validateReviewImage",
    ()=>validateReviewImage
]);
const capturePattern = /^audit-(experience|skills|projects|featured)\.png$/;
const reviewPattern = /\/details\/(experience|skills|projects|featured)\/?$/;
const REVIEW_IMAGE_ERROR = 'Choose a PNG, JPEG or WebP file under 2 MB.';
function validateReviewImage(file) {
    if (file.size > 2 * 1024 * 1024) return REVIEW_IMAGE_ERROR;
    if (![
        'image/png',
        'image/jpeg',
        'image/webp'
    ].includes(file.type)) return REVIEW_IMAGE_ERROR;
    return null;
}
function captureSection(fileName) {
    return capturePattern.exec(fileName)?.[1] ?? null;
}
function reviewSection(pageUrl) {
    return reviewPattern.exec(pageUrl)?.[1] ?? 'profile';
}
function appendVisualReviewStep(plan, reviewId, annotationCount) {
    const id = `review-${reviewId.slice(0, 8)}`;
    if (plan.steps.some((step)=>step.id === id)) return plan;
    const steps = [
        ...plan.steps
    ];
    const index = steps.findIndex((step)=>step.id === 'action');
    steps.splice(index, 0, {
        id,
        kind: 'note',
        title: 'Tagged image instruction',
        message: 'Image review ' + reviewId + ' · ' + annotationCount + ' location actions; approval still required'
    });
    return {
        ...plan,
        steps,
        links: steps.slice(1).map((step, i)=>({
                source: steps[i]?.id,
                target: step.id
            }))
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/build-run-payload.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildRunPayload",
    ()=>buildRunPayload
]);
function buildRunPayload({ loadingWorkflow, activeWorkflow, planDirty, formDirty, activeConnector, platform, action, workflowPlan, form, selectedPage, fields }) {
    if (loadingWorkflow) {
        throw Error('Selected workflow has not finished loading');
    }
    if (activeWorkflow && (planDirty || formDirty)) {
        throw Error('Save workflow changes before starting this revision');
    }
    if (activeConnector?.status !== 'connected' || activeConnector.platform !== platform) {
        throw Error('Select and verify the social account before starting a workflow');
    }
    const payload = {
        platform,
        action,
        accountId: activeConnector.id,
        profileUrl: activeConnector.profileUrl
    };
    if (activeWorkflow) {
        payload.workflowId = activeWorkflow.id;
        payload.workflowRevision = activeWorkflow.revision;
    } else {
        payload.workflow = {
            ...workflowPlan,
            parameters: {
                ...form
            }
        };
    }
    if (action === 'audit-page') payload.pageUrl = selectedPage;
    for (const field of fields){
        const value = form[field.key]?.trim();
        if (field.required && !value) throw Error(`${field.label} is required`);
        if (value) {
            payload[field.key] = field.key === 'websiteIndex' ? Number(value) : value;
        }
    }
    return payload;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CheckpointDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/automate-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function CheckpointDialog({ checkpoint, checkpointError, inputReply, onInputChange, onDecision, onCancel }) {
    const checkpointNeeded = checkpoint?.kind === 'approval';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: Boolean(checkpoint),
        onDismiss: ()=>{},
        dismissible: false,
        title: checkpointNeeded ? 'Approval required' : 'Operator input required',
        description: checkpoint?.message,
        testId: "checkpoint-dialog",
        children: checkpoint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm leading-6 text-slate-700",
                    children: "Review the operation before continuing."
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                    lineNumber: 37,
                    columnNumber: 11
                }, this),
                checkpointError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800",
                    children: checkpointError
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                    lineNumber: 41,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: checkpointNeeded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "primary",
                                onClick: ()=>void onDecision(true),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                        className: "size-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                        lineNumber: 52,
                                        columnNumber: 19
                                    }, this),
                                    "Approve checkpoint"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                lineNumber: 51,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "danger",
                                onClick: ()=>void onDecision(false),
                                children: "Reject"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                lineNumber: 55,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                        lineNumber: 50,
                        columnNumber: 15
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                "aria-label": "Checkpoint response",
                                value: inputReply,
                                onChange: (event)=>onInputChange(event.target.value),
                                className: "min-h-10 min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3 text-sm",
                                maxLength: 300
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                lineNumber: 61,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "primary",
                                disabled: !inputReply.trim(),
                                onClick: ()=>void onDecision(true, inputReply),
                                children: "Respond"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                lineNumber: 68,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                type: "button",
                                onClick: ()=>void onCancel(),
                                children: "Cancel run"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                                lineNumber: 75,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                        lineNumber: 60,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
            lineNumber: 36,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/checkpoint-dialog.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c = CheckpointDialog;
var _c;
__turbopack_context__.k.register(_c, "CheckpointDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkflowRunButton",
    ()=>WorkflowRunButton,
    "default",
    ()=>FloatingWorkflowControls
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/check.mjs [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/pause.mjs [app-client] (ecmascript) <export default as Pause>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/play.mjs [app-client] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/square.mjs [app-client] (ecmascript) <export default as Square>");
'use client';
;
;
function FloatingWorkflowControls({ selectedGrowthTemplateId, workspaceOpen, active, platform, action, busy, available, connectorReady, loadingWorkflow, workflowPlan, activeWorkflow, planDirty, formDirty, resumeRun, pauseRun, launchRun, cancelRun, setConnectorOpenSignal, platformLabel, PlatformIcon }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "pointer-events-none fixed bottom-5 left-1/2 z-30 hidden -translate-x-1/2 items-center gap-2 rounded-full border border-white/30 bg-[#111e2b] p-1.5 shadow-2xl lg:flex",
        "data-testid": "floating-workflow-controls",
        children: [
            (workspaceOpen || Boolean(active)) && !selectedGrowthTemplateId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WorkflowRunButton, {
                active: active,
                platform: platform,
                action: action,
                busy: busy,
                available: available,
                connectorReady: connectorReady,
                loadingWorkflow: loadingWorkflow,
                workflowPlan: workflowPlan,
                activeWorkflow: activeWorkflow,
                planDirty: planDirty,
                formDirty: formDirty,
                resumeRun: resumeRun,
                pauseRun: pauseRun,
                launchRun: launchRun,
                cancelRun: cancelRun
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                lineNumber: 61,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setConnectorOpenSignal((value)=>value + 1),
                "aria-label": `${(connectorReady ? 'Manage ' : 'Connect ') + platformLabel} account`,
                "aria-haspopup": "dialog",
                title: connectorReady ? `${platformLabel} connected · Manage or sync` : `Connect ${platformLabel} account`,
                "data-testid": "floating-connector-button",
                className: "pointer-events-auto relative inline-flex size-12 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-400",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "grid size-5 shrink-0 place-items-center [&>svg]:h-5 [&>svg]:w-5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlatformIcon, {
                            className: "size-5"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: 'absolute -top-1 -right-1 grid size-4 place-items-center rounded-full text-slate-950 ring-2 ring-[#111e2b] ' + (connectorReady ? 'bg-emerald-400' : 'bg-amber-400'),
                        children: connectorReady ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                            className: "size-2.5",
                            strokeWidth: 3
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                            lineNumber: 103,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                            className: "size-2.5",
                            strokeWidth: 3
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                            lineNumber: 105,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_c = FloatingWorkflowControls;
function WorkflowRunButton({ appearance = 'dock', active, platform, action, busy, available, connectorReady, loadingWorkflow, workflowPlan, activeWorkflow, planDirty, formDirty, resumeRun, pauseRun, launchRun, cancelRun }) {
    const state = active?.state;
    const canStop = state === 'running' || state === 'paused' || state === 'approval-needed' || state === 'input-needed';
    const mode = state === 'paused' ? 'resume' : state === 'running' ? 'pause' : canStop ? 'stop' : 'run';
    const label = mode === 'resume' ? 'Resume' : mode === 'pause' ? 'Pause' : mode === 'stop' ? 'Stop' : 'Run workflow';
    const ariaLabel = mode === 'resume' ? 'Resume workflow' : mode === 'pause' ? 'Pause workflow' : mode === 'stop' ? 'Stop workflow' : 'Start workflow';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: appearance === 'nav' ? 'relative mx-1 inline-flex shrink-0' : 'contents',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": ariaLabel,
                disabled: mode === 'run' && (busy || available !== 'ready' || !connectorReady || loadingWorkflow || workflowPlan.platform !== platform || workflowPlan.action !== action || Boolean(activeWorkflow) && (planDirty || formDirty)),
                onClick: ()=>{
                    if (mode === 'resume') void resumeRun();
                    else if (mode === 'pause') void pauseRun();
                    else if (mode === 'stop') void cancelRun();
                    else void launchRun();
                },
                className: appearance === 'nav' ? 'pointer-events-auto relative z-10 inline-flex size-14 shrink-0 items-center justify-center rounded-full text-white shadow-lg transition disabled:opacity-50 ' + (mode === 'stop' ? 'bg-rose-500 hover:bg-rose-400' : 'bg-[#111e2b] hover:bg-slate-800') : 'pointer-events-auto inline-flex min-h-12 items-center justify-center gap-3 rounded-full px-6 text-sm font-bold transition disabled:opacity-50 ' + (mode === 'stop' ? 'bg-rose-500 text-white hover:bg-rose-400' : 'bg-white text-slate-950 hover:bg-teal-50'),
                children: [
                    mode === 'pause' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__["Pause"], {
                        className: appearance === 'nav' ? 'size-6' : 'size-5'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 217,
                        columnNumber: 11
                    }, this) : mode === 'stop' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square$3e$__["Square"], {
                        className: "size-4 fill-current"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 219,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                        className: appearance === 'nav' ? 'size-6' : 'size-5'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 221,
                        columnNumber: 11
                    }, this),
                    appearance === 'dock' ? label : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sr-only",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                        lineNumber: 226,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                lineNumber: 185,
                columnNumber: 7
            }, this),
            (mode === 'pause' || mode === 'resume') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": "Stop workflow",
                title: "Stop workflow",
                onClick: ()=>{
                    void cancelRun();
                },
                className: appearance === 'nav' ? 'pointer-events-auto absolute -top-1 -right-1 z-20 inline-flex size-7 items-center justify-center rounded-full bg-rose-500 text-white ring-2 ring-white' : 'pointer-events-auto inline-flex size-12 items-center justify-center rounded-full bg-rose-500 text-white transition hover:bg-rose-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-300',
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Square$3e$__["Square"], {
                    className: "size-4 fill-current"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                    lineNumber: 243,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
                lineNumber: 230,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx",
        lineNumber: 180,
        columnNumber: 5
    }, this);
}
_c1 = WorkflowRunButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "FloatingWorkflowControls");
__turbopack_context__.k.register(_c1, "WorkflowRunButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardBottomNav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/activity.mjs [app-client] (ecmascript) <export default as Activity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/compass.mjs [app-client] (ecmascript) <export default as Compass>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/crosshair.mjs [app-client] (ecmascript) <export default as Crosshair>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/file-text.mjs [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw-clock.mjs [app-client] (ecmascript) <export default as History>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/notebook-pen.mjs [app-client] (ecmascript) <export default as NotebookPen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/pen-line.mjs [app-client] (ecmascript) <export default as PenLine>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/user-round.mjs [app-client] (ecmascript) <export default as UserRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$floating$2d$workflow$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const items = [
    {
        id: 'workspace',
        label: 'Workspace',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"]
    },
    {
        id: 'history',
        label: 'Run history',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"]
    },
    {
        id: 'profile',
        label: 'Account',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__["UserRound"]
    },
    {
        id: 'resumes',
        label: 'Résumés',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
    },
    {
        id: 'memory',
        label: 'Intelligence',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"]
    },
    {
        id: 'research',
        label: 'Creator research',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__["Crosshair"]
    },
    {
        id: 'editorial',
        label: 'Editorial drafts',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__["PenLine"]
    },
    {
        id: 'growth',
        label: 'Growth',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__["Compass"]
    }
];
function current(pane, id) {
    if (id === 'profile') return pane === 'profile' || pane === 'settings';
    return pane === id;
}
function DashboardBottomNav({ pane, onNavigate, showRun, active, platform, action, busy, available, connectorReady, loadingWorkflow, workflowPlan, activeWorkflow, planDirty, formDirty, resumeRun, pauseRun, launchRun, cancelRun, chatOpen }) {
    _s();
    const reduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const buttonRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const [indicator, setIndicator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: 0,
        left: 0
    });
    const activeIndex = items.findIndex((item)=>current(pane, item.id));
    const left = items.slice(0, items.length / 2);
    const right = items.slice(items.length / 2);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardBottomNav.useEffect": ()=>{
            const measure = {
                "DashboardBottomNav.useEffect.measure": ()=>{
                    const container = containerRef.current;
                    const button = buttonRefs.current[activeIndex];
                    if (!container || !button) return;
                    const buttonBox = button.getBoundingClientRect();
                    const containerBox = container.getBoundingClientRect();
                    setIndicator({
                        width: buttonBox.width,
                        left: buttonBox.left - containerBox.left
                    });
                }
            }["DashboardBottomNav.useEffect.measure"];
            measure();
            window.addEventListener('resize', measure);
            return ({
                "DashboardBottomNav.useEffect": ()=>window.removeEventListener('resize', measure)
            })["DashboardBottomNav.useEffect"];
        }
    }["DashboardBottomNav.useEffect"], [
        activeIndex
    ]);
    function itemButton(item, index) {
        const selected = current(pane, item.id);
        const Icon = item.icon;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            ref: (element)=>{
                buttonRefs.current[index] = element;
            },
            type: "button",
            "aria-label": item.label,
            "aria-current": selected ? 'page' : undefined,
            onClick: ()=>onNavigate(item.id),
            className: 'relative z-10 inline-flex size-11 shrink-0 flex-col items-center justify-center rounded-full text-slate-500 ' + (selected ? 'text-teal-800' : ''),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                className: "size-5"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
                lineNumber: 128,
                columnNumber: 9
            }, this)
        }, item.id, false, {
            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
            lineNumber: 114,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: 'fixed bottom-3 left-1/2 z-40 w-[calc(100%-1rem)] max-w-lg -translate-x-1/2 lg:hidden' + (chatOpen ? ' hidden' : ''),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: containerRef,
            "data-testid": "studio-bottom-nav",
            "aria-label": "Studio",
            className: "relative flex items-center rounded-full border border-slate-200 bg-white px-1 py-1.5 shadow-xl shadow-slate-900/15",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    "aria-hidden": "true",
                    animate: indicator,
                    transition: reduceMotion ? {
                        duration: 0
                    } : {
                        type: 'spring',
                        stiffness: 400,
                        damping: 32
                    },
                    className: "absolute top-1.5 bottom-1.5 rounded-full bg-teal-500/15"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
                    lineNumber: 146,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-w-0 flex-1 items-center justify-evenly overflow-x-auto",
                    children: left.map((item, index)=>itemButton(item, index))
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this),
                showRun && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$floating$2d$workflow$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorkflowRunButton"], {
                    appearance: "nav",
                    active: active,
                    platform: platform,
                    action: action,
                    busy: busy,
                    available: available,
                    connectorReady: connectorReady,
                    loadingWorkflow: loadingWorkflow,
                    workflowPlan: workflowPlan,
                    activeWorkflow: activeWorkflow,
                    planDirty: planDirty,
                    formDirty: formDirty,
                    resumeRun: resumeRun,
                    pauseRun: pauseRun,
                    launchRun: launchRun,
                    cancelRun: cancelRun
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
                    lineNumber: 160,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-w-0 flex-1 items-center justify-evenly overflow-x-auto",
                    children: right.map((item, index)=>itemButton(item, index + left.length))
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
                    lineNumber: 179,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
            lineNumber: 140,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-bottom-nav.tsx",
        lineNumber: 134,
        columnNumber: 5
    }, this);
}
_s(DashboardBottomNav, "QG0p7o6V401Tnc2KgFeJt4jYK8o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
});
_c = DashboardBottomNav;
var _c;
__turbopack_context__.k.register(_c, "DashboardBottomNav");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/external-link.mjs [app-client] (ecmascript) <export default as ExternalLink>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw-clock.mjs [app-client] (ecmascript) <export default as History>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/rotate-ccw.mjs [app-client] (ecmascript) <export default as RotateCcw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/user-round.mjs [app-client] (ecmascript) <export default as UserRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/popover.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const statusText = {
    checking: 'Connecting to the engine',
    ready: 'Engine connected',
    offline: 'Engine offline'
};
function DashboardHeader({ available, onRefresh, onOpenHistory, onOpenAccount }) {
    _s();
    const [accountOpen, setAccountOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [profile, setProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardHeader.useEffect": ()=>{
            // Account details only decorate the menu; a failure keeps the neutral initial.
            let alive = true;
            fetch('/api/account', {
                cache: 'no-store'
            }).then({
                "DashboardHeader.useEffect": (response)=>response.ok ? response.json() : null
            }["DashboardHeader.useEffect"]).then({
                "DashboardHeader.useEffect": (value)=>{
                    if (alive && value?.profile) setProfile(value.profile);
                }
            }["DashboardHeader.useEffect"]).catch({
                "DashboardHeader.useEffect": ()=>undefined
            }["DashboardHeader.useEffect"]);
            return ({
                "DashboardHeader.useEffect": ()=>{
                    alive = false;
                }
            })["DashboardHeader.useEffect"];
        }
    }["DashboardHeader.useEffect"], []);
    const displayName = profile?.displayName?.trim() || 'Account';
    const initial = displayName.charAt(0).toUpperCase();
    const avatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(profile?.avatarUrl);
    const closeAnd = (action)=>{
        setAccountOpen(false);
        action();
    };
    const menuItem = 'flex min-h-11 w-full cursor-pointer items-center gap-2.5 rounded-xl px-3 text-left text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 motion-reduce:transition-none';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "shrink-0 border-b border-slate-200 bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto flex max-w-[1760px] items-center justify-between gap-3 px-4 py-3 md:px-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AppMark"], {
                            className: "size-10"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm leading-tight font-extrabold tracking-[-.02em]",
                                    children: [
                                        "Utomator",
                                        ' ',
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-slate-400",
                                            children: "/ Studio"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                            lineNumber: 72,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-slate-500",
                                    children: "Local automation, evidence first"
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            role: "status",
                            title: statusText[available],
                            className: "flex size-6 items-center justify-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: 'size-2.5 rounded-full ring-2 ring-white ' + (available === 'ready' ? 'bg-emerald-500' : 'bg-amber-500')
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sr-only",
                                    children: statusText[available]
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                    lineNumber: 94,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                            open: accountOpen,
                            onOpenChange: setAccountOpen,
                            align: "end",
                            "aria-label": "Account menu",
                            contentClassName: "w-60",
                            trigger: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                "aria-haspopup": "dialog",
                                "aria-expanded": accountOpen,
                                "aria-label": "Account menu",
                                onClick: ()=>setAccountOpen((value)=>!value),
                                className: "block cursor-pointer rounded-full text-slate-300 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 motion-reduce:transition-none",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "inline-flex size-11 items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex size-9 items-center justify-center overflow-hidden rounded-xl bg-[#111a25] font-serif text-sm text-white",
                                        children: avatar ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            unoptimized: true,
                                            src: avatar,
                                            alt: "",
                                            width: 36,
                                            height: 36,
                                            className: "size-9 rounded-xl object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                            lineNumber: 115,
                                            columnNumber: 23
                                        }, this) : initial
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                        lineNumber: 113,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                    lineNumber: 112,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                lineNumber: 104,
                                columnNumber: 15
                            }, this),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col px-1.5 py-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2.5 px-2 py-2.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex size-9 items-center justify-center overflow-hidden rounded-xl bg-[#111a25] font-serif text-sm text-white",
                                                children: avatar ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    unoptimized: true,
                                                    src: avatar,
                                                    alt: "",
                                                    width: 36,
                                                    height: 36,
                                                    className: "size-9 rounded-xl object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                    lineNumber: 135,
                                                    columnNumber: 21
                                                }, this) : initial
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 133,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "truncate text-sm font-semibold text-[#111a25]",
                                                        children: displayName
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-slate-500",
                                                        children: "Local studio"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 151,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 147,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1 border-t border-slate-100 pt-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: menuItem,
                                                onClick: ()=>closeAnd(onOpenHistory),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"], {
                                                        className: "size-4 shrink-0",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 160,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Run history"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 155,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: menuItem,
                                                onClick: ()=>closeAnd(onRefresh),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__["RotateCcw"], {
                                                        className: "size-4 shrink-0",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Refresh workspace"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 163,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                        lineNumber: 154,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "border-t border-slate-100 pt-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: menuItem,
                                                onClick: ()=>closeAnd(onOpenAccount),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__["UserRound"], {
                                                        className: "size-4 shrink-0",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 178,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Account"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 173,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/",
                                                className: menuItem,
                                                onClick: ()=>setAccountOpen(false),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                        className: "size-4 shrink-0",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 186,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Portfolio",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "ml-auto text-[10px] font-medium tracking-wider text-slate-400 uppercase",
                                                        children: "Open"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                        lineNumber: 191,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                                lineNumber: 181,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                        lineNumber: 172,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                                lineNumber: 131,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                            lineNumber: 97,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
            lineNumber: 66,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-header.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
}
_s(DashboardHeader, "TrEqGMW74q67rK8c6gWib4j693E=");
_c = DashboardHeader;
var _c;
__turbopack_context__.k.register(_c, "DashboardHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/activity.mjs [app-client] (ecmascript) <export default as Activity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/compass.mjs [app-client] (ecmascript) <export default as Compass>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/crosshair.mjs [app-client] (ecmascript) <export default as Crosshair>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/file-text.mjs [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/notebook-pen.mjs [app-client] (ecmascript) <export default as NotebookPen>");
'use client';
;
;
function DashboardSidebar({ pane, onNavigate }) {
    const topItems = [
        {
            id: 'workspace',
            label: 'Workspace',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"]
        }
    ];
    const items = [
        {
            id: 'resumes',
            label: 'Résumés',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            id: 'memory',
            label: 'Intelligence',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"]
        },
        {
            id: 'research',
            label: 'Creator research',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__["Crosshair"]
        },
        {
            id: 'editorial',
            label: 'Editorial drafts',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            id: 'growth',
            label: 'Growth',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__["Compass"]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-testid": "automation-navigation-sidebar",
        className: "hidden min-w-0 lg:flex lg:h-full lg:w-auto lg:overflow-hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-full w-full rounded-2xl bg-[#111a25] p-4 text-white shadow-xl shadow-slate-900/10 lg:overflow-hidden",
            children: [
                topItems.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>onNavigate(item.id),
                        "aria-current": pane === item.id ? 'page' : undefined,
                        className: 'flex min-h-10 w-full items-center gap-2.5 rounded-xl px-3 text-left text-xs font-semibold transition ' + (pane === item.id ? 'bg-teal-500/15 text-teal-200' : 'text-slate-300 hover:bg-slate-800'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this),
                            item.label
                        ]
                    }, item.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this)),
                items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>onNavigate(item.id),
                        "aria-current": pane === item.id ? 'page' : undefined,
                        className: 'flex min-h-10 w-full items-center gap-2.5 rounded-xl px-3 text-left text-xs font-semibold transition ' + (pane === item.id ? 'bg-teal-500/15 text-teal-200' : 'text-slate-300 hover:bg-slate-800'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this),
                            item.label
                        ]
                    }, item.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/dashboard-sidebar.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_c = DashboardSidebar;
var _c;
__turbopack_context__.k.register(_c, "DashboardSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/workflow-catalog.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "workflows",
    ()=>workflows
]);
const workflows = {
    linkedin: [
        {
            id: 'audit',
            title: 'Profile audit',
            category: 'Inspect',
            fields: []
        },
        {
            id: 'audit-page',
            title: 'Inspect selected page',
            category: 'Inspect',
            fields: []
        },
        {
            id: 'edit-profile',
            title: 'Headline & About',
            category: 'Profile',
            fields: [
                {
                    key: 'headline',
                    label: 'Headline',
                    max: 220
                },
                {
                    key: 'about',
                    label: 'About',
                    multiline: true,
                    max: 2600
                }
            ]
        },
        {
            id: 'edit-experience',
            title: 'Experience',
            category: 'Profile',
            fields: [
                {
                    key: 'positionId',
                    label: 'Existing LinkedIn position ID',
                    required: true
                },
                {
                    key: 'description',
                    label: 'Experience description',
                    multiline: true,
                    required: true
                },
                {
                    key: 'startMonth',
                    label: 'Start month (optional)'
                },
                {
                    key: 'startYear',
                    label: 'Start year (optional)'
                }
            ]
        },
        {
            id: 'add-skill',
            title: 'Add skill',
            category: 'Profile',
            fields: [
                {
                    key: 'skill',
                    label: 'Exact skill',
                    required: true
                }
            ]
        },
        {
            id: 'edit-website',
            title: 'Contact website',
            category: 'Profile',
            fields: [
                {
                    key: 'website',
                    label: 'HTTPS website',
                    required: true
                },
                {
                    key: 'websiteIndex',
                    label: 'Row index (0–9)',
                    placeholder: '0'
                },
                {
                    key: 'websiteType',
                    label: 'Website type (optional)'
                }
            ]
        },
        {
            id: 'edit-services',
            title: 'Services',
            category: 'Profile',
            fields: [
                {
                    key: 'description',
                    label: 'Services description',
                    multiline: true,
                    required: true
                }
            ]
        },
        {
            id: 'add-project',
            title: 'Add project',
            category: 'Showcase',
            fields: [
                {
                    key: 'projectName',
                    label: 'Project name',
                    required: true
                },
                {
                    key: 'description',
                    label: 'Contribution and outcome',
                    required: true,
                    multiline: true
                },
                {
                    key: 'projectUrl',
                    label: 'Optional media URL'
                }
            ]
        },
        {
            id: 'add-featured',
            title: 'Featured link',
            category: 'Showcase',
            fields: [
                {
                    key: 'projectUrl',
                    label: 'HTTPS destination',
                    required: true
                },
                {
                    key: 'featuredTitle',
                    label: 'Featured title',
                    required: true
                }
            ]
        }
    ],
    x: [
        {
            id: 'audit',
            title: 'Profile audit',
            category: 'Inspect',
            fields: []
        },
        {
            id: 'audit-page',
            title: 'Inspect selected page',
            category: 'Inspect',
            fields: []
        },
        {
            id: 'edit-profile',
            title: 'Bio & contact',
            category: 'Profile',
            fields: [
                {
                    key: 'bio',
                    label: 'Bio',
                    multiline: true,
                    max: 160
                },
                {
                    key: 'location',
                    label: 'Location'
                },
                {
                    key: 'website',
                    label: 'HTTPS website'
                }
            ]
        },
        {
            id: 'upload-banner',
            title: 'Upload banner',
            category: 'Profile',
            fields: [
                {
                    key: 'bannerPath',
                    label: 'Local image in apps/backend/assets',
                    required: true
                }
            ]
        },
        {
            id: 'compose-post',
            title: 'Publish one post',
            category: 'Content',
            fields: [
                {
                    key: 'postText',
                    label: 'Post text',
                    required: true,
                    multiline: true,
                    max: 280
                }
            ]
        },
        {
            id: 'pin-post',
            title: 'Pin post',
            category: 'Content',
            fields: [
                {
                    key: 'postUrl',
                    label: 'Exact post URL',
                    required: true
                }
            ]
        },
        {
            id: 'delete-post',
            title: 'Delete one post',
            category: 'Content',
            fields: [
                {
                    key: 'postUrl',
                    label: 'Exact authored post URL',
                    required: true
                }
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PipelineRunSetupForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/crosshair.mjs [app-client] (ecmascript) <export default as Crosshair>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$focus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Focus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/focus.mjs [app-client] (ecmascript) <export default as Focus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workflow-catalog.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
function PipelineRunSetupForm({ reduceMotion, runFormError, action, platform, chooseAction, scopeSection, setScopeSection, pageOptions, selectedPage, profilePage, setSelectedNode, selected, form, setForm, platformLabel }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].form, {
        className: "space-y-6 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-4 sm:p-5",
        onSubmit: (event)=>event.preventDefault(),
        initial: reduceMotion ? false : {
            opacity: 0,
            y: 10
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: reduceMotion ? {
            duration: 0
        } : {
            type: 'spring',
            stiffness: 380,
            damping: 32
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-sm font-semibold tracking-tight text-slate-950",
                        children: "Run setup"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs leading-5 text-slate-500",
                        children: "Choose the action and page, then start from the dock. Mator stages pipeline edits in the chat beside this board."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            runFormError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800",
                children: runFormError
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 65,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: "workflowSelect",
                className: "block text-xs font-semibold",
                children: [
                    "Workflow action",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        id: "workflowSelect",
                        className: "mt-2 min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm",
                        value: action,
                        onChange: (event)=>chooseAction(event.target.value),
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workflows"][platform].map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: item.id,
                                children: item.title
                            }, item.id, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "page-scope",
                className: "rounded-xl border border-teal-200 bg-teal-50 p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "flex items-center gap-2 text-xs font-bold text-teal-900",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$focus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Focus$3e$__["Focus"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this),
                            "Isolate one page"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "mt-2 block text-xs font-semibold",
                        htmlFor: "pageScope",
                        children: "Page section"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        id: "pageScope",
                        className: "mt-1.5 min-h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm",
                        value: scopeSection,
                        onChange: (e)=>setScopeSection(e.target.value),
                        children: pageOptions.map((part)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: part,
                                children: part === 'profile' ? 'Main profile' : part[0].toUpperCase() + part.slice(1)
                            }, part, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 105,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 font-mono text-[10px] break-all text-teal-800",
                        children: selectedPage || 'Select a saved social profile to set the inspection target.'
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        disabled: !profilePage,
                        onClick: ()=>{
                            chooseAction('audit-page');
                            setSelectedNode('inspect');
                        },
                        className: "mt-2 inline-flex items-center gap-2 text-xs font-bold text-teal-900 hover:underline",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__["Crosshair"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this),
                            "Inspect this page before editing"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            selected.fields.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-3",
                children: selected.fields.map((field)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "mb-1 block text-xs font-semibold",
                                htmlFor: `automation-${field.key}`,
                                children: [
                                    field.label,
                                    field.required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-1 text-rose-500",
                                        children: "*"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                        lineNumber: 139,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 133,
                                columnNumber: 15
                            }, this),
                            field.multiline ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                id: `automation-${field.key}`,
                                className: "min-h-24 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-teal-600",
                                maxLength: field.max || 3000,
                                required: field.required,
                                value: form[field.key] || '',
                                onChange: (event)=>setForm((prev)=>({
                                            ...prev,
                                            [field.key]: event.target.value
                                        }))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 143,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: `automation-${field.key}`,
                                className: "min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-teal-600",
                                maxLength: field.max || 500,
                                placeholder: field.placeholder,
                                required: field.required,
                                value: form[field.key] || '',
                                onChange: (event)=>setForm((prev)=>({
                                            ...prev,
                                            [field.key]: event.target.value
                                        }))
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                                lineNumber: 157,
                                columnNumber: 17
                            }, this)
                        ]
                    }, field.key, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                        lineNumber: 132,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 130,
                columnNumber: 9
            }, this),
            platform === 'linkedin' && action === 'edit-profile' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs leading-5 text-slate-500",
                children: "Use details reviewed for this LinkedIn account. Content from another identity is not auto-filled."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 177,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "rounded-xl bg-white p-3 text-xs leading-6 text-slate-500",
                children: [
                    "Authentication is managed by the selected connection. Use the",
                    ' ',
                    platformLabel,
                    " icon in the floating toolbar to connect, verify, or sync an expired session."
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
                lineNumber: 182,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c = PipelineRunSetupForm;
var _c;
__turbopack_context__.k.register(_c, "PipelineRunSetupForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PipelineWorkspace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.38.0_react_c6850c7a3f6ac082229dee387470c1fc/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$editor$2f$workflow$2d$empty$2d$state$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/workflows/editor/workflow-empty-state.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$workflow$2d$plan$2d$editor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/workflows/workflow-plan-editor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$floating$2d$workflow$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workspace/floating-workflow-controls.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$pipeline$2d$run$2d$setup$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workspace/pipeline-run-setup-form.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function PipelineWorkspace({ pane, workflowPlan, templatePlans, selectedGrowthTemplateId, workspaceOpen, savedWorkflows, beginNewWorkflow, selectSavedWorkflow, closeWorkspace, connectorReady, activeConnector, applyGrowthTemplate, chooseAction, platform, action, events, active, busy, planDirty, formDirty, planSaving, activeWorkflow, configRequest, setWorkflowPlan, setPlanDirty, applyTemplate, saveWorkflowPlan, cancelRun, runFormError, annotateCapture, form, setForm, selected, scopeSection, setScopeSection, pageOptions, selectedPage, profilePage, setSelectedNode, platformLabel, available, loadingWorkflow, launchRun, resumeRun, pauseRun, setConnectorOpenSignal, PlatformIcon }) {
    _s();
    const reduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            pane === 'workspace' && (!workspaceOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$editor$2f$workflow$2d$empty$2d$state$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                platform: platform,
                templates: templatePlans,
                savedWorkflows: savedWorkflows,
                connected: connectorReady,
                busy: busy,
                error: runFormError,
                onNew: beginNewWorkflow,
                onOpenSaved: selectSavedWorkflow,
                onApplyTemplate: applyTemplate,
                onApplyYaml: applyGrowthTemplate
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx",
                lineNumber: 122,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$workflows$2f$workflow$2d$plan$2d$editor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                plan: workflowPlan,
                templates: templatePlans,
                growthTemplateId: selectedGrowthTemplateId,
                growthAccountId: connectorReady ? activeConnector?.id : undefined,
                onGrowthTemplateApply: applyGrowthTemplate,
                onClearGrowth: closeWorkspace,
                onGrowthActionSelect: chooseAction,
                connected: activeConnector?.platform === 'linkedin' && activeConnector?.status === 'connected',
                accountLabel: activeConnector?.platform === platform ? activeConnector.label : undefined,
                events: active?.platform === platform && active.action === action ? events : [],
                state: active?.platform === platform && active.action === action ? active.state : undefined,
                runId: active?.platform === platform && active.action === action ? active.id : undefined,
                busy: busy,
                dirty: planDirty || formDirty,
                saving: planSaving,
                configRequest: configRequest,
                onPlanChange: (next)=>{
                    setWorkflowPlan(next);
                    setPlanDirty(true);
                },
                onTemplateApply: applyTemplate,
                onSave: saveWorkflowPlan,
                runError: runFormError,
                evidenceRoot: active ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${active.id}/evidence/`) : undefined,
                onEvidenceOpen: annotateCapture,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$pipeline$2d$run$2d$setup$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    reduceMotion: Boolean(reduceMotion),
                    runFormError: runFormError,
                    action: action,
                    platform: platform,
                    chooseAction: chooseAction,
                    scopeSection: scopeSection,
                    setScopeSection: setScopeSection,
                    pageOptions: pageOptions,
                    selectedPage: selectedPage,
                    profilePage: profilePage,
                    setSelectedNode: setSelectedNode,
                    selected: selected,
                    form: form,
                    setForm: setForm,
                    platformLabel: platformLabel
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx",
                    lineNumber: 183,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx",
                lineNumber: 135,
                columnNumber: 11
            }, this)),
            pane === 'workspace' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workspace$2f$floating$2d$workflow$2d$controls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                selectedGrowthTemplateId: selectedGrowthTemplateId,
                workspaceOpen: workspaceOpen,
                active: active,
                platform: platform,
                action: action,
                busy: busy,
                available: available,
                connectorReady: connectorReady,
                loadingWorkflow: loadingWorkflow,
                workflowPlan: workflowPlan,
                activeWorkflow: activeWorkflow,
                planDirty: planDirty,
                formDirty: formDirty,
                resumeRun: resumeRun,
                pauseRun: pauseRun,
                launchRun: launchRun,
                cancelRun: cancelRun,
                setConnectorOpenSignal: setConnectorOpenSignal,
                platformLabel: platformLabel,
                PlatformIcon: PlatformIcon
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/pipeline-workspace.tsx",
                lineNumber: 203,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(PipelineWorkspace, "yAKkJs7CtWSNDV8HpmqLOOhKJtw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$38$2e$0_react_c6850c7a3f6ac082229dee387470c1fc$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
});
_c = PipelineWorkspace;
var _c;
__turbopack_context__.k.register(_c, "PipelineWorkspace");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RunHistory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/arrow-right.mjs [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/automate-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$presentation$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/presentation-utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
function RunHistory({ runs, onSelect }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                        children: "Recent executions"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                        children: "Stored in memory during the current engine session. Select a run to inspect streamed events."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$automate$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "divide-y divide-slate-100",
                    children: [
                        runs.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "py-10 text-center text-sm text-slate-500",
                            children: "No runs yet. Start an audit to capture the first trace."
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                            lineNumber: 40,
                            columnNumber: 13
                        }, this),
                        runs.map((run)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "flex min-h-16 w-full items-center justify-between gap-3 py-3 text-left hover:bg-slate-50",
                                onClick: ()=>onSelect(run),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block text-sm font-semibold capitalize",
                                                children: [
                                                    run.platform,
                                                    " / ",
                                                    run.action.replaceAll('-', ' ')
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                                lineNumber: 52,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-slate-500",
                                                children: [
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$presentation$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["short"])(run.id),
                                                    " · ",
                                                    new Date(run.createdAt).toLocaleString()
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                                lineNumber: 55,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                        lineNumber: 51,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-semibold text-slate-500 capitalize",
                                        children: [
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$presentation$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stateLabel"])(run.state),
                                            ' ',
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                className: "ml-1 inline size-3"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                                lineNumber: 61,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                        lineNumber: 59,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, run.id, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/pipeline/run-history.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_c = RunHistory;
var _c;
__turbopack_context__.k.register(_c, "RunHistory");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/dashboard-route.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDashboardRoute",
    ()=>getDashboardRoute
]);
function getDashboardRoute(pathname) {
    const libraryView = pathname.endsWith('/source') ? 'source' : pathname.startsWith('/growth/') || pathname.startsWith('/dashboard/growth/') || pathname.startsWith('/dashboard/crafts/') ? 'visual' : 'catalog';
    let pane = null;
    let craftId;
    if (pathname === '/growth/default-growth-profile') {
        pane = 'growth';
        craftId = 'default-growth-profile';
    } else if (pathname.startsWith('/dashboard/growth/') || pathname.startsWith('/dashboard/crafts/')) {
        const id = pathname.split('/')[3];
        pane = 'growth';
        craftId = id || null;
    } else if (pathname === '/dashboard/crafts') pane = 'growth';
    else if (pathname === '/dashboard/history') pane = 'history';
    else if (pathname.startsWith('/dashboard/profile')) pane = 'profile';
    else if (pathname.startsWith('/dashboard/resumes')) pane = 'resumes';
    else if (pathname === '/dashboard/observer') pane = 'observer';
    else if (pathname === '/dashboard/memory') pane = 'memory';
    else if (pathname === '/dashboard/research') pane = 'research';
    else if (pathname === '/dashboard/editorial') pane = 'editorial';
    else if (pathname === '/dashboard/growth') pane = 'growth';
    else if (pathname === '/dashboard/settings') pane = 'settings';
    else if (pathname === '/dashboard/workspace' || pathname === '/dashboard/pipeline') pane = 'workspace';
    return {
        pane,
        craftId,
        libraryView
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/use-dashboard-navigation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDashboardNavigation",
    ()=>useDashboardNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$route$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/dashboard-route.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useDashboardNavigation(initialPane) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const route = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$route$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDashboardRoute"])(pathname);
    const [requestedPane, setPane] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialPane);
    const [mobileMenu, setMobileMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [rememberedCraftId, setSelectedCraftId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useDashboardNavigation.useState": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$dashboard$2d$route$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDashboardRoute"])(pathname).craftId ?? null
    }["useDashboardNavigation.useState"]);
    const [selectedCraftSlug, setSelectedCraftSlug] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pane = route.pane ?? requestedPane;
    const selectedCraftId = route.craftId === undefined ? rememberedCraftId : route.craftId;
    const { libraryView } = route;
    function navigate(path) {
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.location.pathname !== path) window.history.pushState(null, '', path);
    }
    function navigatePane(next) {
        if (next !== pane && typeof document !== 'undefined' && document.querySelector('[data-career-dirty="true"]') && !window.confirm('Discard unsaved career edits?')) return;
        setPane(next);
        navigate(`/dashboard/${next}`);
    }
    function navigateSubpage(path) {
        if (typeof document !== 'undefined' && document.querySelector('[data-career-dirty="true"]') && !window.confirm('Discard unsaved career edits?')) return;
        setPane(path.startsWith('/dashboard/resumes') ? 'resumes' : path.startsWith('/dashboard/settings') ? 'settings' : 'profile');
        navigate(path);
    }
    function navigateCraft(id, slug) {
        setPane('growth');
        setSelectedCraftId(id);
        if (id && slug) setSelectedCraftSlug(slug);
        if (!id) setSelectedCraftSlug(null);
        const target = id ? `/dashboard/growth/${encodeURIComponent(id)}` : '/dashboard/growth';
        navigate(id && pathname === `${target}/source` ? pathname : target);
    }
    function navigateCraftView(next) {
        if (!selectedCraftId) return;
        navigate('/dashboard/growth/' + encodeURIComponent(selectedCraftId) + (next === 'source' ? '/source' : ''));
    }
    return {
        pathname,
        pane,
        setPane,
        mobileMenu,
        setMobileMenu,
        selectedCraftId,
        selectedCraftSlug,
        libraryView,
        navigate,
        navigatePane,
        navigateSubpage,
        navigateCraft,
        navigateCraftView
    };
}
_s(useDashboardNavigation, "YSxggprYYOLu/KDOao8Yw/Q7Mis=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/craft-command-editor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "editCraftFromCommand",
    ()=>editCraftFromCommand
]);
function editCraftFromCommand(chosen, command) {
    if (chosen.scope === 'default') throw Error('This shared craft is read-only. Clone it to create your own editable version.');
    const draft = {
        slug: chosen.slug,
        name: chosen.name,
        description: chosen.description,
        category: chosen.category,
        enabled: chosen.enabled,
        steps: chosen.steps.map((item)=>({
                ...item
            })),
        links: chosen.links.map((item)=>({
                ...item
            }))
    };
    const addition = command.match(/^add\s+([^|]+)\|\s*([\s\S]+)$/i);
    const link = command.match(/^(link|unlink)\s+([a-z0-9-]+)\s*->\s*([a-z0-9-]+)$/i);
    const rename = command.match(/^rename\s+(.+)$/i);
    const description = command.match(/^description\s+([\s\S]+)$/i);
    if (addition) {
        const title = addition[1]?.trim().slice(0, 100);
        const idBase = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 45);
        if (!idBase) throw Error('Specify an alphanumeric step title.');
        let id = idBase, number = 2;
        while(draft.steps.some((item)=>item.id === id))id = `${idBase}-${number++}`;
        draft.steps.push({
            id,
            title,
            kind: 'draft',
            body: addition[2]?.trim().slice(0, 8000),
            position: {
                x: 70 + draft.steps.length * 180,
                y: 220 + draft.steps.length % 3 * 140
            }
        });
    } else if (link) {
        const source = link[2], target = link[3], id = `${source}-to-${target}`;
        if (!draft.steps.some((item)=>item.id === source) || !draft.steps.some((item)=>item.id === target)) throw Error('Both step IDs must exist in the selected craft.');
        if (link[1]?.toLowerCase() === 'link') {
            if (draft.links.some((item)=>item.id === id)) throw Error('These steps are already connected.');
            draft.links.push({
                id,
                source,
                target
            });
        } else {
            if (!draft.links.some((item)=>item.id === id)) throw Error('The connection does not exist.');
            draft.links = draft.links.filter((item)=>item.id !== id);
        }
    } else if (rename) {
        draft.name = rename[1]?.trim().slice(0, 100);
    } else if (description) {
        draft.description = description[1]?.trim().slice(0, 1023);
    } else if (/^(enable|disable)$/i.test(command)) {
        draft.enabled = command.toLowerCase() === 'enable';
    } else throw Error('Unknown command. Try /craft help to see supported edits.');
    return {
        expectedVersion: chosen.version,
        craft: draft
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/craft-command-service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeCraftCommand",
    ()=>executeCraftCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$craft$2d$command$2d$editor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/craft-command-editor.ts [app-client] (ecmascript)");
;
;
async function executeCraftCommand(text, selectedCraftId) {
    const command = text.trim().replace(/^\/?craft\s*/i, '').trim();
    const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('crafts'), {
        cache: 'no-store'
    });
    if (!response.ok) throw Error('Craft library is unavailable; start the local API');
    const library = await response.json();
    if (/^(?:crafts|list|help)?$/i.test(command)) {
        return {
            kind: 'list',
            notice: 'Crafts opened. Commands: /craft open <slug>; /craft add <title> | <instructions>; /craft link <from> -> <to>; /craft unlink <from> -> <to>; /craft rename <name>; /craft enable; /craft disable. You can also edit visually or in MDX.'
        };
    }
    const opening = command.match(/^open\s+([a-z0-9-]+)$/i);
    if (opening) {
        const wanted = library.find((item)=>item.slug === opening[1]);
        if (!wanted) throw Error(`No craft matches the slug ${opening[1]}`);
        return {
            kind: 'open',
            id: wanted.id,
            slug: wanted.slug,
            notice: 'Opened ' + wanted.name + ' in the craft editor. Select nodes or drag handles to rewire, then save.'
        };
    }
    const chosen = library.find((item)=>item.id === selectedCraftId);
    if (!chosen) throw Error('Select a craft in Crafts first.');
    const { expectedVersion, craft } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$craft$2d$command$2d$editor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["editCraftFromCommand"])(chosen, command);
    const responseSave = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`crafts/${chosen.id}`), {
        method: 'PUT',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({
            expectedVersion,
            craft
        })
    });
    const saved = await responseSave.json();
    if (!responseSave.ok) throw Error(saved.error || 'Craft edit was rejected');
    return {
        kind: 'updated',
        id: saved.id,
        slug: saved.slug,
        notice: 'Updated ' + saved.name + ' · v' + saved.version + '. The graph and MDX source now share this revision.'
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/command-parser.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "explainCommand",
    ()=>explainCommand,
    "isLegacyExact",
    ()=>isLegacyExact
]);
const AUDIT_NOTE = 'Read-only audit prepared. Start the run to collect current profile evidence.';
const HEADLINE_NOTE = 'Headline staged for review. No change has been published.';
const SKILL_NOTE = 'Skill selected. LinkedIn will confirm the exact catalog entry.';
const POST_NOTE = 'Post staged. Publishing still requires your explicit approval.';
function spokenValue(value) {
    const cleaned = value.trim().replace(/^to\s+/i, '').replace(/^[:-]\s*/, '').trim();
    if (!cleaned || /^(?:called|named)$/i.test(cleaned)) return null;
    return cleaned;
}
function matchLegacy(text) {
    if (/^(audit|inspect|review)(?:\s+(?:my\s+)?profile)?[.!]?$/i.test(text)) {
        return {
            action: 'audit',
            fields: {},
            note: AUDIT_NOTE
        };
    }
    const headline = text.match(/^(?:set|update|draft)\s+(?:my\s+)?headline\s*:\s*([\s\S]+)$/i);
    if (headline) {
        return {
            action: 'edit-profile',
            fields: {
                headline: headline[1].trim()
            },
            note: HEADLINE_NOTE
        };
    }
    const skill = text.match(/^(?:add)\s+(?:the\s+)?skill\s*:\s*([\s\S]+)$/i);
    if (skill) {
        return {
            action: 'add-skill',
            fields: {
                skill: skill[1].trim()
            },
            note: SKILL_NOTE
        };
    }
    const post = text.match(/^(?:draft|compose)\s+(?:a\s+)?post\s*:\s*([\s\S]+)$/i);
    if (post) {
        return {
            action: 'compose-post',
            fields: {
                postText: post[1].trim()
            },
            note: POST_NOTE
        };
    }
    return null;
}
function matchNatural(text) {
    if (/^(?:check|review|audit)\s+(?:my\s+)?linkedin$/i.test(text) || /^check\s+(?:my\s+)?profile$/i.test(text)) {
        return {
            action: 'audit',
            fields: {},
            note: AUDIT_NOTE
        };
    }
    const headline = text.match(/^(?:change|set|update)\s+(?:my\s+)?headline\s+to\s+([\s\S]+)$/i);
    const madeHeadline = headline ? null : text.match(/^(?:make)\s+(?:my\s+)?headline\s+([\s\S]+)$/i);
    const headlineValue = spokenValue((headline ?? madeHeadline)?.[1] ?? '');
    if ((headline || madeHeadline) && headlineValue) {
        return {
            action: 'edit-profile',
            fields: {
                headline: headlineValue
            },
            note: HEADLINE_NOTE
        };
    }
    if (headline || madeHeadline) return null;
    const skill = text.match(/^(?:add)\s+(?:(?:a|the)\s+)?skill(?:\s+(?:called|named))?\s+([\s\S]+)$/i);
    if (skill) {
        const value = spokenValue(skill[1]);
        if (!value) return null;
        return {
            action: 'add-skill',
            fields: {
                skill: value
            },
            note: SKILL_NOTE
        };
    }
    const post = text.match(/^(?:draft|write|compose)\s+(?:a\s+)?post\s+(?:about|saying)\s+([\s\S]+)$/i);
    if (post) {
        const value = spokenValue(post[1]);
        if (!value) return null;
        return {
            action: 'compose-post',
            fields: {
                postText: value
            },
            note: POST_NOTE
        };
    }
    return null;
}
function explainCommand(value) {
    const text = value.trim();
    if (!text) return null;
    return matchLegacy(text) ?? matchNatural(text.replace(/[.!?]+$/g, '').trim());
}
function isLegacyExact(value) {
    const text = value.trim();
    return text.length > 0 && matchLegacy(text) !== null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/utterance.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "decideUtterance",
    ()=>decideUtterance,
    "hearingReply",
    ()=>hearingReply,
    "nextCommandState",
    ()=>nextCommandState,
    "pendingCommandLabel",
    ()=>pendingCommandLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$command$2d$parser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/command-parser.ts [app-client] (ecmascript)");
;
const CONFIRM = /^(?:stage it|stage this|go ahead)$/i;
const CANCEL = /^(?:cancel|never mind|nevermind)$/i;
const UNKNOWN = 'I can audit a profile, change a headline, add a skill, or draft a post. Say it in your own words.';
const IDLE = 'Nothing is waiting to be staged.';
function phrase(value) {
    return value.trim().replace(/[.!?]+$/g, '').trim();
}
function quote(value) {
    return `'${value}'`;
}
function hearingReply(command) {
    if (command.fields.headline) {
        return `I heard a new headline: ${quote(command.fields.headline)}. Nothing is staged until you confirm. No change is published until you approve it.`;
    }
    if (command.fields.skill) {
        return `I heard a skill: ${quote(command.fields.skill)}. Nothing is staged until you confirm. LinkedIn will still confirm the exact catalog entry.`;
    }
    if (command.fields.postText) {
        return `I heard a post: ${quote(command.fields.postText)}. Nothing is staged until you confirm. Publishing still needs your explicit approval.`;
    }
    return 'I heard an audit. Nothing is staged until you confirm. The run stays read-only until you start it.';
}
function pendingCommandLabel(command) {
    if (command.fields.headline || command.action === 'edit-profile') return 'headline';
    if (command.fields.skill || command.action === 'add-skill') return 'skill';
    if (command.fields.postText || command.action === 'compose-post') return 'post';
    return 'audit';
}
function decideUtterance(value, source, hasPending) {
    const request = value.trim();
    if (!request) return {
        kind: 'ignore'
    };
    const spoken = phrase(request);
    if (CONFIRM.test(spoken)) {
        return hasPending ? {
            kind: 'confirm-pending'
        } : {
            kind: 'nothing-pending',
            reply: IDLE
        };
    }
    if (CANCEL.test(spoken)) {
        return hasPending ? {
            kind: 'cancel-pending',
            reply: 'Dropped. Nothing was staged.'
        } : {
            kind: 'nothing-pending',
            reply: IDLE
        };
    }
    if (/^(?:\/?craft(?:\s|$)|crafts$)/i.test(request)) return {
        kind: 'craft'
    };
    if (/^(what do you remember\??|show memory|memory)$/i.test(spoken)) {
        return {
            kind: 'memory'
        };
    }
    if (/^(inspect this page|audit this page)$/i.test(spoken)) {
        return {
            kind: 'inspect-page'
        };
    }
    const command = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$command$2d$parser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explainCommand"])(request);
    if (!command) return {
        kind: 'unknown',
        reply: UNKNOWN
    };
    if (source === 'text' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$command$2d$parser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLegacyExact"])(request)) {
        return {
            kind: 'stage-now',
            command
        };
    }
    return {
        kind: 'needs-confirm',
        command,
        reply: hearingReply(command)
    };
}
function nextCommandState(pending, decision) {
    switch(decision.kind){
        case 'ignore':
        case 'craft':
        case 'memory':
        case 'inspect-page':
            return {
                pending,
                stage: null,
                reply: null
            };
        case 'confirm-pending':
            if (!pending) return {
                pending: null,
                stage: null,
                reply: IDLE
            };
            return {
                pending: null,
                stage: pending,
                reply: pending.note
            };
        case 'cancel-pending':
            return {
                pending: null,
                stage: null,
                reply: decision.reply
            };
        case 'nothing-pending':
            return {
                pending,
                stage: null,
                reply: decision.reply
            };
        case 'stage-now':
            return {
                pending: null,
                stage: decision.command,
                reply: decision.command.note
            };
        case 'needs-confirm':
            return {
                pending: decision.command,
                stage: null,
                reply: decision.reply
            };
        case 'unknown':
            return {
                pending,
                stage: null,
                reply: decision.reply
            };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/use-operator-commands.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOperatorCommands",
    ()=>useOperatorCommands
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$craft$2d$command$2d$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/craft-command-service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$utterance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/utterance.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/workflow-catalog.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function useOperatorCommands({ message, setMessage, setConversation, chatNotice, onSpeak, platform, accountId, selectedCraftId, selectedPage, navigatePane, navigateCraft, setCraftsRevision, onStageWorkflow, setSelectedNode }) {
    _s();
    const [pending, setPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pendingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    function setPendingCommand(next) {
        pendingRef.current = next;
        setPending(next);
    }
    function reply(text) {
        chatNotice(text);
        try {
            onSpeak(text);
        } catch  {
        /* Speech is optional. The written reply still stands. */ }
    }
    function remember(text) {
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])('intelligence/chat', {
            text,
            platform,
            ...accountId ? {
                accountId
            } : {}
        }).catch((error)=>reply('This message was not stored in memory: ' + (error instanceof Error ? error.message : 'Storage unavailable')));
    }
    function stage(command) {
        navigatePane('workspace');
        return onStageWorkflow(command.action, command.fields);
    }
    function unsupported() {
        return 'That operation is not supported on ' + (platform === 'x' ? 'X' : 'LinkedIn') + '. Choose another platform or supported workflow.';
    }
    function supported(action) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$workflow$2d$catalog$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workflows"][platform].some((workflow)=>workflow.id === action);
    }
    function apply(decision) {
        if ((decision.kind === 'stage-now' || decision.kind === 'needs-confirm') && !supported(decision.command.action)) {
            setPendingCommand(null);
            reply(unsupported());
            return;
        }
        const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$utterance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextCommandState"])(pendingRef.current, decision);
        if (next.stage && !supported(next.stage.action)) {
            setPendingCommand(null);
            reply(unsupported());
            return;
        }
        setPendingCommand(next.pending);
        if (next.stage) {
            void stage(next.stage).then(()=>{
                if (next.reply) reply(next.reply);
            }).catch((cause)=>reply(cause instanceof Error ? cause.message : 'Unable to stage this workflow'));
        } else if (next.reply) {
            reply(next.reply);
        }
    }
    async function handleCraftCommand(text) {
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$craft$2d$command$2d$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeCraftCommand"])(text, selectedCraftId);
            if (result.kind === 'list') {
                navigatePane('growth');
            } else {
                if (result.kind === 'updated') setCraftsRevision((value)=>value + 1);
                navigateCraft(result.id, result.slug);
            }
            reply(result.notice);
        } catch (error) {
            reply(error instanceof Error ? error.message : 'Unable to edit craft');
        }
    }
    function submitUtterance(text, source) {
        const request = text.trim();
        if (!request) return;
        if (source === 'text') setMessage('');
        setConversation((previous)=>[
                ...previous,
                {
                    id: Date.now() + Math.random(),
                    sender: 'user',
                    text: request
                }
            ]);
        remember(request);
        const decision = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$utterance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decideUtterance"])(request, source, pendingRef.current !== null);
        if (decision.kind === 'craft') {
            void handleCraftCommand(request === 'crafts' ? '/craft help' : request);
            return;
        }
        if (decision.kind === 'memory') {
            void fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('intelligence'), {
                cache: 'no-store'
            }).then(async (response)=>{
                if (!response.ok) throw Error('Memory unavailable');
                const entries = await response.json();
                const summary = entries.filter((item)=>item.source === 'chat').slice(0, 5).map((item)=>`• ${item.text}`).join('\n');
                reply(summary || 'No chat-origin memory has been saved yet.');
            }).catch(()=>reply('Could not load local conversation memory.'));
            return;
        }
        if (decision.kind === 'inspect-page') {
            navigatePane('workspace');
            void onStageWorkflow('audit-page').then(()=>{
                setSelectedNode('inspect');
                reply('Scoped read-only inspection staged for ' + selectedPage + '. Use Start Inspect selected page in the artboard to open the real page.');
            }).catch((cause)=>reply(cause instanceof Error ? cause.message : 'Could not load the inspection workflow'));
            return;
        }
        apply(decision);
    }
    function sendMessage(event) {
        event.preventDefault();
        submitUtterance(message, 'text');
    }
    function confirmPending() {
        apply((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$utterance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decideUtterance"])('stage this', 'text', pendingRef.current !== null));
    }
    return {
        handleCraftCommand,
        sendMessage,
        submitUtterance,
        confirmPending,
        pendingLabel: pending ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$utterance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pendingCommandLabel"])(pending) : null
    };
}
_s(useOperatorCommands, "ATMh0REje+kzPSc7BWHjB/+VsFM=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/run-event-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appendRunEvent",
    ()=>appendRunEvent,
    "belongsToRun",
    ()=>belongsToRun,
    "isPauseOrResume",
    ()=>isPauseOrResume,
    "isTerminalRunStatus",
    ()=>isTerminalRunStatus,
    "reconcileRunJournal",
    ()=>reconcileRunJournal
]);
function appendRunEvent(previous, item) {
    return previous.some((entry)=>entry.id === item.id) ? previous : [
        ...previous,
        item
    ];
}
function belongsToRun(event, currentRunId) {
    return event.runId === currentRunId;
}
function isPauseOrResume(event) {
    return event.kind === 'status' && (event.message.startsWith('Run paused') || event.message.startsWith('Run resumed'));
}
function isTerminalRunStatus(event) {
    return event.kind === 'status' && (event.message.startsWith('Run ended:') || event.message.includes('Run finished'));
}
function reconcileRunJournal(previous, archived, runId) {
    const values = new Map();
    const conflicts = new Set();
    for (const event of [
        ...previous,
        ...archived
    ]){
        if (event.runId !== runId || !Number.isSafeInteger(event.id) || event.id < 1) continue;
        if (conflicts.has(event.id)) continue;
        const earlier = values.get(event.id);
        if (earlier && JSON.stringify(earlier) !== JSON.stringify(event)) {
            values.delete(event.id);
            conflicts.add(event.id);
        } else if (!earlier) {
            values.set(event.id, event);
        }
    }
    return [
        ...values.values()
    ].sort((a, b)=>a.id - b.id);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/use-run-monitor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRunMonitor",
    ()=>useRunMonitor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/run-event-utils.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useRunMonitor(onNotice, onRunError) {
    _s();
    const [reviews, setReviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [available, setAvailable] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('checking');
    const [playbook, setPlaybook] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [assessment, setAssessment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [runs, setRuns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [active, setActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [events, setEvents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [checkpoint, setCheckpoint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [checkpointError, setCheckpointError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [inputReply, setInputReply] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [currentRunId, setCurrentRunId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const streamRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const journalRequestRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const currentRunRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useRunMonitor.useCallback[refresh]": async ()=>{
            try {
                const [health, recent, rules, savedReviews] = await Promise.all([
                    fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('health'), {
                        cache: 'no-store'
                    }),
                    fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('runs'), {
                        cache: 'no-store'
                    }),
                    fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('playbook'), {
                        cache: 'no-store'
                    }),
                    fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('visual-reviews'), {
                        cache: 'no-store'
                    })
                ]);
                if (!health.ok) throw new Error('Engine health request failed');
                setAvailable('ready');
                if (recent.ok) {
                    const list = await recent.json();
                    setRuns(list);
                    if (currentRunRef.current) {
                        const matching = list.find({
                            "useRunMonitor.useCallback[refresh].matching": (run)=>run.id === currentRunRef.current
                        }["useRunMonitor.useCallback[refresh].matching"]);
                        if (matching) {
                            setActive(matching);
                            if ([
                                'completed',
                                'blocked',
                                'failed',
                                'cancelled'
                            ].includes(matching.state)) setCheckpoint(null);
                            else if (matching.checkpoint && [
                                'approval-needed',
                                'input-needed'
                            ].includes(matching.state)) setCheckpoint({
                                kind: matching.state === 'approval-needed' ? 'approval' : 'input',
                                id: matching.checkpoint.id,
                                message: matching.checkpoint.message
                            });
                        }
                    }
                }
                if (rules.ok) setPlaybook(await rules.json());
                if (savedReviews.ok) setReviews(await savedReviews.json());
                if (currentRunRef.current) {
                    const current = await (await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${currentRunRef.current}`), {
                        cache: 'no-store'
                    })).json();
                    if (current.action === 'audit') {
                        const report = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${current.id}/assessment`), {
                            cache: 'no-store'
                        });
                        if (report.ok) setAssessment(await report.json());
                    }
                }
            } catch  {
                setAvailable('offline');
            }
        }
    }["useRunMonitor.useCallback[refresh]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRunMonitor.useEffect": ()=>{
            void refresh();
            const timer = setInterval({
                "useRunMonitor.useEffect.timer": ()=>{
                    void refresh();
                }
            }["useRunMonitor.useEffect.timer"], 20000);
            return ({
                "useRunMonitor.useEffect": ()=>{
                    clearInterval(timer);
                    streamRef.current?.close();
                    journalRequestRef.current?.abort();
                }
            })["useRunMonitor.useEffect"];
        }
    }["useRunMonitor.useEffect"], [
        refresh
    ]);
    function connect(runId) {
        streamRef.current?.close();
        const source = new EventSource((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`events/${runId}`));
        streamRef.current = source;
        const kinds = [
            'status',
            'step',
            'audit',
            'approval',
            'input',
            'screenshot',
            'error',
            'result'
        ];
        const consume = (incoming)=>{
            const item = JSON.parse(incoming.data);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["belongsToRun"])(item, currentRunRef.current)) return;
            setEvents((prev)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reconcileRunJournal"])(prev, [
                    item
                ], item.runId));
            if (item.kind === 'approval' || item.kind === 'input') {
                setCheckpointError('');
                setCheckpoint({
                    kind: item.kind,
                    id: item.details?.checkpointId || '',
                    message: item.message
                });
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPauseOrResume"])(item)) void refresh();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTerminalRunStatus"])(item)) {
                setCheckpoint(null);
                void refresh();
            }
        };
        for (const kind of kinds)source.addEventListener(kind, consume);
        source.onerror = ()=>{
            setAvailable('offline');
        }; // EventSource retries automatically.
    }
    async function hydrateRunJournal(runId) {
        journalRequestRef.current?.abort();
        const controller = new AbortController();
        journalRequestRef.current = controller;
        try {
            const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`runs/${runId}/logs`), {
                cache: 'no-store',
                signal: controller.signal
            });
            if (!response.ok) throw Error(`Runner journal unavailable (HTTP ${response.status})`);
            const archived = await response.json();
            if (!Array.isArray(archived)) throw Error('Invalid saved Runner journal');
            if (controller.signal.aborted || currentRunRef.current !== runId) return;
            setEvents((previous)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$run$2d$event$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reconcileRunJournal"])(previous, archived, runId));
            if (response.headers?.get('x-run-journal-truncated') === 'true') onRunError('Earlier Runner events were omitted. Execution history is incomplete.');
        } catch (error) {
            if (!controller.signal.aborted && currentRunRef.current === runId) onRunError(error instanceof Error ? error.message : 'Runner journal unavailable');
        }
    }
    async function startMonitoredRun(payload, action, platform) {
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])('runs', payload);
        if (!result.id) throw new Error('Server did not return a run ID');
        currentRunRef.current = result.id;
        setCurrentRunId(result.id);
        setActive({
            id: result.id,
            action,
            platform,
            state: 'running',
            createdAt: new Date().toISOString()
        });
        setEvents([]);
        setAssessment(null);
        setCheckpoint(null);
        connect(result.id);
        void refresh();
    }
    function selectRun(run) {
        currentRunRef.current = run.id;
        setCurrentRunId(run.id);
        setActive(run);
        setEvents([]);
        setCheckpoint(run.checkpoint && [
            'approval-needed',
            'input-needed'
        ].includes(run.state) ? {
            kind: run.state === 'approval-needed' ? 'approval' : 'input',
            id: run.checkpoint.id,
            message: run.checkpoint.message
        } : null);
        streamRef.current?.close();
        if (![
            'completed',
            'blocked',
            'failed',
            'cancelled'
        ].includes(run.state)) connect(run.id);
        void hydrateRunJournal(run.id);
    }
    async function pauseRun() {
        if (!active) return;
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`runs/${active.id}/pause`);
            void refresh();
        } catch (e) {
            onRunError(e instanceof Error ? e.message : 'Could not pause');
        }
    }
    async function resumeRun() {
        if (!active) return;
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`runs/${active.id}/resume`);
            void refresh();
        } catch (e) {
            onRunError(e instanceof Error ? e.message : 'Could not resume');
        }
    }
    async function act(approve, text) {
        if (!active || !checkpoint) return;
        setCheckpointError('');
        try {
            if (checkpoint.kind === 'approval') await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`runs/${active.id}/decision`, {
                checkpointId: checkpoint.id,
                approved: approve
            });
            else await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`runs/${active.id}/input`, {
                checkpointId: checkpoint.id,
                value: text || ''
            });
            setCheckpoint(null);
            setInputReply('');
        } catch (error) {
            const detail = error instanceof Error ? error.message : 'Action failed';
            setCheckpointError(detail);
            onNotice(detail);
        }
    }
    async function cancelRun() {
        if (!active) return;
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`runs/${active.id}/cancel`);
            void refresh();
        } catch (error) {
            onNotice(String(error));
        }
    }
    return {
        available,
        playbook,
        assessment,
        runs,
        active,
        events,
        checkpoint,
        checkpointError,
        inputReply,
        setInputReply,
        reviews,
        currentRunId,
        refresh,
        startMonitoredRun,
        selectRun,
        pauseRun,
        resumeRun,
        act,
        cancelRun
    };
}
_s(useRunMonitor, "9YDhrL/1aGZ2ha6hyKNHViBYA2I=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/default-workflow-plan.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultWorkflowPlan",
    ()=>defaultWorkflowPlan,
    "newWorkflowDraft",
    ()=>newWorkflowDraft
]);
const defaultWorkflowPlan = ()=>({
        version: 1,
        platform: 'linkedin',
        action: 'audit',
        name: 'Profile audit',
        steps: [
            {
                id: 'start',
                kind: 'start',
                title: 'Start run'
            },
            {
                id: 'session',
                kind: 'session',
                title: 'Authenticated browser'
            },
            {
                id: 'inspect',
                kind: 'inspect',
                title: 'Inspect current page'
            },
            {
                id: 'action',
                kind: 'action',
                title: 'Inspect page'
            },
            {
                id: 'verify',
                kind: 'verify',
                title: 'Observe final page'
            },
            {
                id: 'finish',
                kind: 'finish',
                title: 'Final output'
            }
        ],
        links: [
            {
                source: 'start',
                target: 'session'
            },
            {
                source: 'session',
                target: 'inspect'
            },
            {
                source: 'inspect',
                target: 'action'
            },
            {
                source: 'action',
                target: 'verify'
            },
            {
                source: 'verify',
                target: 'finish'
            }
        ]
    });
const newWorkflowDraft = (platform)=>{
    const steps = [
        {
            id: 'start',
            kind: 'start',
            title: 'Start workflow'
        },
        {
            id: 'session',
            kind: 'session',
            title: 'Verify account session'
        },
        {
            id: 'action',
            kind: 'action',
            title: 'Configure the approved action'
        },
        {
            id: 'finish',
            kind: 'finish',
            title: 'Review recorded output'
        }
    ];
    return {
        version: 1,
        platform,
        action: 'audit',
        name: 'Untitled workflow',
        steps,
        links: steps.slice(1).map((step, i)=>({
                source: steps[i]?.id,
                target: step.id
            }))
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/pipeline/use-workflow-workspace.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useWorkflowWorkspace",
    ()=>useWorkflowWorkspace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$default$2d$workflow$2d$plan$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/pipeline/default-workflow-plan.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useWorkflowWorkspace({ busy, setRunFormError }) {
    _s();
    const [platform, setPlatform] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('linkedin');
    const [action, setAction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('audit');
    const [handle, setHandle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [workflowPlan, setWorkflowPlan] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$default$2d$workflow$2d$plan$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultWorkflowPlan"]);
    const [templatePlans, setTemplatePlans] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedGrowthTemplateId, setSelectedGrowthTemplateId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [savedWorkflows, setSavedWorkflows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [activeWorkflow, setActiveWorkflow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [workspaceOpen, setWorkspaceOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loadingWorkflow, setLoadingWorkflow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const workflowSelectionEpoch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const savedListEpoch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const [planDirty, setPlanDirty] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [planSaving, setPlanSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const formDirty = JSON.stringify(form) !== JSON.stringify(workflowPlan.parameters ?? {});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWorkflowWorkspace.useEffect": ()=>{
            let live = true;
            const generation = savedListEpoch.current;
            void fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('workflows'), {
                cache: 'no-store'
            }).then({
                "useWorkflowWorkspace.useEffect": async (response)=>{
                    if (!response.ok) throw Error('Saved workflows unavailable');
                    const records = await response.json();
                    if (!live || savedListEpoch.current !== generation) return;
                    setSavedWorkflows(records);
                }
            }["useWorkflowWorkspace.useEffect"]).catch({
                "useWorkflowWorkspace.useEffect": ()=>{
                    if (live) setRunFormError('Saved workflows unavailable. Check the local automation API.');
                }
            }["useWorkflowWorkspace.useEffect"]);
            return ({
                "useWorkflowWorkspace.useEffect": ()=>{
                    live = false;
                }
            })["useWorkflowWorkspace.useEffect"];
        }
    }["useWorkflowWorkspace.useEffect"], [
        setRunFormError
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWorkflowWorkspace.useEffect": ()=>{
            let live = true;
            setTemplatePlans([]);
            const controller = new AbortController();
            void fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`workflow-templates/${platform}`), {
                cache: 'no-store',
                signal: controller.signal
            }).then({
                "useWorkflowWorkspace.useEffect": async (result)=>{
                    if (!result.ok) throw Error('Template catalogue not available');
                    const plans = await result.json();
                    if (live) setTemplatePlans(plans);
                }
            }["useWorkflowWorkspace.useEffect"]).catch({
                "useWorkflowWorkspace.useEffect": ()=>{
                    if (live) setTemplatePlans([]);
                }
            }["useWorkflowWorkspace.useEffect"]);
            return ({
                "useWorkflowWorkspace.useEffect": ()=>{
                    live = false;
                    controller.abort();
                }
            })["useWorkflowWorkspace.useEffect"];
        }
    }["useWorkflowWorkspace.useEffect"], [
        platform
    ]);
    async function saveWorkflowPlan() {
        if (busy) throw Error('Stop the active workflow before saving');
        if (loadingWorkflow) throw Error('Wait until the selected workflow finishes loading');
        if (planSaving) throw Error('A workflow save is already running');
        const selection = workflowSelectionEpoch.current;
        setPlanSaving(true);
        try {
            const value = {
                ...workflowPlan,
                parameters: {
                    ...form
                }
            };
            const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(activeWorkflow ? `workflows/${activeWorkflow.id}` : 'workflows'), {
                method: activeWorkflow ? 'PUT' : 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify(activeWorkflow ? {
                    plan: value,
                    expectedRevision: activeWorkflow.revision
                } : {
                    plan: value
                })
            });
            const json = await response.json();
            if (!response.ok) throw Error(json.error ?? 'Could not save workflow');
            savedListEpoch.current++;
            setSavedWorkflows((previous)=>[
                    ...previous.filter((item)=>item.id !== json.id),
                    json
                ]);
            if (selection === workflowSelectionEpoch.current) {
                setWorkspaceOpen(true);
                setActiveWorkflow(json);
                setWorkflowPlan(json.plan);
                setPlanDirty(false);
                setRunFormError('');
            }
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Workflow save failed';
            setRunFormError(message);
            throw Error(message);
        } finally{
            setPlanSaving(false);
        }
    }
    async function applyGrowthTemplate(id) {
        if (busy) throw Error('Stop the current Runner workflow before loading a Growth template');
        if (platform !== 'linkedin') throw Error('Growth template requires LinkedIn');
        const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`growth/templates/${encodeURIComponent(id)}`), {
            cache: 'no-store'
        });
        const program = await response.json();
        if (!response.ok || program.id !== id || !Array.isArray(program.stages) || program.stages.length === 0) throw Error(program.error || 'Growth YAML did not compile into a connected pipeline graph');
        setSelectedGrowthTemplateId(id);
        setWorkspaceOpen(true);
    }
    async function applyTemplate(plan, templateId) {
        setSelectedGrowthTemplateId(null);
        if (busy) throw Error('Stop or finish the active workflow before changing templates');
        if (plan.platform !== platform) throw Error('Select the matching studio account before applying this template');
        if (planSaving) throw Error('A workflow save is already running');
        const selection = ++workflowSelectionEpoch.current;
        setPlanSaving(true);
        setRunFormError('');
        try {
            const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])('workflows'), {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    plan,
                    templateId
                })
            });
            const saved = await response.json();
            if (!response.ok) throw Error(saved.error || 'The selected workflow could not be saved');
            savedListEpoch.current++;
            setSavedWorkflows((previous)=>[
                    ...previous.filter((item)=>item.id !== saved.id),
                    saved
                ]);
            if (selection === workflowSelectionEpoch.current) {
                setWorkspaceOpen(true);
                setAction(saved.plan.action);
                setActiveWorkflow(saved);
                setWorkflowPlan(saved.plan);
                setForm(saved.plan.parameters ?? {});
                setPlanDirty(false);
                setLoadingWorkflow(false);
            }
        } finally{
            setPlanSaving(false);
        }
    }
    async function openActionWorkflow(nextAction, parameters = {}) {
        if (busy) throw Error('Stop the active workflow before changing actions');
        if (planSaving) throw Error('Wait for the current workflow to finish saving');
        if (workspaceOpen && !selectedGrowthTemplateId && (planDirty || formDirty)) throw Error('Save or discard the current workflow edits first');
        const selection = ++workflowSelectionEpoch.current;
        setLoadingWorkflow(true);
        setRunFormError('');
        try {
            const response = await fetch((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApi"])(`workflow-plans/${platform}/${encodeURIComponent(nextAction)}`), {
                cache: 'no-store'
            });
            const result = await response.json();
            if (!response.ok || result.platform !== platform || result.action !== nextAction || !Array.isArray(result.steps)) throw Error(result.error || 'The selected action workflow is unavailable');
            if (selection !== workflowSelectionEpoch.current) return;
            setSelectedGrowthTemplateId(null);
            setActiveWorkflow(null);
            setAction(nextAction);
            setWorkflowPlan(result);
            setForm({
                ...result.parameters ?? {},
                ...parameters
            });
            setPlanDirty(Object.keys(parameters).length > 0);
            setWorkspaceOpen(true);
        } catch (cause) {
            const message = cause instanceof Error ? cause.message : 'Could not open the action workflow';
            if (selection === workflowSelectionEpoch.current) setRunFormError(message);
            throw Error(message);
        } finally{
            if (selection === workflowSelectionEpoch.current) setLoadingWorkflow(false);
        }
    }
    function beginNewWorkflow() {
        if (busy || planSaving) return;
        workflowSelectionEpoch.current++;
        setSelectedGrowthTemplateId(null);
        setActiveWorkflow(null);
        const draft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$pipeline$2f$default$2d$workflow$2d$plan$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newWorkflowDraft"])(platform);
        setAction(draft.action);
        setWorkflowPlan(draft);
        setForm({});
        setPlanDirty(true);
        setRunFormError('');
        setLoadingWorkflow(false);
        setWorkspaceOpen(true);
    }
    function closeWorkspace() {
        if (busy) return;
        workflowSelectionEpoch.current++;
        setSelectedGrowthTemplateId(null);
        setActiveWorkflow(null);
        setPlanDirty(false);
        setRunFormError('');
        setWorkspaceOpen(false);
    }
    function selectSavedWorkflow(id) {
        setSelectedGrowthTemplateId(null);
        workflowSelectionEpoch.current++;
        if (id === null) {
            setWorkspaceOpen(false);
            setActiveWorkflow(null);
            setPlanDirty(false);
            setRunFormError('');
            return;
        }
        const selected = savedWorkflows.find((item)=>item.id === id);
        if (!selected) return;
        setWorkspaceOpen(true);
        setLoadingWorkflow(false);
        setActiveWorkflow(selected);
        setPlatform(selected.plan.platform);
        setAction(selected.plan.action);
        setWorkflowPlan(selected.plan);
        setForm(selected.plan.parameters ?? {});
        setPlanDirty(false);
        setRunFormError('');
    }
    const invalidateWorkflowSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkflowWorkspace.useCallback[invalidateWorkflowSelection]": ()=>{
            workflowSelectionEpoch.current++;
        }
    }["useWorkflowWorkspace.useCallback[invalidateWorkflowSelection]"], []);
    return {
        platform,
        setPlatform,
        handle,
        setHandle,
        action,
        setAction,
        form,
        setForm,
        workflowPlan,
        setWorkflowPlan,
        templatePlans,
        selectedGrowthTemplateId,
        setSelectedGrowthTemplateId,
        savedWorkflows,
        activeWorkflow,
        setActiveWorkflow,
        workspaceOpen,
        setWorkspaceOpen,
        beginNewWorkflow,
        openActionWorkflow,
        closeWorkspace,
        loadingWorkflow,
        planDirty,
        setPlanDirty,
        planSaving,
        formDirty,
        saveWorkflowPlan,
        applyGrowthTemplate,
        applyTemplate,
        selectSavedWorkflow,
        invalidateWorkflowSelection
    };
}
_s(useWorkflowWorkspace, "Xq4LGVHu5h6nrg2n5BO/Fbzjv9g=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_components_dashboard_pipeline_0pmy..m._.js.map