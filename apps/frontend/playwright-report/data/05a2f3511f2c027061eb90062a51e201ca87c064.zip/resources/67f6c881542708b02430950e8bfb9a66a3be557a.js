(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accountSection",
    ()=>accountSection,
    "choiceLabel",
    ()=>choiceLabel,
    "portraitSrc",
    ()=>portraitSrc,
    "senseCopy",
    ()=>senseCopy,
    "statusLine",
    ()=>statusLine,
    "workFor",
    ()=>workFor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/linkedin-growth-capabilities.ts [app-client] (ecmascript)");
;
const senseCopy = {
    chat: {
        title: 'Writing',
        hint: 'How Mator writes when you talk with it.'
    },
    vision: {
        title: 'Pictures',
        hint: 'How Mator understands images you attach.'
    },
    'speech-to-text': {
        title: 'Listening',
        hint: 'How Mator hears you when you speak.'
    },
    'text-to-speech': {
        title: 'Speaking',
        hint: 'The voice Mator uses when it talks back.'
    },
    moderation: {
        title: 'Review',
        hint: 'How Mator checks a message before preparing a step.'
    }
};
function accountSection(pathname, pane) {
    if (pane === 'settings' || pathname === '/dashboard/settings') return 'mator';
    if (pathname.endsWith('/connections')) return 'connections';
    return 'you';
}
function workFor(ids) {
    return ids.map((id)=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthCapabilities"].find((item)=>item.id === id)?.title).filter((title)=>Boolean(title));
}
function choiceLabel(model) {
    const tier = model.tier === 'free' ? 'Free' : 'Paid';
    const friendly = {
        'openai/gpt-oss-20b': 'Everyday writing',
        'openai/gpt-oss-120b': 'Deeper writing',
        'qwen/qwen3.8-27b': 'Picture understanding',
        'whisper-large-v3-turbo': 'Quick listening',
        'whisper-large-v3': 'Careful listening',
        'canopylabs/orpheus-v1-english': 'Spoken replies'
    };
    return `${friendly[model.id] ?? model.label} — ${tier}`;
}
function portraitSrc(value) {
    if (!value) return undefined;
    const lower = value.toLowerCase();
    if (lower.includes('displaybackground') || lower.includes('backgroundimage')) return undefined;
    return value;
}
function statusLine(status) {
    if (status === 'connected') return 'Connected';
    if (status === 'sign-in-open') return 'Finishing sign-in';
    if (status === 'api-required') return 'Waiting on official access';
    return 'Not connected';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/account-notice.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Notice",
    ()=>Notice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function Notice({ tone, children, onDismiss }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: tone === 'warn' ? 'alert' : 'status',
        className: 'flex items-start justify-between gap-4 rounded-2xl px-5 py-4 text-sm leading-6 ' + (tone === 'warn' ? 'border border-rose-200 bg-rose-50 text-rose-900' : 'border border-teal-200 bg-teal-50 text-teal-950'),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: children
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-notice.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onDismiss,
                className: "min-h-11 shrink-0 cursor-pointer rounded-lg px-3 font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                children: "Dismiss"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-notice.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/account-notice.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Notice;
var _c;
__turbopack_context__.k.register(_c, "Notice");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DisconnectNetworkDialog",
    ()=>DisconnectNetworkDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
'use client';
;
;
function DisconnectNetworkDialog({ account, linkBusy, onDismiss, onConfirm }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: Boolean(account),
        title: "Disconnect this network?",
        description: account ? `${account.label} will be signed out here. You can connect it again later.` : undefined,
        onDismiss: ()=>!linkBusy && onDismiss(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-wrap justify-end gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    disabled: Boolean(linkBusy),
                    onClick: onDismiss,
                    className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl px-4 text-sm font-semibold text-slate-700 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                    children: "Stay connected"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    disabled: Boolean(linkBusy) || !account,
                    onClick: onConfirm,
                    className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-rose-700 px-4 text-sm font-semibold text-white hover:bg-rose-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-700 disabled:opacity-50",
                    children: linkBusy ? 'Disconnecting…' : 'Disconnect'
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = DisconnectNetworkDialog;
var _c;
__turbopack_context__.k.register(_c, "DisconnectNetworkDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProfileEditorDialog",
    ()=>ProfileEditorDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
'use client';
;
;
function ProfileEditorDialog({ open, draft, saving, onDismiss, onDraftChange, onSubmit }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: open,
        title: "Edit personal details",
        description: "This is how you appear inside Utomator.",
        onDismiss: ()=>!saving && onDismiss(),
        testId: "account-profile-dialog",
        children: draft ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: "flex flex-col gap-5",
            onSubmit: (event)=>{
                event.preventDefault();
                onSubmit();
            },
            children: [
                [
                    [
                        'displayName',
                        'Display name',
                        'text',
                        150
                    ],
                    [
                        'email',
                        'Email',
                        'email',
                        180
                    ],
                    [
                        'location',
                        'Location',
                        'text',
                        180
                    ]
                ].map(([key, label, type, max])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-slate-800",
                        children: [
                            label,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                required: key === 'displayName',
                                type: type,
                                autoComplete: key === 'email' ? 'email' : 'off',
                                maxLength: max,
                                value: draft[key],
                                onChange: (event)=>onDraftChange((current)=>current && {
                                            ...current,
                                            [key]: event.target.value
                                        }),
                                className: "mt-2 block min-h-11 w-full rounded-xl border border-slate-200 px-3 text-base font-normal text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this)
                        ]
                    }, key, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                        lineNumber: 58,
                        columnNumber: 13
                    }, this)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-slate-800",
                    children: [
                        "About",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            rows: 4,
                            maxLength: 1200,
                            value: draft.about,
                            onChange: (event)=>onDraftChange((current)=>current && {
                                        ...current,
                                        about: event.target.value
                                    }),
                            className: "mt-2 block w-full resize-y rounded-xl border border-slate-200 px-3 py-3 text-base leading-7 font-normal text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: saving,
                            onClick: onDismiss,
                            className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl px-4 text-sm font-semibold text-slate-700 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                            lineNumber: 95,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            disabled: saving,
                            className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-teal-700 px-4 text-sm font-semibold text-white hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:opacity-50",
                            children: saving ? 'Saving…' : 'Save details'
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                            lineNumber: 103,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
                    lineNumber: 94,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
            lineNumber: 44,
            columnNumber: 9
        }, this) : null
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = ProfileEditorDialog;
var _c;
__turbopack_context__.k.register(_c, "ProfileEditorDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProfilePlanDialog",
    ()=>ProfilePlanDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/linkedin-growth-capabilities.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function ProfilePlanDialog({ open, onDismiss }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: open,
        title: "Improve my profile",
        description: "A prioritized, evidence-backed section revision plan and a measured follow-up.",
        onDismiss: onDismiss,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "grid gap-2 sm:grid-cols-2",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["workFor"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthJourneys"][0].sequence).map((step)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "text-sm font-medium text-[#111a25]",
                        children: step
                    }, step, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx",
                        lineNumber: 26,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "mt-4 grid gap-x-6 gap-y-1 border-t border-slate-100 pt-4 sm:grid-cols-2",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["profileSections"].map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "text-sm leading-7 text-slate-600",
                        children: section
                    }, section, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = ProfilePlanDialog;
var _c;
__turbopack_context__.k.register(_c, "ProfilePlanDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemoveAccountDialog",
    ()=>RemoveAccountDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
'use client';
;
;
function RemoveAccountDialog({ account, saving, onDismiss, onConfirm }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: Boolean(account),
        title: "Remove this account?",
        description: account ? `${account.label} will be forgotten here. You can connect it again later.` : undefined,
        onDismiss: ()=>!saving && onDismiss(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-wrap justify-end gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    disabled: saving,
                    onClick: onDismiss,
                    className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl px-4 text-sm font-semibold text-slate-700 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                    children: "Keep account"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    disabled: saving || !account,
                    onClick: onConfirm,
                    className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-rose-700 px-4 text-sm font-semibold text-white hover:bg-rose-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-700 disabled:opacity-50",
                    children: saving ? 'Removing…' : 'Remove account'
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = RemoveAccountDialog;
var _c;
__turbopack_context__.k.register(_c, "RemoveAccountDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccountSectionNav",
    ()=>AccountSectionNav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sliders$2d$horizontal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SlidersHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/sliders-horizontal.mjs [app-client] (ecmascript) <export default as SlidersHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/sparkles.mjs [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/user-round.mjs [app-client] (ecmascript) <export default as UserRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waypoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Waypoints$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/waypoints.mjs [app-client] (ecmascript) <export default as Waypoints>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
function AccountSectionNav({ section, profile, socialAccounts, linkedCount, initial, onOpenSection }) {
    const menu = [
        {
            id: 'you',
            label: 'Profile',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__["UserRound"]
        },
        {
            id: 'connections',
            label: 'Networks',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waypoints$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Waypoints$3e$__["Waypoints"]
        },
        {
            id: 'mator',
            label: 'Mator',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"]
        },
        {
            id: 'preferences',
            label: 'Preferences',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sliders$2d$horizontal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SlidersHorizontal$3e$__["SlidersHorizontal"]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: "rounded-3xl bg-white p-4 shadow-[0_20px_50px_-36px_rgba(17,26,37,0.45)] lg:sticky lg:top-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 px-2 py-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex size-12 items-center justify-center overflow-hidden rounded-2xl bg-[#111a25] font-serif text-xl text-white",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(profile?.avatarUrl) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(socialAccounts.find((row)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(row.avatarUrl))?.avatarUrl) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            unoptimized: true,
                            src: ((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(profile?.avatarUrl) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(socialAccounts.find((row)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(row.avatarUrl))?.avatarUrl)) ?? '',
                            alt: "",
                            width: 48,
                            height: 48,
                            className: "size-12 rounded-2xl object-cover"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                            lineNumber: 53,
                            columnNumber: 13
                        }, this) : initial
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "truncate text-sm font-semibold text-[#111a25]",
                                children: profile?.displayName || 'Account'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-slate-500",
                                children: [
                                    linkedCount,
                                    " linked"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                        lineNumber: 72,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                "aria-label": "Account",
                className: "mt-3 grid grid-cols-2 gap-1 lg:grid-cols-1",
                children: menu.map((item)=>{
                    const active = section === item.id;
                    const Icon = item.icon;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "aria-current": active ? 'page' : undefined,
                        onClick: ()=>onOpenSection(item.id),
                        className: 'flex min-h-11 cursor-pointer items-center gap-2 rounded-xl px-3 text-left text-sm font-semibold transition duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 motion-reduce:transition-none ' + (active ? 'bg-[#111a25] text-white' : 'text-slate-700 hover:bg-slate-50'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "size-4 shrink-0",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                                lineNumber: 99,
                                columnNumber: 15
                            }, this),
                            item.label
                        ]
                    }, item.id, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                        lineNumber: 87,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_c = AccountSectionNav;
var _c;
__turbopack_context__.k.register(_c, "AccountSectionNav");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/account-hint.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Hint",
    ()=>Hint
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/info.mjs [app-client] (ecmascript) <export default as Info>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Hint({ label, children }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const panelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Hint.useEffect": ()=>{
            if (!open) return;
            const close = {
                "Hint.useEffect.close": (event)=>{
                    if (!ref.current?.contains(event.target)) setOpen(false);
                }
            }["Hint.useEffect.close"];
            const onKey = {
                "Hint.useEffect.onKey": (event)=>{
                    if (event.key === 'Escape') setOpen(false);
                }
            }["Hint.useEffect.onKey"];
            document.addEventListener('mousedown', close);
            document.addEventListener('keydown', onKey);
            return ({
                "Hint.useEffect": ()=>{
                    document.removeEventListener('mousedown', close);
                    document.removeEventListener('keydown', onKey);
                }
            })["Hint.useEffect"];
        }
    }["Hint.useEffect"], [
        open
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-expanded": open,
                "aria-controls": panelId,
                "aria-label": label,
                onClick: ()=>setOpen((value)=>!value),
                className: "inline-flex size-11 cursor-pointer items-center justify-center rounded-full text-current/80 transition duration-200 hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-300 motion-reduce:transition-none",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__["Info"], {
                    className: "size-4",
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/account-hint.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-hint.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                id: panelId,
                role: "note",
                className: "absolute top-12 right-0 z-20 w-[min(18rem,calc(100vw-3rem))] rounded-2xl border border-slate-200 bg-white p-4 text-sm leading-6 text-slate-700 shadow-xl",
                children: children
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-hint.tsx",
                lineNumber: 40,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/account-hint.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_s(Hint, "NMOytWcCio0ndR02J+WfzRaxySc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Hint;
var _c;
__turbopack_context__.k.register(_c, "Hint");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MatorAccountSection",
    ()=>MatorAccountSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$audio$2d$lines$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AudioLines$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/audio-lines.mjs [app-client] (ecmascript) <export default as AudioLines>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/eye.mjs [app-client] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/eye-off.mjs [app-client] (ecmascript) <export default as EyeOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/image.mjs [app-client] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$key$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__KeyRound$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/key-round.mjs [app-client] (ecmascript) <export default as KeyRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquareText$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/message-square-text.mjs [app-client] (ecmascript) <export default as MessageSquareText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/sparkles.mjs [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$hint$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-hint.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$notice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-notice.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/ui/studio-dialog.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function MatorAccountSection({ matorLoading, mator, models, voices, matorError, matorBusy, keyDraft, keyVisible, editingKey, confirmClearKey, keyInputRef, onDismissMatorError, onKeyDraftChange, onSetKeyVisible, onEditingKeyChange, onConfirmClearKeyChange, onPatchMator }) {
    _s();
    const keyReady = Boolean(mator?.groqKeyConfigured);
    const showKeyEditor = editingKey || !keyReady;
    const keyStatus = mator?.keySource === 'environment' ? 'Environment key' : keyReady ? 'Saved key' : 'Not configured';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MatorAccountSection.useEffect": ()=>{
            if (editingKey) keyInputRef.current?.focus();
        }
    }["MatorAccountSection.useEffect"], [
        editingKey,
        keyInputRef
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                "aria-labelledby": "account-mator-heading",
                "data-testid": "mator-settings-card",
                className: "flex flex-col gap-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                id: "account-mator-heading",
                                className: "font-serif text-3xl tracking-tight text-[#111a25]",
                                children: "Mator"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 87,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-3 max-w-xl text-base leading-7 text-slate-600",
                                children: "Your key lets Mator write, listen, and look at pictures with you. It stays private after you save it."
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    matorLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-48 animate-pulse rounded-3xl bg-[#111a25]/10 motion-reduce:animate-none"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-3xl bg-[#111a25] px-6 py-7 text-white sm:px-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-start justify-between gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$key$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__KeyRound$3e$__["KeyRound"], {
                                                className: "size-5 text-teal-200",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 105,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-lg font-semibold",
                                                children: "API key"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 106,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 104,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$hint$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hint"], {
                                        label: "About your API key",
                                        children: "After you save a key, Utomator keeps it private and will not show it again. Edit replaces it. Remove deletes it from this account."
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 108,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 103,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-testid": "mator-key-status",
                                className: "mt-4 inline-flex min-h-8 items-center rounded-full bg-white/10 px-3 text-xs font-semibold tracking-wide text-teal-100",
                                children: keyStatus
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-3 max-w-lg text-sm leading-6 text-slate-300",
                                children: mator?.keySource === 'environment' ? 'This computer already has a key. Save your own if you want Mator to use a different one.' : keyReady ? 'A key is saved. Edit it whenever you want to replace it.' : 'Paste a key to turn Mator on for this account.'
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            showKeyEditor ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "mator-api-key",
                                        className: "text-sm font-semibold text-white",
                                        children: "API key"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 130,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-2 flex items-center gap-2 rounded-2xl bg-white p-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "mator-api-key",
                                                ref: keyInputRef,
                                                type: keyVisible ? 'text' : 'password',
                                                autoComplete: "off",
                                                spellCheck: false,
                                                value: keyDraft,
                                                disabled: matorBusy,
                                                placeholder: keyReady ? 'Type a new key' : 'Paste your API key',
                                                onChange: (event)=>onKeyDraftChange(event.target.value),
                                                className: "min-h-11 min-w-0 flex-1 bg-transparent px-3 text-base text-slate-900 outline-none placeholder:text-slate-400"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 137,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                "aria-label": keyVisible ? 'Hide API key' : 'Show API key',
                                                onClick: ()=>onSetKeyVisible(!keyVisible),
                                                className: "inline-flex size-11 cursor-pointer items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-teal-700",
                                                children: keyVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__["EyeOff"], {
                                                    className: "size-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                    lineNumber: 158,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                    className: "size-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                    lineNumber: 160,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 136,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4 flex flex-wrap gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: matorBusy || !keyDraft.trim(),
                                                onClick: ()=>void onPatchMator({
                                                        groqApiKey: keyDraft.trim()
                                                    }, {
                                                        clearDraft: true,
                                                        saved: 'API key saved.'
                                                    }),
                                                className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-teal-500 px-4 text-sm font-semibold text-[#111a25] transition duration-200 hover:bg-teal-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white disabled:cursor-not-allowed disabled:opacity-40 motion-reduce:transition-none",
                                                children: matorBusy ? 'Saving…' : 'Save key'
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 165,
                                                columnNumber: 19
                                            }, this),
                                            keyReady ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: matorBusy,
                                                onClick: ()=>{
                                                    onEditingKeyChange(false);
                                                    onKeyDraftChange('');
                                                    onSetKeyVisible(false);
                                                },
                                                className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl px-4 text-sm font-semibold text-white hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white",
                                                children: "Cancel"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 179,
                                                columnNumber: 21
                                            }, this) : null
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 164,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 129,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6 flex flex-wrap items-center justify-between gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-mono text-lg tracking-[0.35em] text-slate-200",
                                        "aria-hidden": "true",
                                        children: "•••• •••• ••••"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 196,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>onEditingKeyChange(true),
                                                className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-white px-4 text-sm font-semibold text-[#111a25] hover:bg-teal-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white",
                                                children: "Edit key"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 203,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>onConfirmClearKeyChange(true),
                                                className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl border border-rose-300/60 px-4 text-sm font-semibold text-rose-100 hover:bg-rose-500/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white",
                                                children: "Remove key"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 210,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 202,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                        lineNumber: 102,
                        columnNumber: 11
                    }, this),
                    matorError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$notice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Notice"], {
                        tone: "warn",
                        onDismiss: onDismissMatorError,
                        children: matorError
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                        lineNumber: 224,
                        columnNumber: 11
                    }, this) : null,
                    mator ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "font-serif text-2xl text-[#111a25]",
                                        children: "How Mator shows up"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 232,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 max-w-xl text-sm leading-6 text-slate-600",
                                        children: "Pick the style of help you want. You can change these any time."
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 235,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this),
                            [
                                [
                                    'chat',
                                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2d$text$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquareText$3e$__["MessageSquareText"],
                                    mator.modelId,
                                    'modelId'
                                ],
                                [
                                    'vision',
                                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"],
                                    mator.visionModelId,
                                    'visionModelId'
                                ],
                                [
                                    'speech-to-text',
                                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$audio$2d$lines$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AudioLines$3e$__["AudioLines"],
                                    mator.sttModelId,
                                    'sttModelId'
                                ],
                                [
                                    'text-to-speech',
                                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"],
                                    mator.ttsModelId,
                                    'ttsModelId'
                                ]
                            ].map(([role, Icon, value, field])=>{
                                const copy = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["senseCopy"][role];
                                const options = models.filter((model)=>model.role === role);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block border-t border-slate-200 pt-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-2 text-base font-semibold text-[#111a25]",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                    className: "size-4 text-teal-800",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                    lineNumber: 255,
                                                    columnNumber: 21
                                                }, this),
                                                copy.title
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                            lineNumber: 254,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mt-1 block text-sm leading-6 text-slate-600",
                                            children: copy.hint
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                            lineNumber: 258,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            "data-testid": `mator-model-${role}`,
                                            value: value,
                                            disabled: matorBusy || options.length === 0,
                                            onChange: (event)=>void onPatchMator({
                                                    [field]: event.target.value
                                                }),
                                            className: "mt-3 min-h-11 w-full cursor-pointer rounded-xl border border-slate-200 bg-white px-3 text-base text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-50",
                                            children: options.map((model)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: model.id,
                                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["choiceLabel"])(model)
                                                }, model.id, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                    lineNumber: 271,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                            lineNumber: 261,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, role, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                    lineNumber: 250,
                                    columnNumber: 17
                                }, this);
                            }),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block border-t border-slate-200 pt-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-base font-semibold text-[#111a25]",
                                        children: "Care"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 280,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mt-1 block text-sm leading-6 text-slate-600",
                                        children: "Quick is faster. Thorough takes a little longer and thinks further."
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 283,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        "data-testid": "mator-reasoning-effort",
                                        value: mator.reasoningEffort,
                                        disabled: matorBusy,
                                        onChange: (event)=>void onPatchMator({
                                                reasoningEffort: event.target.value
                                            }),
                                        className: "mt-3 min-h-11 w-full cursor-pointer rounded-xl border border-slate-200 bg-white px-3 text-base text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "low",
                                                children: "Quick"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 299,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "medium",
                                                children: "Balanced"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 300,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "high",
                                                children: "Thorough"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 301,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 287,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 279,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block border-t border-slate-200 pt-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-base font-semibold text-[#111a25]",
                                        children: "Speaking voice"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 305,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mt-1 block text-sm leading-6 text-slate-600",
                                        children: "The voice you hear when Mator reads a note aloud."
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 308,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        "data-testid": "mator-tts-voice",
                                        value: mator.ttsVoice,
                                        disabled: matorBusy,
                                        onChange: (event)=>void onPatchMator({
                                                ttsVoice: event.target.value
                                            }),
                                        className: "mt-3 min-h-11 w-full cursor-pointer rounded-xl border border-slate-200 bg-white px-3 text-base text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                        children: (voices.length ? voices : [
                                            {
                                                id: 'hannah',
                                                label: 'Hannah',
                                                language: 'English'
                                            },
                                            {
                                                id: 'troy',
                                                label: 'Troy',
                                                language: 'English'
                                            },
                                            {
                                                id: 'austin',
                                                label: 'Austin',
                                                language: 'English'
                                            }
                                        ]).map((voice)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: voice.id,
                                                children: [
                                                    voice.label,
                                                    " — ",
                                                    voice.language
                                                ]
                                            }, voice.id, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                                lineNumber: 336,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                        lineNumber: 311,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                                lineNumber: 304,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                        lineNumber: 230,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$ui$2f$studio$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: confirmClearKey,
                title: "Remove API key?",
                description: "Mator will not be able to reply until you save a key again.",
                onDismiss: ()=>!matorBusy && onConfirmClearKeyChange(false),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap justify-end gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: matorBusy,
                            onClick: ()=>onConfirmClearKeyChange(false),
                            className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl px-4 text-sm font-semibold text-slate-700 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                            children: "Keep key"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                            lineNumber: 353,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: matorBusy,
                            onClick: ()=>void onPatchMator({
                                    groqApiKey: null
                                }, {
                                    clearDraft: true,
                                    saved: 'API key removed.'
                                }),
                            className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-rose-700 px-4 text-sm font-semibold text-white hover:bg-rose-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-700 disabled:opacity-50",
                            children: matorBusy ? 'Removing…' : 'Remove key'
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                            lineNumber: 361,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                    lineNumber: 352,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx",
                lineNumber: 346,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(MatorAccountSection, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = MatorAccountSection;
var _c;
__turbopack_context__.k.register(_c, "MatorAccountSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NetworksSection",
    ()=>NetworksSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/connections/provider-meta.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const platforms = [
    'linkedin',
    'x',
    'instagram',
    'github',
    'devto'
];
function NetworksSection({ available, socialAccounts, connections, linkBusy, pendingSync, linkedAccountId, selectedAccount, onConnect, onOpenProviderTab, onBeginSync, onRequestDisconnect }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-labelledby": "account-networks-heading",
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "flex flex-wrap items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        id: "account-networks-heading",
                        className: "font-serif text-3xl tracking-tight text-[#111a25]",
                        children: "Networks"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onConnect,
                        className: "inline-flex min-h-11 cursor-pointer items-center rounded-xl bg-teal-700 px-4 text-sm font-semibold text-white transition duration-200 hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 motion-reduce:transition-none",
                        children: "Manage connections"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            available === 'offline' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                className: "rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4 text-sm leading-6 text-amber-950",
                children: "Utomator is not running on this computer, so live connection status may be out of date. Saved accounts are still listed."
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                lineNumber: 78,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "divide-y divide-slate-200 overflow-hidden rounded-3xl bg-white shadow-[0_20px_50px_-36px_rgba(17,26,37,0.45)]",
                children: platforms.map((platformKey)=>{
                    const meta = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["providerMeta"][platformKey];
                    const Icon = meta.icon;
                    const rows = socialAccounts?.filter((row)=>row.platform === platformKey) ?? [];
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "px-5 py-4",
                        children: rows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: 'flex size-11 shrink-0 items-center justify-center rounded-xl ' + meta.tile,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        className: "size-5!"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                        lineNumber: 102,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                    lineNumber: 96,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "min-w-0 flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-base font-semibold text-[#111a25]",
                                            children: meta.name
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                            lineNumber: 105,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-slate-500",
                                            children: "No verified account linked."
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                            lineNumber: 108,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                    lineNumber: 104,
                                    columnNumber: 19
                                }, this),
                                platformKey === 'linkedin' || platformKey === 'x' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: linkBusy === platformKey || linkBusy === pendingSync[platformKey],
                                    onClick: ()=>{
                                        onOpenProviderTab(platformKey);
                                        void onBeginSync(platformKey);
                                    },
                                    className: "inline-flex min-h-11 shrink-0 cursor-pointer items-center rounded-xl bg-[#111a25] px-4 text-sm font-semibold text-white hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                                    children: linkBusy === platformKey || linkBusy === pendingSync[platformKey] ? 'Working…' : 'Sync'
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                    lineNumber: 113,
                                    columnNumber: 21
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                            lineNumber: 95,
                            columnNumber: 17
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-3",
                            children: [
                                rows.map((row)=>{
                                    const live = connections.find((item)=>item.id === row.id);
                                    const inUse = linkedAccountId === row.id || selectedAccount?.platform === row.platform && selectedAccount.handle === row.handle;
                                    const disconnecting = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$connections$2f$provider$2d$meta$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["primaryOperation"])(live?.status ?? 'disconnected', live?.verifiedAt ?? null) === 'disconnect';
                                    const portrait = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["portraitSrc"])(row.avatarUrl);
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: 'flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-full ' + (portrait ? '' : meta.tile),
                                                children: portrait ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    unoptimized: true,
                                                    src: portrait,
                                                    alt: "",
                                                    width: 44,
                                                    height: 44,
                                                    className: "size-11 rounded-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                    lineNumber: 155,
                                                    columnNumber: 29
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                    className: "size-5!"
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                    lineNumber: 164,
                                                    columnNumber: 29
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                lineNumber: 148,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "min-w-0 flex-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex min-w-0 items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                                className: "truncate text-base font-semibold text-[#111a25]",
                                                                children: meta.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                                lineNumber: 169,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "shrink-0 rounded-full bg-teal-50 px-2 py-0.5 text-xs font-semibold text-teal-900",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusLine"])(live?.status)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                                lineNumber: 172,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "truncate text-sm text-slate-500",
                                                        children: [
                                                            "@",
                                                            row.handle,
                                                            inUse ? ' · In use' : ''
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                        lineNumber: 176,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                lineNumber: 167,
                                                columnNumber: 25
                                            }, this),
                                            row.platform === 'linkedin' || row.platform === 'x' ? disconnecting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: linkBusy === row.id,
                                                onClick: ()=>onRequestDisconnect(row.id),
                                                className: "inline-flex min-h-11 shrink-0 cursor-pointer items-center rounded-xl border border-slate-200 px-4 text-sm font-semibold text-slate-800 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                                                children: linkBusy === row.id ? 'Working…' : 'Disconnect'
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                lineNumber: 183,
                                                columnNumber: 29
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: linkBusy === row.id,
                                                onClick: ()=>{
                                                    onOpenProviderTab(row.platform);
                                                    void onBeginSync(row.platform, row.id);
                                                },
                                                className: "inline-flex min-h-11 shrink-0 cursor-pointer items-center rounded-xl bg-[#111a25] px-4 text-sm font-semibold text-white hover:bg-teal-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                                                children: linkBusy === row.id ? 'Working…' : 'Sync'
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                                lineNumber: 192,
                                                columnNumber: 29
                                            }, this) : null
                                        ]
                                    }, row.id, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                        lineNumber: 147,
                                        columnNumber: 23
                                    }, this);
                                }),
                                rows.length > 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "alert",
                                    className: "text-sm leading-6 text-amber-900",
                                    children: "More than one account is saved here. Remove the extra one before connecting another."
                                }, void 0, false, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                                    lineNumber: 214,
                                    columnNumber: 21
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                            lineNumber: 133,
                            columnNumber: 17
                        }, this)
                    }, platformKey, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                        lineNumber: 93,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_c = NetworksSection;
var _c;
__turbopack_context__.k.register(_c, "NetworksSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SwitchRow",
    ()=>SwitchRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function SwitchRow({ checked, disabled, label, hint, testId, onChange }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between gap-6 border-b border-slate-200 py-6 last:border-b-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-base font-semibold text-[#111a25]",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                        lineNumber: 21,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 max-w-md text-sm leading-6 text-slate-600",
                        children: hint
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                role: "switch",
                "aria-checked": checked,
                "aria-label": label,
                "data-testid": testId,
                disabled: disabled,
                onClick: ()=>onChange(!checked),
                className: "inline-flex min-h-11 min-w-16 cursor-pointer items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 disabled:cursor-not-allowed disabled:opacity-40",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: 'inline-flex h-8 w-14 items-center rounded-full p-1 transition duration-200 motion-reduce:transition-none ' + (checked ? 'bg-teal-700' : 'bg-slate-300'),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: 'size-6 rounded-full bg-white shadow transition duration-200 motion-reduce:transition-none ' + (checked ? 'translate-x-6' : 'translate-x-0')
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = SwitchRow;
var _c;
__turbopack_context__.k.register(_c, "SwitchRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PreferencesSection",
    ()=>PreferencesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/log-out.mjs [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$switch$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-switch-row.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function PreferencesSection({ mator, matorBusy, hosted, onPatchMator }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-labelledby": "account-preferences-heading",
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        id: "account-preferences-heading",
                        className: "font-serif text-3xl tracking-tight text-[#111a25]",
                        children: "Preferences"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-3 max-w-xl text-base leading-7 text-slate-600",
                        children: "Choose how much Mator does on its own, and how it talks with you."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-3xl bg-white px-6 shadow-[0_20px_50px_-36px_rgba(17,26,37,0.45)] sm:px-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$switch$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwitchRow"], {
                        label: "Ask before changes",
                        hint: "Mator shows a change and waits. Turn this off to let those changes apply right away.",
                        checked: !(mator?.autoApprove ?? false),
                        disabled: matorBusy || !mator,
                        onChange: (ask)=>void onPatchMator({
                                autoApprove: !ask
                            })
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$switch$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwitchRow"], {
                        label: "Keep older chats short",
                        hint: "Mator sets aside earlier messages so a long conversation stays easy to follow.",
                        checked: mator?.squashPipelineHistory ?? false,
                        disabled: matorBusy || !mator,
                        onChange: (value)=>void onPatchMator({
                                squashPipelineHistory: value
                            })
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$switch$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwitchRow"], {
                        label: "Read notes aloud",
                        hint: "Mator speaks short explanations while you work together.",
                        checked: mator?.howTtsEnabled ?? true,
                        disabled: matorBusy || !mator,
                        onChange: (value)=>void onPatchMator({
                                howTtsEnabled: value
                            })
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$switch$2d$row$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwitchRow"], {
                        label: "Check messages first",
                        hint: "Mator reviews what you send before it prepares the next step.",
                        testId: "mator-moderation-toggle",
                        checked: mator?.moderationEnabled ?? false,
                        disabled: matorBusy || !mator,
                        onChange: (value)=>void onPatchMator({
                                moderationEnabled: value
                            })
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            hosted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                method: "post",
                action: "/auth/logout",
                className: "border-t border-slate-200 pt-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-base font-semibold text-[#111a25]",
                        children: "Sign out"
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 max-w-md text-sm leading-6 text-slate-600",
                        children: "This signs you out of Utomator. Your linked networks stay as they are."
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 77,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "mt-4 inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-xl border border-slate-300 px-4 text-sm font-semibold text-slate-800 hover:bg-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                className: "size-4",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                                lineNumber: 85,
                                columnNumber: 13
                            }, this),
                            "Sign out"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_c = PreferencesSection;
var _c;
__turbopack_context__.k.register(_c, "PreferencesSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProfileSection",
    ()=>ProfileSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/briefcase.mjs [app-client] (ecmascript) <export default as Briefcase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$building$2d$complex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Building2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/building-complex.mjs [app-client] (ecmascript) <export default as Building2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$messages$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessagesSquare$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/messages-square.mjs [app-client] (ecmascript) <export default as MessagesSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/pencil.mjs [app-client] (ecmascript) <export default as Pencil>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/user-round.mjs [app-client] (ecmascript) <export default as UserRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@1.61.0_@types+react@19.2.14_react@19.2.4/node_modules/lucide-react/dist/esm/icons/users.mjs [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/growth/linkedin-growth-capabilities.ts [app-client] (ecmascript)");
'use client';
;
;
;
const journeyIcon = {
    profile: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__["UserRound"],
    audience: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
    job: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__["Briefcase"],
    company: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$building$2d$complex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Building2$3e$__["Building2"],
    relationships: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$messages$2d$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessagesSquare$3e$__["MessagesSquare"]
};
function ProfileSection({ dataLoaded, profile, onEdit, onRunAim }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-labelledby": "account-you-heading",
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                id: "account-you-heading",
                className: "font-serif text-3xl tracking-tight text-[#111a25]",
                children: "Profile"
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-hidden rounded-3xl bg-white shadow-[0_20px_50px_-36px_rgba(17,26,37,0.45)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4",
                        children: !dataLoaded || !profile ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-10 flex-1 animate-pulse rounded-lg bg-slate-100 motion-reduce:animate-none"
                        }, void 0, false, {
                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                            lineNumber: 60,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "truncate text-base font-semibold text-[#111a25]",
                                            children: profile.displayName || 'Name not added'
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                            lineNumber: 64,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-0.5 truncate text-sm text-slate-500",
                                            children: [
                                                profile.headline,
                                                profile.email,
                                                profile.location
                                            ].filter(Boolean).join(' · ') || 'Add email and location'
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                            lineNumber: 67,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                    lineNumber: 63,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: onEdit,
                                    className: "inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-xl border border-slate-200 px-4 text-sm font-semibold text-slate-800 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                            className: "size-4",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                            lineNumber: 78,
                                            columnNumber: 17
                                        }, this),
                                        "Edit"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                    lineNumber: 73,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    profile && [
                        profile.about,
                        profile.website,
                        profile.skills,
                        profile.experience,
                        profile.education
                    ].some(Boolean) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                        className: "grid gap-4 border-b border-slate-100 px-5 py-4 sm:grid-cols-2",
                        children: [
                            [
                                'About',
                                profile.about
                            ],
                            [
                                'Website',
                                profile.website
                            ],
                            [
                                'Skills',
                                profile.skills
                            ],
                            [
                                'Experience',
                                profile.experience
                            ],
                            [
                                'Education',
                                profile.education
                            ]
                        ].filter(([, value])=>Boolean(value)).map(([label, value])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: label === 'About' || label === 'Experience' ? 'sm:col-span-2' : '',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                        className: "text-xs font-semibold tracking-wide text-slate-500 uppercase",
                                        children: label
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                        lineNumber: 112,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                        className: "mt-1 line-clamp-4 text-sm leading-6 text-[#111a25]",
                                        children: value
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                        lineNumber: 115,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, label, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                lineNumber: 104,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this) : null,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$growth$2f$linkedin$2d$growth$2d$capabilities$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["growthJourneys"].map((journey)=>{
                            const Icon = journeyIcon[journey.id];
                            const action = journey.id === 'profile' ? 'Review' : journey.id === 'job' ? 'Open career' : 'Open';
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "flex items-center gap-3 border-t border-slate-100 px-5 py-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex size-10 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-800",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                            className: "size-4",
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                        lineNumber: 136,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0 flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "truncate text-sm font-semibold text-[#111a25]",
                                                children: journey.title
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                                lineNumber: 140,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "truncate text-sm text-slate-500",
                                                children: journey.outcome
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                                lineNumber: 143,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                        lineNumber: 139,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>onRunAim(journey.id),
                                        className: "inline-flex min-h-11 shrink-0 cursor-pointer items-center gap-1 rounded-xl px-3 text-sm font-semibold text-teal-800 hover:bg-teal-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700",
                                        children: [
                                            action,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$1$2e$61$2e$0_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                className: "size-4",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                                lineNumber: 153,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                        lineNumber: 147,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, journey.id, true, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                                lineNumber: 132,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
_c = ProfileSection;
var _c;
__turbopack_context__.k.register(_c, "ProfileSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/frontend/components/dashboard/account/account-home.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AccountHome
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$notice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/account-notice.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$disconnect$2d$network$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/dialogs/disconnect-network-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$profile$2d$editor$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/dialogs/profile-editor-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$profile$2d$plan$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/dialogs/profile-plan-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$remove$2d$account$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/dialogs/remove-account-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$account$2d$section$2d$nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/sections/account-section-nav.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$mator$2d$account$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/sections/mator-account-section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$networks$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/sections/networks-section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$preferences$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/sections/preferences-section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$profile$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/dashboard/account/sections/profile-section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/frontend/components/mator/mator-api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const endpoint = '/api/account';
function AccountHome({ pathname, pane, available, selectedAccount, onNavigate, onConnect, linkedAccountId }) {
    _s();
    const routed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accountSection"])(pathname, pane);
    const [section, setSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(routed);
    const [planOpen, setPlanOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingProfile, setEditingProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [connections, setConnections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [removeId, setRemoveId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [disconnectId, setDisconnectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [linkBusy, setLinkBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pendingSync, setPendingSync] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [notice, setNotice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [hosted, setHosted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mator, setMator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [voices, setVoices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [matorLoading, setMatorLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [matorError, setMatorError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [matorBusy, setMatorBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [keyDraft, setKeyDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [keyVisible, setKeyVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editingKey, setEditingKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [confirmClearKey, setConfirmClearKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const keyInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            if (pane === 'settings' || pathname === '/dashboard/settings') {
                setSection({
                    "AccountHome.useEffect": (current)=>current === 'preferences' || current === 'mator' ? current : 'mator'
                }["AccountHome.useEffect"]);
                return;
            }
            setSection(pathname.endsWith('/connections') ? 'connections' : 'you');
        }
    }["AccountHome.useEffect"], [
        pathname,
        pane
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            if (!notice) return;
            const timer = window.setTimeout({
                "AccountHome.useEffect.timer": ()=>setNotice('')
            }["AccountHome.useEffect.timer"], 4000);
            return ({
                "AccountHome.useEffect": ()=>window.clearTimeout(timer)
            })["AccountHome.useEffect"];
        }
    }["AccountHome.useEffect"], [
        notice
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            if (/^(localhost|127\.0\.0\.1)$/.test(window.location.hostname)) return;
            let current = true;
            fetch('/auth/me', {
                cache: 'no-store'
            }).then({
                "AccountHome.useEffect": (response)=>{
                    if (current && response.ok) setHosted(true);
                }
            }["AccountHome.useEffect"]).catch({
                "AccountHome.useEffect": ()=>undefined
            }["AccountHome.useEffect"]);
            return ({
                "AccountHome.useEffect": ()=>{
                    current = false;
                }
            })["AccountHome.useEffect"];
        }
    }["AccountHome.useEffect"], []);
    const loadAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AccountHome.useCallback[loadAccount]": async ()=>{
            try {
                const response = await fetch(endpoint, {
                    cache: 'no-store'
                });
                const value = await response.json();
                if (!response.ok) throw Error(value.error || 'Account unavailable');
                setData(value);
                setError('');
            } catch (cause) {
                setError(cause instanceof Error ? cause.message : 'Account unavailable');
            }
        }
    }["AccountHome.useCallback[loadAccount]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            void loadAccount();
        }
    }["AccountHome.useEffect"], [
        loadAccount
    ]);
    const refreshConnections = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AccountHome.useCallback[refreshConnections]": async ()=>{
            const response = await fetch('/api/connectors', {
                cache: 'no-store'
            });
            if (!response.ok) return;
            const rows = await response.json();
            if (Array.isArray(rows)) setConnections(rows);
        }
    }["AccountHome.useCallback[refreshConnections]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            let alive = true;
            const check = {
                "AccountHome.useEffect.check": async ()=>{
                    try {
                        if (alive) await refreshConnections();
                    } catch  {
                    /* Saved accounts remain visible when live status cannot be checked. */ }
                }
            }["AccountHome.useEffect.check"];
            void check();
            const timer = window.setInterval({
                "AccountHome.useEffect.timer": ()=>void check()
            }["AccountHome.useEffect.timer"], 15000);
            return ({
                "AccountHome.useEffect": ()=>{
                    alive = false;
                    window.clearInterval(timer);
                }
            })["AccountHome.useEffect"];
        }
    }["AccountHome.useEffect"], [
        refreshConnections
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            const pending = Object.entries(pendingSync).filter({
                "AccountHome.useEffect.pending": (entry)=>Boolean(entry[1])
            }["AccountHome.useEffect.pending"]);
            if (!pending.length) return;
            let alive = true;
            const timer = window.setInterval({
                "AccountHome.useEffect.timer": ()=>{
                    void ({
                        "AccountHome.useEffect.timer": async ()=>{
                            for (const [platform, id] of pending){
                                if (!alive) return;
                                try {
                                    const response = await fetch(`/api/connectors/${encodeURIComponent(id)}/sync`, {
                                        method: 'POST',
                                        headers: {
                                            'content-type': 'application/json'
                                        },
                                        body: '{}'
                                    });
                                    const result = await response.json();
                                    if (!alive || !response.ok || result.status !== 'connected') continue;
                                    setPendingSync({
                                        "AccountHome.useEffect.timer": (current)=>({
                                                ...current,
                                                [platform]: undefined
                                            })
                                    }["AccountHome.useEffect.timer"]);
                                    await refreshConnections();
                                    await loadAccount();
                                    setNotice('Network synced.');
                                } catch  {
                                /* Sign-in is still open in the provider window. */ }
                            }
                        }
                    })["AccountHome.useEffect.timer"]();
                }
            }["AccountHome.useEffect.timer"], 4000);
            return ({
                "AccountHome.useEffect": ()=>{
                    alive = false;
                    window.clearInterval(timer);
                }
            })["AccountHome.useEffect"];
        }
    }["AccountHome.useEffect"], [
        pendingSync,
        refreshConnections,
        loadAccount
    ]);
    function openProviderTab(platform) {
        const url = platform === 'linkedin' ? 'https://www.linkedin.com/login' : 'https://x.com/i/flow/login';
        const tab = window.open(url, '_blank', 'noopener,noreferrer');
        if (!tab) {
            setError('Allow a new tab so you can sign in.');
            return false;
        }
        setNotice('Sign in in the new tab. Phone and computer use the same page. Come back and click Sync when you are done.');
        return true;
    }
    async function beginSync(platform, accountId) {
        const openSignIn = connections.find((item)=>item.platform === platform && item.status === 'sign-in-open' && !item.handle);
        const known = accountId || pendingSync[platform] || openSignIn?.id;
        const busyKey = known || platform;
        setLinkBusy(busyKey);
        setError('');
        setNotice('');
        try {
            const live = known ? connections.find((item)=>item.id === known) : undefined;
            if (!known) {
                const response = await fetch('/api/connectors/start', {
                    method: 'POST',
                    headers: {
                        'content-type': 'application/json'
                    },
                    body: JSON.stringify({
                        platform
                    })
                });
                const result = await response.json();
                if (!response.ok || !result.accountId) throw Error(result.error || 'Could not start sync');
                setPendingSync((current)=>({
                        ...current,
                        [platform]: result.accountId
                    }));
                await refreshConnections();
                return;
            }
            // A pending sign-in has no saved account yet. Sync reads that open window.
            // Connect is only for a profile that was saved and later signed out.
            if (live?.status === 'disconnected') {
                const response = await fetch(`/api/connectors/${encodeURIComponent(known)}/connect`, {
                    method: 'POST',
                    headers: {
                        'content-type': 'application/json'
                    },
                    body: '{}'
                });
                const result = await response.json();
                if (!response.ok) throw Error(result.error || 'Could not open sign-in');
                await refreshConnections();
                return;
            }
            const response = await fetch(`/api/connectors/${encodeURIComponent(known)}/sync`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: '{}'
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'Could not sync this network');
            await refreshConnections();
            await loadAccount();
            if (result.status === 'connected') setPendingSync((current)=>({
                    ...current,
                    [platform]: undefined
                }));
            setNotice(result.status === 'connected' ? 'Network synced.' : 'Sign-in is still open. Finish it, then click Sync again.');
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Could not sync this network');
        } finally{
            setLinkBusy(null);
        }
    }
    async function runLink(id, operation) {
        setLinkBusy(id);
        setError('');
        setNotice('');
        try {
            const response = await fetch(`/api/connectors/${encodeURIComponent(id)}/${operation}`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: '{}'
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'Could not update this network');
            await refreshConnections();
            setDisconnectId(null);
            setNotice(operation === 'sync' ? 'Network synced.' : 'Network disconnected.');
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Could not update this network');
        } finally{
            setLinkBusy(null);
        }
    }
    const loadMator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AccountHome.useCallback[loadMator]": async ()=>{
            setMatorLoading(true);
            setMatorError('');
            try {
                const [settings, catalog] = await Promise.all([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorSettings"])(),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchMatorModels"])()
                ]);
                setMator(settings);
                setModels(catalog.models);
                setVoices(catalog.voices);
            } catch (cause) {
                setMatorError(cause instanceof Error ? cause.message : 'Unable to load Mator');
            } finally{
                setMatorLoading(false);
            }
        }
    }["AccountHome.useCallback[loadMator]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountHome.useEffect": ()=>{
            void loadMator();
        }
    }["AccountHome.useEffect"], [
        loadMator
    ]);
    async function saveAccount(path, method, document) {
        if (!data) return;
        setSaving(true);
        setError('');
        setNotice('');
        try {
            const response = await fetch(endpoint + path, {
                method,
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    expectedRevision: data.revision,
                    ...document === undefined ? {} : {
                        document
                    }
                })
            });
            const result = await response.json();
            if (!response.ok) throw Error(result.error || 'Could not save');
            setData(result);
            setEditingProfile(false);
            setRemoveId(null);
            setNotice(method === 'DELETE' ? 'Account removed.' : 'Details saved.');
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : 'Could not save');
        } finally{
            setSaving(false);
        }
    }
    async function patchMator(patch, options) {
        setMatorBusy(true);
        setMatorError('');
        try {
            const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$mator$2f$mator$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveMatorSettings"])(patch);
            setMator(next);
            if (options?.clearDraft) {
                setKeyDraft('');
                setEditingKey(false);
                setKeyVisible(false);
                setConfirmClearKey(false);
            }
            if (options?.saved) setNotice(options.saved);
        } catch (cause) {
            setMatorError(cause instanceof Error ? cause.message : 'Unable to save');
        } finally{
            setMatorBusy(false);
        }
    }
    function openSection(next) {
        setSection(next);
        onNavigate(next === 'connections' ? '/dashboard/profile/connections' : next === 'you' ? '/dashboard/profile' : '/dashboard/settings');
    }
    function runAim(id) {
        if (id === 'profile') {
            setPlanOpen(true);
            return;
        }
        if (id === 'job') {
            onNavigate('/dashboard/resumes/profile');
            return;
        }
        window.location.assign(id === 'audience' ? '/dashboard/editorial' : '/dashboard/growth');
    }
    const profile = data?.profile;
    const initial = (profile?.displayName || 'U').trim().charAt(0).toUpperCase();
    const linkedCount = connections.filter((item)=>item.status === 'connected').length;
    const removeAccount = data?.socialAccounts.find((row)=>row.id === removeId) ?? null;
    const disconnectAccount = data?.socialAccounts.find((row)=>row.id === disconnectId) ?? null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "owner-profile-page",
        className: "pb-16",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "automation-settings-page",
                className: "mx-auto grid max-w-6xl gap-8 lg:grid-cols-[220px_minmax(0,1fr)] lg:items-start lg:gap-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$account$2d$section$2d$nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccountSectionNav"], {
                        section: section,
                        profile: profile,
                        socialAccounts: data?.socialAccounts ?? [],
                        linkedCount: linkedCount,
                        initial: initial,
                        onOpenSection: openSection
                    }, void 0, false, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex max-w-3xl min-w-0 flex-col gap-4",
                        children: [
                            notice ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$notice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Notice"], {
                                tone: "ok",
                                onDismiss: ()=>setNotice(''),
                                children: notice
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 490,
                                columnNumber: 13
                            }, this) : null,
                            error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$account$2d$notice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Notice"], {
                                tone: "warn",
                                onDismiss: ()=>setError(''),
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 495,
                                columnNumber: 13
                            }, this) : null,
                            section === 'you' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$profile$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileSection"], {
                                dataLoaded: Boolean(data),
                                profile: profile,
                                onEdit: ()=>{
                                    if (profile) {
                                        setDraft({
                                            ...profile
                                        });
                                        setEditingProfile(true);
                                    }
                                },
                                onRunAim: runAim
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 501,
                                columnNumber: 13
                            }, this) : null,
                            section === 'connections' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$networks$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NetworksSection"], {
                                available: available,
                                socialAccounts: data?.socialAccounts,
                                connections: connections,
                                linkBusy: linkBusy,
                                pendingSync: pendingSync,
                                linkedAccountId: linkedAccountId,
                                selectedAccount: selectedAccount,
                                onConnect: onConnect,
                                onOpenProviderTab: openProviderTab,
                                onBeginSync: beginSync,
                                onRequestDisconnect: setDisconnectId
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 515,
                                columnNumber: 13
                            }, this) : null,
                            section === 'mator' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$mator$2d$account$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MatorAccountSection"], {
                                matorLoading: matorLoading,
                                mator: mator,
                                models: models,
                                voices: voices,
                                matorError: matorError,
                                matorBusy: matorBusy,
                                keyDraft: keyDraft,
                                keyVisible: keyVisible,
                                editingKey: editingKey,
                                confirmClearKey: confirmClearKey,
                                keyInputRef: keyInputRef,
                                onDismissMatorError: ()=>setMatorError(''),
                                onKeyDraftChange: setKeyDraft,
                                onSetKeyVisible: setKeyVisible,
                                onEditingKeyChange: setEditingKey,
                                onConfirmClearKeyChange: setConfirmClearKey,
                                onPatchMator: patchMator
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 531,
                                columnNumber: 13
                            }, this) : null,
                            section === 'preferences' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$sections$2f$preferences$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PreferencesSection"], {
                                mator: mator,
                                matorBusy: matorBusy,
                                hosted: hosted,
                                onPatchMator: patchMator
                            }, void 0, false, {
                                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                                lineNumber: 553,
                                columnNumber: 13
                            }, this) : null
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                        lineNumber: 488,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                lineNumber: 476,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$profile$2d$plan$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfilePlanDialog"], {
                open: planOpen,
                onDismiss: ()=>setPlanOpen(false)
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                lineNumber: 563,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$profile$2d$editor$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileEditorDialog"], {
                open: editingProfile,
                draft: draft,
                saving: saving,
                onDismiss: ()=>setEditingProfile(false),
                onDraftChange: (updater)=>setDraft((current)=>current ? updater(current) : current),
                onSubmit: ()=>{
                    if (draft) void saveAccount('/profile', 'PUT', draft);
                }
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                lineNumber: 565,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$remove$2d$account$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoveAccountDialog"], {
                account: removeAccount,
                saving: saving,
                onDismiss: ()=>setRemoveId(null),
                onConfirm: ()=>{
                    if (removeAccount) {
                        void saveAccount(`/social/${removeAccount.id}`, 'DELETE');
                    }
                }
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                lineNumber: 578,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$frontend$2f$components$2f$dashboard$2f$account$2f$dialogs$2f$disconnect$2d$network$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisconnectNetworkDialog"], {
                account: disconnectAccount,
                linkBusy: linkBusy,
                onDismiss: ()=>setDisconnectId(null),
                onConfirm: ()=>{
                    if (disconnectAccount) {
                        void runLink(disconnectAccount.id, 'disconnect');
                    }
                }
            }, void 0, false, {
                fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
                lineNumber: 589,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/frontend/components/dashboard/account/account-home.tsx",
        lineNumber: 475,
        columnNumber: 5
    }, this);
}
_s(AccountHome, "SLDlFd0sIFIKO+sU4XfEtLlX+0w=");
_c = AccountHome;
var _c;
__turbopack_context__.k.register(_c, "AccountHome");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_frontend_components_dashboard_account_0lej1ms._.js.map