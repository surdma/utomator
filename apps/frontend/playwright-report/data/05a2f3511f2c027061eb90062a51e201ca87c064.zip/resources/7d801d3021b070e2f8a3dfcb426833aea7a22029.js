(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0zbjahy._.js","static/chunks/0ohs_next_dist_compiled_next-devtools_index_0jw_ul0.js","static/chunks/0ohs_next_dist_compiled_react-dom_0ara29_._.js","static/chunks/0ohs_next_dist_compiled_react-server-dom-turbopack_05ufh6o._.js","static/chunks/0ohs_next_dist_compiled_0d50daw._.js","static/chunks/0ohs_next_dist_client_0jqbu37._.js","static/chunks/0ohs_next_dist_03guh~f._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
