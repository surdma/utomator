(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@shadcn+react@0.3.1_@types+react@19.2.14_react@19.2.4/node_modules/@shadcn/react/dist/chunk-HBS6WEDP.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>S,
    "b",
    ()=>d,
    "c",
    ()=>f
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function S({ defaultTagName: a, props: r, render: t, state: n = {}, stateAttributesMapping: e }) {
    let o = d(R(n, e), r);
    if (!t) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](a, o);
    if (typeof t == "function") return t(o, n);
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](t)) return null;
    let s = t.props, u = {
        ...d(o, s),
        ref: f(o.ref, s.ref)
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](t, u);
}
function d(...a) {
    let r = {};
    for (let t of a){
        if (!t) continue;
        let n = t;
        for (let e of Object.keys(n)){
            let o = n[e];
            if (o === void 0) continue;
            let s = r[e];
            e === "className" ? r[e] = [
                s,
                o
            ].filter(Boolean).join(" ") : e === "style" ? r[e] = {
                ...s,
                ...o
            } : e === "ref" ? r[e] = f(s, o) : l(e) && typeof s == "function" && typeof o == "function" ? r[e] = p(o, s) : r[e] = o;
        }
    }
    return r;
}
function R(a, r) {
    let t = {};
    for (let n of Object.keys(a)){
        let e = a[n], o = r?.[n]?.(e);
        if (o) {
            Object.assign(t, o);
            continue;
        }
        if (n === "slot") {
            t["data-slot"] = e;
            continue;
        }
        let s = `data-${String(n).replace(/[A-Z]/g, (c)=>`-${c.toLowerCase()}`)}`;
        typeof e == "boolean" ? t[s] = e ? "" : void 0 : e != null && (t[s] = String(e));
    }
    return t;
}
function p(a, r) {
    return function(n) {
        a(n), n.defaultPrevented || r(n);
    };
}
function l(a) {
    return /^on[A-Z]/.test(a);
}
function f(...a) {
    let r = a.filter(Boolean);
    if (r.length !== 0) return (t)=>{
        for (let n of r)typeof n == "function" ? n(t) : n && (n.current = t);
    };
}
;
}),
"[project]/node_modules/.pnpm/@shadcn+react@0.3.1_@types+react@19.2.14_react@19.2.4/node_modules/@shadcn/react/dist/message-scroller/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageScroller",
    ()=>er,
    "useMessageScroller",
    ()=>Pt,
    "useMessageScrollerScrollable",
    ()=>wt,
    "useMessageScrollerVisibility",
    ()=>Ot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@shadcn+react@0.3.1_@types+react@19.2.14_react@19.2.4/node_modules/@shadcn/react/dist/chunk-HBS6WEDP.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
var _e = 8, Be = 64, Fe = 0, J = .5, je = 180, Ge = new Set([
    "ArrowDown",
    "ArrowUp",
    "End",
    "Home",
    "PageDown",
    "PageUp",
    " "
]), ge = {
    start: false,
    end: false
}, vt = [], Q = {
    currentAnchorId: null,
    visibleMessageIds: vt
};
function Ne({ content: e, scrollEdgeThreshold: t, spacer: r, viewport: n }) {
    if (!n || !e) return ge;
    let l = Re({
        content: e,
        spacer: r,
        viewport: n
    });
    return {
        start: n.scrollTop > t,
        end: l - n.scrollTop - n.clientHeight > t
    };
}
function Ue({ content: e, scrollMargin: t, scrollPreviousItemPeek: r, spacer: n, viewport: l, visibleMessageIds: c }) {
    if (!e || !l) return Q;
    let S = l.getBoundingClientRect(), o = S.top + t + r, b = typeof IntersectionObserver > "u", v = [], m = null;
    for (let L of ee(e, n)){
        let R = L.dataset.messageId;
        if (!R) continue;
        let E = L.dataset.scrollAnchor === "true", h = E || b ? L.getBoundingClientRect() : null;
        (b && h ? h.bottom > o && h.top < S.bottom : c.has(R)) && v.push(R), E && h && h.top <= o + J && (m = R);
    }
    return v.length === 0 && m === null ? Q : {
        currentAnchorId: m,
        visibleMessageIds: v
    };
}
function ee(e, t) {
    return Array.from(e.children).filter((r)=>r instanceof HTMLElement && r !== t);
}
function Ye(e, t) {
    for(let r = t; r < e.length; r++){
        let n = e[r];
        if (n?.dataset.scrollAnchor === "true") return n;
    }
    return null;
}
function ze(e, t) {
    for (let r of e)if (r.dataset.scrollAnchor === "true" && !t.has(r)) return r;
    return null;
}
function qe(e, t) {
    let r = 0;
    for(let n = t; n < e.length; n++)if (e[n]?.dataset.scrollAnchor === "true" && (r += 1, r > 1)) return true;
    return false;
}
function Ke(e) {
    for(let t = e.length - 1; t >= 0; t--){
        let r = e[t];
        if (r?.dataset.scrollAnchor === "true") return r;
    }
    return null;
}
function We({ content: e, spacer: t, viewport: r }) {
    let n = r.getBoundingClientRect();
    for (let l of ee(e, t)){
        if (!l.dataset.messageId) continue;
        let c = l.getBoundingClientRect();
        if (c.bottom > n.top && c.top < n.bottom) return l;
    }
    return null;
}
function $e({ align: e, element: t, scrollMargin: r, spacer: n, viewport: l }) {
    let c = me(t, l), S = t.getBoundingClientRect().height, o = ht(n);
    if (e === "center") {
        let b = Math.max(0, l.clientHeight - o.start - o.end);
        return c - o.start - (b - S) / 2 - r;
    }
    if (e === "end") return c - l.clientHeight + S + o.end + r;
    if (e === "nearest") {
        let b = c + S, v = l.scrollTop + o.start, m = l.scrollTop + l.clientHeight - o.end;
        return c >= v && b <= m ? l.scrollTop : c < v ? c - o.start - r : b - l.clientHeight + o.end + r;
    }
    return c - o.start - r;
}
function me(e, t) {
    let r = e.getBoundingClientRect(), n = t.getBoundingClientRect();
    return r.top - n.top + t.scrollTop;
}
function te(e, t) {
    return e.getBoundingClientRect().top - t.getBoundingClientRect().top;
}
function Je({ content: e, scrollTop: t, spacer: r, viewport: n }) {
    let l = Re({
        content: e,
        spacer: r,
        viewport: n
    });
    return t + n.clientHeight - l;
}
function Re({ content: e, spacer: t, viewport: r }) {
    let n = ee(e, t), l = Xe(e), c = r.getBoundingClientRect(), S = r.scrollTop, o = l.start + l.end;
    for (let b of n){
        let v = b.getBoundingClientRect();
        o = Math.max(o, v.bottom - c.top + S + l.end);
    }
    return o;
}
function Qe(e) {
    return Math.max(0, e.scrollHeight - e.clientHeight);
}
function Xe(e) {
    let t = window.getComputedStyle(e);
    return {
        end: pe(t.paddingBlockEnd || t.paddingBottom),
        start: pe(t.paddingBlockStart || t.paddingTop)
    };
}
function ht(e) {
    let t = e?.parentElement;
    return t ? Xe(t) : {
        end: 0,
        start: 0
    };
}
function Ze(e) {
    if (!e) return 0;
    let t = window.getComputedStyle(e), r = t.rowGap === "normal" ? t.gap : t.rowGap;
    return pe(r);
}
function pe(e) {
    if (!e) return 0;
    let t = Number.parseFloat(e);
    return Number.isFinite(t) ? t : 0;
}
function et(e, t) {
    let r = e, n = new Set;
    return {
        getSnapshot: ()=>r,
        hasListeners: ()=>n.size > 0,
        setSnapshot: (l)=>{
            t(r, l) || (r = l, n.forEach((c)=>c()));
        },
        subscribe: (l, c, S)=>{
            let o = n.size === 0;
            return n.add(l), o && c?.(), ()=>{
                n.delete(l), n.size === 0 && S?.();
            };
        }
    };
}
function de(e, t) {
    return et(e, t);
}
function tt() {
    return et(Q, Lt);
}
function rt(e, t) {
    return e.start === t.start && e.end === t.end;
}
function Lt(e, t) {
    return e.currentAnchorId !== t.currentAnchorId || e.visibleMessageIds.length !== t.visibleMessageIds.length ? false : e.visibleMessageIds.every((r, n)=>r === t.visibleMessageIds[n]);
}
function nt({ autoScroll: e, defaultScrollPosition: t, scrollEdgeThreshold: r, scrollMargin: n, scrollPreviousItemPeek: l }) {
    let c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](e), S = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), b = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false), v = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](r), m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0), L = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), R = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0), E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](e ? "following-bottom" : "free-scrolling"), h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](new Map), I = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), u = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), k = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), j = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](l), _ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](true), Y = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](n), V = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), P = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0), G = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0), A = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), le = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), z = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), B = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), w = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), C = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), y = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](new Set), F = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](new WeakSet);
    return z.current === null && (z.current = de(t === "end" || t === "last-anchor", (q, X)=>q === X)), B.current === null && (B.current = de(ge, rt)), C.current === null && (C.current = tt()), c.current = e, v.current = r, x.current = n, j.current = l, {
        autoScrollRef: c,
        autoscrollingRef: S,
        autoscrollingTimeoutRef: i,
        streamingTurnRef: k,
        contentRef: o,
        defaultScrollPositionAppliedRef: b,
        firstItemRef: L,
        itemCountRef: m,
        lastScrollTopRef: R,
        messageElementsRef: h,
        modeRef: E,
        pendingScrollFrameRef: V,
        pendingScrollToMessageRef: I,
        prependRestoreRef: u,
        preserveScrollOnPrependRef: _,
        pendingDefaultScrollStore: z.current,
        rootRef: Y,
        scrollEdgeThresholdRef: v,
        scrollMarginRef: x,
        scrollPreviousItemPeekRef: j,
        spacerGapRef: P,
        spacerHeightRef: G,
        spacerRef: A,
        stateFrameRef: le,
        stateStore: B.current,
        viewportRef: d,
        visibilityFrameRef: T,
        visibilityObserverRef: w,
        visibilityStore: C.current,
        visibleMessageIdsRef: y,
        handledScrollAnchorsRef: F
    };
}
function Me(e) {
    e.pendingDefaultScrollStore.setSnapshot(false);
}
function re(e) {
    e.defaultScrollPositionAppliedRef.current = true, Me(e);
}
function lt({ refs: e, commitScrollState: t, scheduleStateCommit: r, scheduleVisibilitySync: n }) {
    let { streamingTurnRef: l, autoScrollRef: c, autoscrollingRef: S, autoscrollingTimeoutRef: o, contentRef: b, itemCountRef: v, messageElementsRef: m, modeRef: L, pendingScrollToMessageRef: R, prependRestoreRef: E, scrollMarginRef: h, scrollPreviousItemPeekRef: I, spacerGapRef: u, spacerHeightRef: k, spacerRef: j, viewportRef: _ } = e, Y = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[Y]": (i)=>{
            o.current !== null && (window.clearTimeout(o.current), o.current = null), S.current !== i && (S.current = i, t()), i && (o.current = window.setTimeout({
                "lt.useCallback[Y]": ()=>{
                    o.current = null, S.current = false, t();
                }
            }["lt.useCallback[Y]"], je));
        }
    }["lt.useCallback[Y]"], [
        t
    ]), x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[x]": (i)=>{
            let d = j.current;
            if (!d) return;
            let T = Math.max(0, Math.ceil(i));
            k.current !== T && (k.current = T, d.hidden = T === 0, d.style.height = `${T}px`, d.style.marginTop = T > 0 ? `${-u.current}px` : "");
        }
    }["lt.useCallback[x]"], []), V = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[V]": (i, { behavior: d = "auto", autoscrolling: T = false } = {})=>{
            let w = _.current;
            if (!w) return;
            let C = Math.max(0, i);
            if (Math.abs(w.scrollTop - C) <= J) {
                w.scrollTop = C, t();
                return;
            }
            T && Y(true), w.scrollTo({
                top: C,
                behavior: d
            }), r();
        }
    }["lt.useCallback[V]"], [
        t,
        r,
        Y
    ]), P = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[P]": ({ behavior: i = "auto" } = {})=>_.current ? (x(0), l.current = null, L.current = "free-scrolling", V(0, {
                behavior: i
            }), n(), true) : false
    }["lt.useCallback[P]"], [
        n,
        V,
        x
    ]), G = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[G]": ({ behavior: i = "auto" } = {})=>{
            let d = _.current;
            return d ? (x(0), l.current = null, L.current = c.current ? "following-bottom" : "free-scrolling", V(Qe(d), {
                autoscrolling: true,
                behavior: i
            }), n(), true) : false;
        }
    }["lt.useCallback[G]"], [
        n,
        V,
        x
    ]), A = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[A]": (i, { align: d = "start", behavior: T = "auto", scrollMargin: w = h.current } = {}, { keepPreviousPeek: C = false } = {})=>{
            let y = b.current, F = _.current;
            if (!y || !F || !y.contains(i)) return false;
            let q = $e({
                align: d,
                element: i,
                scrollMargin: C ? w + I.current : w,
                spacer: j.current,
                viewport: F
            }), X = Je({
                content: y,
                scrollTop: q,
                spacer: j.current,
                viewport: F
            });
            return x(X), E.current = {
                element: i,
                viewportTop: te(i, F)
            }, L.current = C ? "anchored-to-message" : "settling-jump", l.current = C ? i : null, V(q, {
                behavior: T
            }), n(), true;
        }
    }["lt.useCallback[A]"], [
        n,
        V,
        x
    ]), le = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[le]": ()=>{
            let i = l.current;
            return !i || !i.isConnected || L.current !== "anchored-to-message" ? false : A(i, {
                align: "start"
            }, {
                keepPreviousPeek: true
            });
        }
    }["lt.useCallback[le]"], [
        A
    ]), z = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "lt.useCallback[z]": (i, d)=>{
            let T = m.current.get(i);
            return T ? (re(e), A(T, d) ? (R.current = null, true) : (R.current = {
                messageId: i,
                options: d
            }, true)) : v.current === 0 ? (R.current = {
                messageId: i,
                options: d
            }, re(e), true) : false;
        }
    }["lt.useCallback[z]"], [
        A
    ]);
    return {
        flushPendingScrollToMessage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
            "lt.useCallback": ()=>{
                let i = R.current;
                if (!i) return false;
                let d = m.current.get(i.messageId);
                return !d || !A(d, i.options) ? false : (R.current = null, re(e), true);
            }
        }["lt.useCallback"], [
            A
        ]),
        reanchorToAnchoredMessage: le,
        scrollToElement: A,
        scrollToEnd: G,
        scrollToMessage: z,
        scrollToStart: P
    };
}
function ot(e, t) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "ot.useCallback": (r)=>{
            e.current = r, r && t();
        }
    }["ot.useCallback"], [
        e,
        t
    ]);
}
function st({ autoScroll: e = false, defaultScrollPosition: t = "end", scrollEdgeThreshold: r = _e, scrollPreviousItemPeek: n = Be, scrollMargin: l = Fe }) {
    let c = nt({
        autoScroll: e,
        defaultScrollPosition: t,
        scrollEdgeThreshold: r,
        scrollMargin: l,
        scrollPreviousItemPeek: n
    }), { streamingTurnRef: S, autoScrollRef: o, autoscrollingRef: b, autoscrollingTimeoutRef: v, contentRef: m, defaultScrollPositionAppliedRef: L, firstItemRef: R, itemCountRef: E, lastScrollTopRef: h, messageElementsRef: I, modeRef: u, pendingScrollFrameRef: k, pendingScrollToMessageRef: j, prependRestoreRef: _, preserveScrollOnPrependRef: Y, pendingDefaultScrollStore: x, rootRef: V, scrollEdgeThresholdRef: P, scrollMarginRef: G, scrollPreviousItemPeekRef: A, spacerGapRef: le, spacerHeightRef: z, spacerRef: B, stateFrameRef: i, stateStore: d, viewportRef: T, visibilityFrameRef: w, visibilityObserverRef: C, visibilityStore: y, visibleMessageIdsRef: F, handledScrollAnchorsRef: q } = c, X = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](t);
    X.current !== t && (X.current = t, L.current = false);
    let ce = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[ce]": (s)=>{
            let a = V.current, M = T.current, H = [
                s.start && "start",
                s.end && "end"
            ].filter(Boolean).join(" "), fe = b.current;
            for (let W of [
                a,
                M
            ])W && (H ? W.setAttribute("data-scrollable", H) : W.removeAttribute("data-scrollable"), W.toggleAttribute("data-autoscrolling", fe));
        }
    }["st.useCallback[ce]"], []), be = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[be]": (s)=>{
            let a = T.current?.scrollTop ?? 0, M = a < h.current - J;
            h.current = a, o.current && !s.end && u.current !== "settling-jump" && u.current !== "anchored-to-message" ? u.current = "following-bottom" : u.current === "following-bottom" && s.end && M && !b.current && (u.current = "free-scrolling");
        }
    }["st.useCallback[be]"], []), N = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[N]": ()=>{
            let s = Ne({
                content: m.current,
                scrollEdgeThreshold: P.current,
                spacer: B.current,
                viewport: T.current
            });
            be(s);
            let a = u.current === "following-bottom" ? {
                ...s,
                end: false
            } : s;
            ce(a), d.setSnapshot(a);
        }
    }["st.useCallback[N]"], [
        be,
        d,
        ce
    ]), oe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[oe]": ()=>{
            i.current === null && (i.current = window.requestAnimationFrame({
                "st.useCallback[oe]": ()=>{
                    i.current = null, N();
                }
            }["st.useCallback[oe]"]));
        }
    }["st.useCallback[oe]"], [
        N
    ]), O = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[O]": ()=>{
            y.hasListeners() && w.current === null && (w.current = window.requestAnimationFrame({
                "st.useCallback[O]": ()=>{
                    w.current = null, y.hasListeners() && y.setSnapshot(Ue({
                        content: m.current,
                        scrollMargin: G.current,
                        scrollPreviousItemPeek: A.current,
                        spacer: B.current,
                        viewport: T.current,
                        visibleMessageIds: F.current
                    }));
                }
            }["st.useCallback[O]"]));
        }
    }["st.useCallback[O]"], [
        y
    ]), { flushPendingScrollToMessage: ae, reanchorToAnchoredMessage: Te, scrollToElement: se, scrollToEnd: D, scrollToMessage: Ee, scrollToStart: ie } = lt({
        refs: c,
        commitScrollState: N,
        scheduleStateCommit: oe,
        scheduleVisibilitySync: O
    }), ve = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[ve]": ()=>{
            let s = _.current, a = T.current;
            if (!s || !a || !s.element.isConnected) return false;
            let H = te(s.element, a) - s.viewportTop;
            return Math.abs(H) <= J ? false : (a.scrollTop += H, s.viewportTop = te(s.element, a), oe(), O(), true);
        }
    }["st.useCallback[ve]"], [
        oe,
        O
    ]), Z = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Z]": ()=>{
            let s = m.current, a = T.current;
            if (!s || !a) {
                _.current = null;
                return;
            }
            let M = We({
                content: s,
                spacer: B.current,
                viewport: a
            });
            _.current = M ? {
                element: M,
                viewportTop: te(M, a)
            } : null;
        }
    }["st.useCallback[Z]"], []), he = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[he]": ()=>{
            k.current === null && (k.current = window.requestAnimationFrame({
                "st.useCallback[he]": ()=>{
                    k.current = null, ae() && Z();
                }
            }["st.useCallback[he]"]));
        }
    }["st.useCallback[he]"], [
        Z,
        ae
    ]), ue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[ue]": ()=>{
            if (!t || L.current || E.current === 0) return false;
            let s = false;
            if (t === "last-anchor") {
                let a = m.current, M = T.current, H = a && M ? Ke(ee(a, B.current)) : null;
                if (!a || !M || !H) s = D({
                    behavior: "auto"
                });
                else {
                    let fe = me(H, M);
                    s = Re({
                        content: a,
                        spacer: B.current,
                        viewport: M
                    }) - fe <= M.clientHeight ? D({
                        behavior: "auto"
                    }) : se(H, {
                        align: "start"
                    }, {
                        keepPreviousPeek: true
                    });
                }
            } else s = t === "end" ? D({
                behavior: "auto"
            }) : ie({
                behavior: "auto"
            });
            return s ? (re(c), true) : false;
        }
    }["st.useCallback[ue]"], [
        t,
        se,
        D,
        ie
    ]), Le = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Le]": ()=>{
            let s = m.current;
            if (!s) return;
            let a = ee(s, B.current), M = E.current, H = R.current;
            E.current = a.length, R.current = a[0] ?? null, ({
                "st.useCallback[Le]": ()=>{
                    if (ae()) return;
                    if (M === 0) {
                        if (ue() || a.length > 0 && o.current && D({
                            behavior: "auto"
                        })) return;
                        N(), O();
                        return;
                    }
                    let W = H ? a.indexOf(H) : -1;
                    if (Y.current && W > 0) {
                        ve();
                        return;
                    }
                    if (a.length > M) {
                        let $ = Ye(a, M);
                        if ($) {
                            if (o.current && u.current === "following-bottom" && qe(a, M)) {
                                D({
                                    behavior: "auto"
                                });
                                return;
                            }
                            se($, {
                                align: "start"
                            }, {
                                keepPreviousPeek: true
                            }), q.current.add($);
                            return;
                        }
                    }
                    if (a.length === M) {
                        let $ = ze(a, q.current);
                        if ($) {
                            se($, {
                                align: "start"
                            }, {
                                keepPreviousPeek: true
                            }), q.current.add($);
                            return;
                        }
                    }
                    u.current === "following-bottom" && o.current ? D({
                        behavior: "auto"
                    }) : (N(), O());
                }
            })["st.useCallback[Le]"](), Z();
        }
    }["st.useCallback[Le]"], [
        ue,
        Z,
        N,
        ae,
        ve,
        O,
        se,
        D
    ]), Ce = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Ce]": ()=>{
            if (u.current === "following-bottom" && o.current) {
                D({
                    behavior: "auto"
                });
                return;
            }
            let s = z.current;
            if (Te()) {
                o.current && s > 0 && z.current === 0 && D({
                    behavior: "auto"
                });
                return;
            }
            oe(), O();
        }
    }["st.useCallback[Ce]"], [
        Te,
        oe,
        O,
        D
    ]), Pe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Pe]": ()=>{
            let s = T.current;
            if (!(!s || !y.hasListeners())) {
                if (typeof IntersectionObserver > "u") {
                    O();
                    return;
                }
                C.current || (C.current = new IntersectionObserver({
                    "st.useCallback[Pe]": (a)=>{
                        for (let M of a){
                            let H = M.target.dataset.messageId;
                            H && (M.isIntersecting ? F.current.add(H) : F.current.delete(H));
                        }
                        O();
                    }
                }["st.useCallback[Pe]"], {
                    root: s,
                    rootMargin: `${-(G.current + A.current)}px 0px 0px 0px`,
                    threshold: [
                        0,
                        .01,
                        .5,
                        1
                    ]
                })), I.current.forEach({
                    "st.useCallback[Pe]": (a)=>{
                        C.current?.observe(a);
                    }
                }["st.useCallback[Pe]"]), O();
            }
        }
    }["st.useCallback[Pe]"], [
        O,
        y
    ]), we = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[we]": ()=>{
            w.current !== null && (window.cancelAnimationFrame(w.current), w.current = null), C.current?.disconnect(), C.current = null, F.current.clear(), y.setSnapshot(Q);
        }
    }["st.useCallback[we]"], [
        y
    ]), bt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[bt]": (s, a, M)=>{
            if (a) {
                I.current.set(s, a), C.current?.observe(a), O(), j.current?.messageId === s && he();
                return;
            }
            M && I.current.get(s) === M && (I.current.delete(s), F.current.delete(s), C.current?.unobserve(M), O());
        }
    }["st.useCallback[bt]"], [
        he,
        O
    ]), Oe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Oe]": ()=>{
            (u.current === "following-bottom" || u.current === "anchored-to-message" || u.current === "settling-jump") && (S.current = null, u.current = "free-scrolling");
        }
    }["st.useCallback[Oe]"], []), ye = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[ye]": ()=>ce(d.getSnapshot())
    }["st.useCallback[ye]"], [
        d,
        ce
    ]), He = ot(V, ye), Ie = ot(T, ye), Ae = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[Ae]": (s)=>{
            m.current = s;
        }
    }["st.useCallback[Ae]"], []), De = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[De]": (s)=>{
            B.current = s, le.current = Ze(s?.parentElement ?? null);
        }
    }["st.useCallback[De]"], []), xe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "st.useCallback[xe]": ()=>{
            N(), O(), Z();
        }
    }["st.useCallback[xe]"], [
        Z,
        N,
        O
    ]), Tt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "st.useMemo[Tt]": ()=>({
                handleContentChange: Le,
                handleResize: Ce,
                observeVisibility: Pe,
                pendingDefaultScrollStore: x,
                preserveScrollOnPrependRef: Y,
                scrollToEnd: D,
                scrollToMessage: Ee,
                scrollToStart: ie,
                setContentElement: Ae,
                setRootElement: He,
                setSpacerElement: De,
                setViewportElement: Ie,
                stateStore: d,
                syncAfterScroll: xe,
                unobserveVisibility: we,
                userScrollIntent: Oe,
                viewportRef: T,
                visibilityStore: y
            })
    }["st.useMemo[Tt]"], [
        Le,
        Ce,
        Pe,
        x,
        D,
        Ee,
        ie,
        Ae,
        He,
        De,
        Ie,
        d,
        xe,
        we,
        Oe,
        y
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "st.useLayoutEffect": ()=>{
            ue() || E.current === 0 && Me(c);
        }
    }["st.useLayoutEffect"], [
        ue
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "st.useEffect": ()=>({
                "st.useEffect": ()=>{
                    i.current !== null && (window.cancelAnimationFrame(i.current), i.current = null), w.current !== null && (window.cancelAnimationFrame(w.current), w.current = null), v.current !== null && (window.clearTimeout(v.current), v.current = null), k.current !== null && (window.cancelAnimationFrame(k.current), k.current = null), C.current?.disconnect(), C.current = null;
                }
            })["st.useEffect"]
    }["st.useEffect"], []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "st.useLayoutEffect": ()=>{
            if (e && u.current === "following-bottom" && E.current > 0) {
                D({
                    behavior: "auto"
                });
                return;
            }
            N();
        }
    }["st.useLayoutEffect"], [
        e,
        N,
        D
    ]), {
        context: Tt,
        registerMessage: bt
    };
}
function at(e) {
    let t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](e);
    return t.current = e, t;
}
var it = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null), ut = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function K() {
    let e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](it);
    if (!e) throw new Error("useMessageScroller must be used within a MessageScroller.");
    return e;
}
function Ct() {
    let e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ut);
    if (!e) throw new Error("MessageScrollerItem must be used within a MessageScroller.");
    return e;
}
function Pt() {
    let { scrollToEnd: e, scrollToMessage: t, scrollToStart: r } = K();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Pt.useMemo": ()=>({
                scrollToEnd: e,
                scrollToMessage: t,
                scrollToStart: r
            })
    }["Pt.useMemo"], [
        e,
        t,
        r
    ]);
}
function wt() {
    let { stateStore: e } = K();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"](e.subscribe, e.getSnapshot, e.getSnapshot);
}
function Ot() {
    let { observeVisibility: e, unobserveVisibility: t, visibilityStore: r } = K(), n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Ot.useCallback[n]": (l)=>r.subscribe(l, e, t)
    }["Ot.useCallback[n]"], [
        e,
        t,
        r
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"](n, r.getSnapshot, r.getSnapshot);
}
function ft({ autoScroll: e = false, children: t, defaultScrollPosition: r = "end", scrollEdgeThreshold: n, scrollPreviousItemPeek: l, scrollMargin: c }) {
    let { context: S, registerMessage: o } = st({
        autoScroll: e,
        defaultScrollPosition: r,
        scrollEdgeThreshold: n,
        scrollPreviousItemPeek: l,
        scrollMargin: c
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(it.Provider, {
        value: S,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ut.Provider, {
            value: o,
            children: t
        })
    });
}
function St() {
    let { pendingDefaultScrollStore: e } = K();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"](e.subscribe, e.getSnapshot, e.getSnapshot);
}
function gt({ children: e, ...t }) {
    let { setRootElement: r } = K(), n = St();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: r,
        ...t,
        ...n ? {
            "data-pending-scroll": ""
        } : null,
        children: e
    });
}
function Rt({ "aria-label": e, children: t, onKeyDown: r, onScroll: n, onTouchMove: l, onWheel: c$1, preserveScrollOnPrepend: S = true, ref: o, role: b, tabIndex: v, ...m }) {
    let { handleResize: L, preserveScrollOnPrependRef: R, setViewportElement: E, syncAfterScroll: h, userScrollIntent: I, viewportRef: u } = K(), k = St();
    R.current = S;
    let j = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Rt.useCallback[j]": (P)=>{
            E(P), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(o)?.(P);
        }
    }["Rt.useCallback[j]"], [
        o,
        E
    ]);
    function _(P) {
        h(), n?.(P);
    }
    function Y(P) {
        I(), c$1?.(P);
    }
    function x(P) {
        I(), l?.(P);
    }
    function V(P) {
        Ge.has(P.key) && I(), r?.(P);
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Rt.useEffect": ()=>{
            let P = u.current;
            if (!P || typeof ResizeObserver > "u") return;
            let G = 0, A = new ResizeObserver({
                "Rt.useEffect": ()=>{
                    window.cancelAnimationFrame(G), G = window.requestAnimationFrame(L);
                }
            }["Rt.useEffect"]);
            return A.observe(P), ({
                "Rt.useEffect": ()=>{
                    window.cancelAnimationFrame(G), A.disconnect();
                }
            })["Rt.useEffect"];
        }
    }["Rt.useEffect"], [
        L,
        u
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: j,
        role: b ?? "region",
        "aria-label": e ?? "Messages",
        tabIndex: v ?? 0,
        onKeyDown: V,
        onScroll: _,
        onTouchMove: x,
        onWheel: Y,
        ...m,
        ...k ? {
            "data-pending-scroll": ""
        } : null,
        children: t
    });
}
function pt({ "aria-relevant": e, children: t, ref: r, role: n, spacerClassName: l, ...c$1 }) {
    let { handleContentChange: S, handleResize: o, setContentElement: b, setSpacerElement: v } = K(), m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), L = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "pt.useCallback[L]": (R)=>{
            m.current = R, b(R), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(r)?.(R);
        }
    }["pt.useCallback[L]"], [
        r,
        b
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "pt.useLayoutEffect": ()=>{
            let R = m.current;
            if (!R || (S(), typeof MutationObserver > "u")) return;
            let E = new MutationObserver({
                "pt.useLayoutEffect": ()=>{
                    S();
                }
            }["pt.useLayoutEffect"]);
            return E.observe(R, {
                childList: true
            }), ({
                "pt.useLayoutEffect": ()=>E.disconnect()
            })["pt.useLayoutEffect"];
        }
    }["pt.useLayoutEffect"], [
        S
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "pt.useEffect": ()=>{
            let R = m.current;
            if (!R || typeof ResizeObserver > "u") return;
            let E = 0, h = new ResizeObserver({
                "pt.useEffect": ()=>{
                    window.cancelAnimationFrame(E), E = window.requestAnimationFrame(o);
                }
            }["pt.useEffect"]);
            return h.observe(R), ({
                "pt.useEffect": ()=>{
                    window.cancelAnimationFrame(E), h.disconnect();
                }
            })["pt.useEffect"];
        }
    }["pt.useEffect"], [
        o
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        ref: L,
        role: n ?? "log",
        "aria-relevant": e ?? "additions",
        ...c$1,
        children: [
            t,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                ref: v,
                "aria-hidden": "true",
                "data-message-scroller-spacer": "",
                hidden: true,
                className: l
            })
        ]
    });
}
function mt({ messageId: e, ref: t, scrollAnchor: r = false, ...n }) {
    let l = Ct(), c$1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), S = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "mt.useCallback[S]": (o)=>{
            let b = c$1.current;
            c$1.current = o, e && l(e, o, b), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(t)?.(o);
        }
    }["mt.useCallback[S]"], [
        e,
        t,
        l
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: S,
        "data-message-id": e,
        "data-scroll-anchor": r ? "true" : "false",
        ...n
    });
}
function dt({ behavior: e = "smooth", children: t, direction: r = "end", onClick: n, render: l, tabIndex: c, type: S = "button", ...o }) {
    let { scrollToEnd: b$1, scrollToStart: v, stateStore: m } = K(), L = at(n), R = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "dt.useCallback[R]": (u)=>m.subscribe(u)
    }["dt.useCallback[R]"], [
        m
    ]), E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "dt.useCallback[E]": ()=>{
            let u = m.getSnapshot();
            return r === "start" ? u.start : u.end;
        }
    }["dt.useCallback[E]"], [
        r,
        m
    ]), h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"](R, E, E), I = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "dt.useCallback[I]": (u)=>{
            h && (L.current?.(u), u.defaultPrevented || (u.currentTarget.blur(), r === "start" ? v({
                behavior: e
            }) : b$1({
                behavior: e
            })));
        }
    }["dt.useCallback[I]"], [
        e,
        r,
        h,
        L,
        b$1,
        v
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "button",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            type: S,
            inert: !h,
            tabIndex: h ? c : -1,
            children: t ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                children: [
                    "Scroll to ",
                    r
                ]
            }),
            onClick: I
        }, o),
        render: l,
        state: {
            active: h,
            direction: r
        },
        stateAttributesMapping: {
            active: (u)=>({
                    "data-active": u ? "true" : "false"
                })
        }
    });
}
var er = {
    Provider: ft,
    Root: gt,
    Viewport: Rt,
    Content: pt,
    Item: mt,
    Button: dt
};
;
}),
"[project]/node_modules/.pnpm/@shadcn+react@0.3.1_@types+react@19.2.14_react@19.2.4/node_modules/@shadcn/react/dist/questionnaire/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Questionnaire",
    ()=>zt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@shadcn+react@0.3.1_@types+react@19.2.14_react@19.2.4/node_modules/@shadcn/react/dist/chunk-HBS6WEDP.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@opentelemetry+_897d872498326607d52df20562703537/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
var Pe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null), ve = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null), Ee = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function ne(e) {
    let t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ve);
    if (!t) throw new Error(`${e} must be used within a Questionnaire.Root component.`);
    return t;
}
function be(e) {
    let t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](Pe);
    if (!t) throw new Error(`${e} must be used within a Questionnaire.Choice component.`);
    return t;
}
function Z(e) {
    let t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](Ee);
    if (!t) throw new Error(`${e} must be used within a Questionnaire.Item component.`);
    return t;
}
function ce(e) {
    return Array.isArray(e) ? e.some((t)=>String(t).trim().length > 0) : e != null && String(e).trim().length > 0;
}
function me(e) {
    return e === "letters" ? Array.from({
        length: 26
    }, (t, i)=>String.fromCharCode(65 + i)) : e === "numbers" ? Array.from({
        length: 9
    }, (t, i)=>String(i + 1)) : [];
}
function He(e, t) {
    let i = t === "letters" ? e.toUpperCase() : e;
    return me(t).includes(i) ? i : null;
}
function Ie(e, t) {
    return [
        e,
        t ? "Enter" : null
    ].filter(Boolean).join(" ") || void 0;
}
function pe(e) {
    return e.type === "choice" ? e.element.checked : e.element.hasAttribute("name") && ce(e.element.value);
}
function $e(e) {
    return e?.type === "input" && [
        "email",
        "password",
        "search",
        "tel",
        "text",
        "url"
    ].includes(e.element.type) && !ce(e.element.value);
}
function he(e) {
    return e instanceof HTMLTextAreaElement || e instanceof HTMLSelectElement ? true : e instanceof HTMLInputElement ? ![
        "button",
        "checkbox",
        "radio",
        "reset",
        "submit"
    ].includes(e.type) : e instanceof HTMLElement && e.isContentEditable;
}
function le(e) {
    return e instanceof HTMLInputElement && e.type === "radio";
}
function Ke(e, t) {
    if (e.element === t.element) return 0;
    let i = e.element.compareDocumentPosition(t.element);
    return i & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : i & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
}
function Ue(e, t) {
    if (e.element === t.element) return 0;
    let i = e.element.compareDocumentPosition(t.element);
    return i & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : i & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
}
function qe({ checked: e, defaultChecked: t = false, disabled: i = false, onChange: a, value: s }) {
    let { disabled: o, hasInputAnswer: u, invalid: f, multiple: g, name: d, registerAnswerControl: c, registerAnswerSelection: S, required: B, resetVersion: Q, selectedAnswerIds: x, setAnswerDefault: U, setAnswerSelectionFromInteraction: P, shortcutByAnswerId: A, shortcutByChoiceValue: G, status: v, syncControlledAnswerSelection: C } = Z("Questionnaire.Choice"), E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"](), [O, V] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), L = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](t), N = e !== void 0, D = o || i, M = x.includes(E), y = N ? v === "skipped" ? false : e : M, R = g ? "checkbox" : "radio", w = G?.get(s) ?? A.get(E) ?? null;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "qe.useLayoutEffect": ()=>S(E, L.current)
    }["qe.useLayoutEffect"], [
        E,
        S
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "qe.useLayoutEffect": ()=>U(E, t)
    }["qe.useLayoutEffect"], [
        E,
        t,
        U
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "qe.useLayoutEffect": ()=>{
            if (O) return c({
                disabled: D,
                element: O,
                id: E,
                ownDisabled: i,
                type: "choice",
                value: s
            });
        }
    }["qe.useLayoutEffect"], [
        E,
        i,
        D,
        O,
        c,
        s
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "qe.useLayoutEffect": ()=>{
            N && C(E, e);
        }
    }["qe.useLayoutEffect"], [
        E,
        N,
        e,
        Q,
        C
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "qe.useLayoutEffect": ()=>{
            O && (O.defaultChecked = N ? e : t, Q > 0 && (O.checked = y));
        }
    }["qe.useLayoutEffect"], [
        y,
        N,
        e,
        t,
        O,
        Q
    ]);
    function X(T) {
        if (a?.(T), !T.defaultPrevented) {
            if (!N) {
                P(E, T.target.checked);
                return;
            }
            v === "skipped" && e === T.target.checked && P(E, e);
        }
    }
    let ie = {
        checked: y,
        disabled: D,
        invalid: f,
        shortcut: w,
        type: R
    };
    return {
        inputProps: {
            ref: V,
            "aria-invalid": f || void 0,
            "aria-keyshortcuts": Ie(w, !D && y),
            checked: y,
            disabled: D,
            id: E,
            name: v === "skipped" ? void 0 : d,
            onChange: X,
            required: B && !g && !u,
            type: R,
            value: s
        },
        state: ie
    };
}
function _e({ defaultValue: e, disabled: t = false, onChange: i, ref: a, type: s = "text", value: o }) {
    let { disabled: u, invalid: f, name: g, registerAnswerControl: d, registerAnswerSelection: c$1, resetVersion: S, selectedAnswerIds: B, setAnswerDefault: Q, setAnswerSelectionFromInteraction: x, syncControlledAnswerSelection: U } = Z("Questionnaire.Input"), P = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"](), A = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), G = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](ce(e)), v = o !== void 0, C = ce(e), E = ce(o), [O, V] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](C), L = u || t, N = v ? E : O, D = B.includes(P);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "_e.useLayoutEffect": ()=>c$1(P, G.current)
    }["_e.useLayoutEffect"], [
        P,
        c$1
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "_e.useLayoutEffect": ()=>Q(P, C)
    }["_e.useLayoutEffect"], [
        C,
        P,
        Q
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "_e.useLayoutEffect": ()=>{
            let w = A.current;
            if (w) return d({
                disabled: L,
                element: w,
                id: P,
                type: "input"
            });
        }
    }["_e.useLayoutEffect"], [
        L,
        P,
        d
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "_e.useLayoutEffect": ()=>{
            if (v) {
                U(P, E);
                return;
            }
            S > 0 && V(C);
        }
    }["_e.useLayoutEffect"], [
        v,
        E,
        o,
        C,
        P,
        S,
        U
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "_e.useLayoutEffect": ()=>{
            let w = A.current;
            !w || !v || (w.defaultValue = String(o));
        }
    }["_e.useLayoutEffect"], [
        v,
        o
    ]);
    function M(w) {
        if (i?.(w), w.defaultPrevented) return;
        let X = w.target.value.trim().length > 0;
        v || (V(X), x(P, X));
    }
    let y = {
        disabled: L,
        filled: N,
        invalid: f
    }, R = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "_e.useCallback[R]": (w)=>{
            A.current = w, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(a)?.(w);
        }
    }["_e.useCallback[R]"], [
        a
    ]);
    return {
        inputProps: {
            "aria-invalid": f || void 0,
            "aria-keyshortcuts": Ie(null, !L && N && D),
            defaultValue: v ? void 0 : e,
            disabled: L,
            form: D ? void 0 : "",
            id: P,
            name: D ? g : void 0,
            onChange: M,
            ref: R,
            type: s,
            value: v ? o : void 0
        },
        state: y
    };
}
function We(e) {
    return e === void 0 ? null : {
        enabledItems: e.filter((t)=>!t.disabled),
        itemByName: new Map(e.map((t)=>[
                t.name,
                t
            ])),
        items: e
    };
}
function we(e, t) {
    if (!e) return t ?? null;
    let i = t ? e.itemByName.get(t) : void 0;
    return i && !i.disabled ? i.name : e.enabledItems[0]?.name ?? null;
}
function Ge(e, t) {
    let i = new Map;
    if (!e || !t) return i;
    let a = me(t), s = 0;
    for (let o of e.choices ?? []){
        if (o.disabled) continue;
        let u = a[s];
        if (!u) break;
        i.set(o.value, u), s += 1;
    }
    return i;
}
function je(e, t) {
    let i = [], a = new Set;
    for (let s of e.items){
        a.has(s.name) && i.push(`Item name "${s.name}" is defined more than once.`), a.add(s.name);
        let o = new Set;
        for (let u of s.choices ?? [])o.has(u.value) && i.push(`Choice value "${u.value}" is defined more than once in item "${s.name}".`), o.add(u.value);
    }
    if (t) {
        let s = e.itemByName.get(t);
        (!s || s.disabled) && i.push(`defaultItem "${t}" does not identify an enabled item. The first enabled item will be used instead.`);
    }
    return i;
}
function ze(e, t, i) {
    let a = [], s = new Map(t.map((o)=>[
            o.name,
            o
        ]));
    for (let o of e.items){
        let u = s.get(o.name);
        if (!u) {
            o.disabled || a.push(`Item "${o.name}" is defined but has no rendered Questionnaire.Item.`);
            continue;
        }
        u.disabled !== !!o.disabled && a.push(`Item "${o.name}" has different disabled values in Root.items and Questionnaire.Item.`), u.required !== !!o.required && a.push(`Item "${o.name}" has different required values in Root.items and Questionnaire.Item.`);
        let f = o.choices ?? [], g = new Map(f.map((c)=>[
                c.value,
                c
            ])), d = new Map(u.choices.map((c)=>[
                c.value,
                c
            ]));
        for (let c of f){
            let S = d.get(c.value);
            if (!S) {
                a.push(`Choice "${c.value}" is defined for item "${o.name}" but has no rendered Questionnaire.Choice.`);
                continue;
            }
            S.disabled !== !!c.disabled && a.push(`Choice "${c.value}" in item "${o.name}" has different disabled values in Root.items and Questionnaire.Choice.`);
        }
        if (i) {
            for (let Q of u.choices)g.has(Q.value) || a.push(`Rendered choice "${Q.value}" in item "${o.name}" is missing from Root.items and will not receive a shortcut.`);
            let c = f.filter((Q)=>!Q.disabled).map((Q)=>Q.value), S = u.choices.filter((Q)=>!Q.disabled).map((Q)=>Q.value);
            c.length > 0 && c.length === S.length && c.every((Q)=>S.includes(Q)) && c.some((Q, x)=>Q !== S[x]) && a.push(`Choice order for item "${o.name}" differs between Root.items and the rendered Questionnaire.Choice elements.`);
        }
    }
    for (let o of t)!o.disabled && !e.itemByName.has(o.name) && a.push(`Rendered item "${o.name}" is missing from Root.items and is excluded from the questionnaire collection.`);
    return a;
}
function Je({ "aria-describedby": e, "aria-keyshortcuts": t, disabled: i = false, invalid: a = false, multiple: s = false, name: o, onStatusChange: u, ref: f, required: g = false }) {
    let { activeItemName: d, domVersion: c$1, first: S, itemDefinitionByName: B, last: Q, nativeValidation: x, registerItem: U, shortcuts: P } = ne("Questionnaire.Item"), [A, G] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), [v, C] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]), [E, O] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false), [V, L] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]), [N, D] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false), [M, y] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0), [R, w] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]), [X, ie] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]([]), q = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](s), de = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](s);
    q.current = s;
    let _ = !i && d === o, j = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Je.useMemo[j]": ()=>[
                ...v
            ].sort(Ue)
    }["Je.useMemo[j]"], [
        v,
        c$1
    ]), h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Je.useMemo[h]": ()=>j.filter({
                "Je.useMemo[h]": (r)=>!r.disabled
            }["Je.useMemo[h]"])
    }["Je.useMemo[h]"], [
        j
    ]), ge = h.some((r)=>V.includes(r.id)), F = N ? "skipped" : ge ? "answered" : "unanswered", re = F === "skipped" && !g, se = i || re || !a && F === "answered", ee = !i && !re && (a || E && !se), Re = h.some((r)=>r.type === "input"), Qe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](F), Ce = B?.get(o), J = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Je.useMemo[J]": ()=>B ? Ge(Ce, P) : null
    }["Je.useMemo[J]"], [
        Ce,
        B,
        P
    ]), ae = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Je.useMemo[ae]": ()=>{
            if (J) return new Map;
            let r = me(P), m = h.filter({
                "Je.useMemo[ae].m": (l)=>l.type === "choice"
            }["Je.useMemo[ae].m"]);
            return new Map(m.slice(0, r.length).map({
                "Je.useMemo[ae]": (l, $)=>[
                        l.id,
                        r[$]
                    ]
            }["Je.useMemo[ae]"]));
        }
    }["Je.useMemo[ae]"], [
        h,
        J,
        P
    ]), ye = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[ye]": (r)=>(C({
                "Je.useCallback[ye]": (m)=>[
                        ...m.filter({
                            "Je.useCallback[ye]": (l)=>l.element !== r.element && l.id !== r.id
                        }["Je.useCallback[ye]"]),
                        r
                    ]
            }["Je.useCallback[ye]"]), ({
                "Je.useCallback[ye]": ()=>{
                    C({
                        "Je.useCallback[ye]": (m)=>m.filter({
                                "Je.useCallback[ye]": (l)=>l !== r
                            }["Je.useCallback[ye]"])
                    }["Je.useCallback[ye]"]);
                }
            })["Je.useCallback[ye]"])
    }["Je.useCallback[ye]"], []);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Je.useLayoutEffect": ()=>{
            Qe.current !== F && (Qe.current = F, u?.(F));
        }
    }["Je.useLayoutEffect"], [
        u,
        F
    ]);
    let n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[n]": (r, m)=>{
            L({
                "Je.useCallback[n]": (l)=>m ? s ? l.includes(r) ? l : [
                        ...l,
                        r
                    ] : [
                        r
                    ] : l.filter({
                        "Je.useCallback[n]": ($)=>$ !== r
                    }["Je.useCallback[n]"])
            }["Je.useCallback[n]"]);
        }
    }["Je.useCallback[n]"], [
        s
    ]), b = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[b]": (r, m)=>{
            D(false), n(r, m);
        }
    }["Je.useCallback[b]"], [
        n
    ]), k = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[k]": (r, m)=>{
            m && D(false), n(r, m);
        }
    }["Je.useCallback[k]"], [
        n
    ]), Y = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Y]": (r, m)=>(m && (T.current = [
                ...T.current.filter({
                    "Je.useCallback[Y]": (l)=>l !== r
                }["Je.useCallback[Y]"]),
                r
            ], L({
                "Je.useCallback[Y]": (l)=>q.current ? l.includes(r) ? l : [
                        ...l,
                        r
                    ] : l.length ? l : [
                        r
                    ]
            }["Je.useCallback[Y]"])), ({
                "Je.useCallback[Y]": ()=>{
                    T.current = T.current.filter({
                        "Je.useCallback[Y]": (l)=>l !== r
                    }["Je.useCallback[Y]"]), L({
                        "Je.useCallback[Y]": (l)=>l.filter({
                                "Je.useCallback[Y]": ($)=>$ !== r
                            }["Je.useCallback[Y]"])
                    }["Je.useCallback[Y]"]);
                }
            })["Je.useCallback[Y]"])
    }["Je.useCallback[Y]"], []), xe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[xe]": (r, m)=>{
            if (m) {
                T.current = T.current.includes(r) ? T.current : [
                    ...T.current,
                    r
                ];
                return;
            }
            T.current = T.current.filter({
                "Je.useCallback[xe]": (l)=>l !== r
            }["Je.useCallback[xe]"]);
        }
    }["Je.useCallback[xe]"], []), Me = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Me]": (r)=>(w({
                "Je.useCallback[Me]": (m)=>m.includes(r) ? m : [
                        ...m,
                        r
                    ]
            }["Je.useCallback[Me]"]), ({
                "Je.useCallback[Me]": ()=>{
                    w({
                        "Je.useCallback[Me]": (m)=>m.filter({
                                "Je.useCallback[Me]": (l)=>l !== r
                            }["Je.useCallback[Me]"])
                    }["Je.useCallback[Me]"]);
                }
            })["Je.useCallback[Me]"])
    }["Je.useCallback[Me]"], []), Ae = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Ae]": (r)=>(ie({
                "Je.useCallback[Ae]": (m)=>m.includes(r) ? m : [
                        ...m,
                        r
                    ]
            }["Je.useCallback[Ae]"]), ({
                "Je.useCallback[Ae]": ()=>{
                    ie({
                        "Je.useCallback[Ae]": (m)=>m.filter({
                                "Je.useCallback[Ae]": (l)=>l !== r
                            }["Je.useCallback[Ae]"])
                    }["Je.useCallback[Ae]"]);
                }
            })["Je.useCallback[Ae]"])
    }["Je.useCallback[Ae]"], []), Ne = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Ne]": ()=>{
            if (O(true), !se) return false;
            if (!x) return true;
            let r = h.find({
                "Je.useCallback[Ne].r": (m)=>pe(m) && m.element.willValidate && !m.element.validity.valid
            }["Je.useCallback[Ne].r"]);
            return r ? (r.element.focus(), r.element.reportValidity(), false) : true;
        }
    }["Je.useCallback[Ne]"], [
        h,
        x,
        se
    ]), Te = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Te]": ()=>{
            A?.focus();
        }
    }["Je.useCallback[Te]"], [
        A
    ]), Le = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Le]": ()=>{
            let r = A?.querySelector("input[data-filled][name]:not(:disabled)"), m = A?.querySelector("input:not([type=hidden]):not(:disabled), textarea:not(:disabled)");
            (r ?? m ?? A)?.focus();
        }
    }["Je.useCallback[Le]"], [
        A
    ]), De = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[De]": ()=>{
            O(false), D(false), L(s ? [
                ...T.current
            ] : T.current.slice(0, 1)), y({
                "Je.useCallback[De]": (r)=>r + 1
            }["Je.useCallback[De]"]);
        }
    }["Je.useCallback[De]"], [
        s
    ]), Be = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Be]": ()=>{
            g || (L([]), D(true));
        }
    }["Je.useCallback[Be]"], [
        g
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Je.useLayoutEffect": ()=>{
            let r = de.current;
            de.current = s, !(!r || s) && L({
                "Je.useLayoutEffect": (m)=>{
                    let l = h.find({
                        "Je.useLayoutEffect.l": ($)=>m.includes($.id)
                    }["Je.useLayoutEffect.l"]);
                    return l ? [
                        l.id
                    ] : [];
                }
            }["Je.useLayoutEffect"]);
        }
    }["Je.useLayoutEffect"], [
        h,
        s
    ]);
    let Fe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Fe]": (r)=>h.find({
                "Je.useCallback[Fe]": (m)=>m.element === r
            }["Je.useCallback[Fe]"]) ?? null
    }["Je.useCallback[Fe]"], [
        h
    ]), Ve = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Ve]": (r)=>{
            if (J) {
                let l = Array.from(J.entries()).find({
                    "Je.useCallback[Ve]": ([, $])=>$ === r
                }["Je.useCallback[Ve]"])?.[0];
                return h.find({
                    "Je.useCallback[Ve]": ($)=>$.type === "choice" && $.value === l
                }["Je.useCallback[Ve]"]) ?? null;
            }
            let m = Array.from(ae.entries()).find({
                "Je.useCallback[Ve]": ([, l])=>l === r
            }["Je.useCallback[Ve]"])?.[0];
            return h.find({
                "Je.useCallback[Ve]": (l)=>l.id === m
            }["Je.useCallback[Ve]"]) ?? null;
        }
    }["Je.useCallback[Ve]"], [
        h,
        ae,
        J
    ]), Oe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[Oe]": (r, m)=>{
            let l = h.findIndex({
                "Je.useCallback[Oe].l": (Qt)=>Qt.element === r
            }["Je.useCallback[Oe].l"]), $ = l < 0 ? null : h[l] ?? null;
            if (!h.length || he(r) && !$e($) || l < 0 && r !== A) return false;
            let oe = l < 0 ? h.find(pe) ?? (m === "next" ? h[0] : h[h.length - 1]) : h[(l + (m === "next" ? 1 : -1) + h.length) % h.length];
            return !oe || oe.element === r || l >= 0 && le(r) && le(oe.element) ? false : (oe.element.focus(), oe.type === "choice" && le(oe.element) && oe.element.click(), true);
        }
    }["Je.useCallback[Oe]"], [
        h,
        A
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Je.useLayoutEffect": ()=>{
            if (A) return U({
                choices: j.flatMap({
                    "Je.useLayoutEffect": (r)=>r.type === "choice" ? [
                            {
                                disabled: r.ownDisabled,
                                value: r.value
                            }
                        ] : []
                }["Je.useLayoutEffect"]),
                disabled: i,
                element: A,
                focus: Te,
                focusInvalid: Le,
                getAnswerByElement: Fe,
                getAnswerByShortcut: Ve,
                moveAnswerFocus: Oe,
                name: o,
                required: g,
                reset: De,
                skip: Be,
                status: F,
                validate: Ne
            });
        }
    }["Je.useLayoutEffect"], [
        j,
        i,
        A,
        Te,
        Le,
        Fe,
        Ve,
        Oe,
        o,
        U,
        g,
        De,
        Be,
        F,
        Ne
    ]);
    let pt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Je.useMemo[pt]": ()=>({
                active: _,
                disabled: i,
                hasInputAnswer: Re,
                invalid: ee,
                multiple: s,
                name: o,
                registerAnswerControl: ye,
                registerAnswerSelection: Y,
                registerDescription: Me,
                registerError: Ae,
                required: g,
                resetVersion: M,
                selectedAnswerIds: V,
                setAnswerDefault: xe,
                setAnswerSelectionFromInteraction: b,
                shortcutByAnswerId: ae,
                shortcutByChoiceValue: J,
                shortcuts: P,
                status: F,
                syncControlledAnswerSelection: k
            })
    }["Je.useMemo[pt]"], [
        _,
        i,
        Re,
        ee,
        s,
        o,
        ye,
        Y,
        Me,
        Ae,
        g,
        M,
        V,
        xe,
        b,
        ae,
        J,
        P,
        F,
        k
    ]), ht = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Je.useCallback[ht]": (r)=>{
            G(r), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(f)?.(r);
        }
    }["Je.useCallback[ht]"], [
        f
    ]), gt = [
        ...R,
        ...ee ? X : [],
        e
    ].filter(Boolean).join(" ") || void 0, Rt = [
        t,
        _ ? "Meta+Enter Control+Enter" : void 0,
        _ && h.length ? "ArrowUp ArrowDown" : void 0,
        _ && !S ? "ArrowLeft" : void 0,
        _ && !Q && F !== "unanswered" ? "ArrowRight" : void 0
    ].filter(Boolean).join(" ") || void 0;
    return {
        context: pt,
        itemProps: {
            "aria-describedby": gt,
            "aria-invalid": ee || void 0,
            "aria-keyshortcuts": Rt,
            disabled: i,
            hidden: !_,
            inert: !_,
            ref: ht,
            tabIndex: -1
        },
        state: {
            active: _,
            disabled: i,
            invalid: ee,
            multiple: s,
            required: g,
            status: F
        }
    };
}
function Xe({ defaultItem: e, item: t, items: i, noValidate: a, onItemChange: s, onReset: o, onSubmit: u, ref: f, shortcuts: g }) {
    let d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Xe.useMemo[d]": ()=>We(i)
    }["Xe.useMemo[d]"], [
        i
    ]), [c$1, S] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]), [B, Q] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "Xe.useState": ()=>we(d, e)
    }["Xe.useState"]), [x, U] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), [P, A] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](0), G = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), v = t !== void 0, C = v ? t : B, E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](C), O = a === false, V = g ?? null, L = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](new Set);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Xe.useLayoutEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            if (!d || !x) {
                L.current.clear();
                return;
            }
            let n = false;
            return queueMicrotask({
                "Xe.useLayoutEffect": ()=>{
                    if (n) return;
                    let b = [
                        ...je(d, e),
                        ...ze(d, c$1, V)
                    ], k = new Set(b);
                    k.forEach({
                        "Xe.useLayoutEffect": (Y)=>{
                            L.current.has(Y) || console.warn(`[Questionnaire] ${Y}`);
                        }
                    }["Xe.useLayoutEffect"]), L.current = k;
                }
            }["Xe.useLayoutEffect"]), ({
                "Xe.useLayoutEffect": ()=>{
                    n = true;
                }
            })["Xe.useLayoutEffect"];
        }
    }["Xe.useLayoutEffect"], [
        d,
        e,
        c$1,
        x,
        V
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Xe.useLayoutEffect": ()=>{
            if (!x || typeof MutationObserver > "u") return;
            let n = new MutationObserver({
                "Xe.useLayoutEffect": ()=>{
                    A({
                        "Xe.useLayoutEffect": (b)=>b + 1
                    }["Xe.useLayoutEffect"]);
                }
            }["Xe.useLayoutEffect"]);
            return n.observe(x, {
                childList: true,
                subtree: true
            }), ({
                "Xe.useLayoutEffect": ()=>n.disconnect()
            })["Xe.useLayoutEffect"];
        }
    }["Xe.useLayoutEffect"], [
        x
    ]);
    let N = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Xe.useMemo[N]": ()=>c$1.filter({
                "Xe.useMemo[N]": (n)=>!n.disabled
            }["Xe.useMemo[N]"]).sort(Ke)
    }["Xe.useMemo[N]"], [
        P,
        c$1
    ]), D = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Xe.useMemo[D]": ()=>new Map(N.map({
                "Xe.useMemo[D]": (n)=>[
                        n.name,
                        n
                    ]
            }["Xe.useMemo[D]"]))
    }["Xe.useMemo[D]"], [
        N
    ]), M = d?.enabledItems ?? N, y = M.findIndex((n)=>n.name === C), R = y < 0 || !C ? null : D.get(C) ?? null, w = C ? d?.itemByName.get(C) : void 0, X = y < 0 ? null : w ? !!w.required : R?.required ?? false, ie = y < 0 ? null : R?.status ?? (C ? "unanswered" : null), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Xe.useMemo[T]": ()=>d ? d.enabledItems.flatMap({
                "Xe.useMemo[T]": (n)=>{
                    let b = D.get(n.name);
                    return b ? [
                        b
                    ] : [];
                }
            }["Xe.useMemo[T]"]) : N
    }["Xe.useMemo[T]"], [
        d,
        D,
        N
    ]), q = M.length, de = y < 0 ? 0 : y + 1, _ = q > 0 && y === 0, j = q > 0 && y === q - 1, h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[h]": (n, b = "item")=>{
            n !== C && (G.current = {
                name: n,
                target: b
            }, v || Q(n), s?.(n));
        }
    }["Xe.useCallback[h]"], [
        C,
        v,
        s
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "Xe.useLayoutEffect": ()=>{
            if (q === 0) return;
            if (y < 0) {
                if (!v && C === null) {
                    Q(M[0].name);
                    return;
                }
                h(M[0].name);
                return;
            }
            let n = G.current, b = E.current !== C;
            if (E.current = C, !n || n.name !== C) {
                v && b && (G.current = null, R?.focus());
                return;
            }
            n.target === "invalid" ? R?.focusInvalid() : R?.focus(), G.current = null;
        }
    }["Xe.useLayoutEffect"], [
        R,
        C,
        v,
        y,
        M,
        h,
        q
    ]);
    let ge = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[ge]": (n)=>(S({
                "Xe.useCallback[ge]": (b)=>[
                        ...b.filter({
                            "Xe.useCallback[ge]": (k)=>k.element !== n.element && k.name !== n.name
                        }["Xe.useCallback[ge]"]),
                        n
                    ]
            }["Xe.useCallback[ge]"]), ({
                "Xe.useCallback[ge]": ()=>{
                    S({
                        "Xe.useCallback[ge]": (b)=>b.filter({
                                "Xe.useCallback[ge]": (k)=>k !== n
                            }["Xe.useCallback[ge]"])
                    }["Xe.useCallback[ge]"]);
                }
            })["Xe.useCallback[ge]"])
    }["Xe.useCallback[ge]"], []), F = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[F]": ()=>{
            y <= 0 || h(M[y - 1].name);
        }
    }["Xe.useCallback[F]"], [
        y,
        M,
        h
    ]), re = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[re]": ()=>{
            if (!(!R || y >= q - 1)) {
                if (!R.validate()) {
                    R.focusInvalid();
                    return;
                }
                h(M[y + 1].name);
            }
        }
    }["Xe.useCallback[re]"], [
        R,
        y,
        M,
        h,
        q
    ]), se = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[se]": ()=>{
            if (R) {
                if (!R.validate()) {
                    R.focusInvalid();
                    return;
                }
                if (j) {
                    x?.requestSubmit();
                    return;
                }
                h(M[y + 1].name);
            }
        }
    }["Xe.useCallback[se]"], [
        R,
        y,
        j,
        M,
        x,
        h
    ]), ee = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[ee]": ()=>{
            if (!(!R || R.required)) {
                if (R.skip(), !j) {
                    h(M[y + 1].name);
                    return;
                }
                queueMicrotask({
                    "Xe.useCallback[ee]": ()=>{
                        x?.requestSubmit();
                    }
                }["Xe.useCallback[ee]"]);
            }
        }
    }["Xe.useCallback[ee]"], [
        R,
        y,
        j,
        M,
        x,
        h
    ]);
    function Re(n) {
        if (o?.(n), n.defaultPrevented) return;
        for (let k of c$1)k.reset();
        let b = d ? we(d, e) : N.find((k)=>k.name === e)?.name ?? N[0]?.name;
        b && h(b);
    }
    function Qe(n) {
        let b = T.find((k)=>!k.validate());
        if (b) {
            n.preventDefault(), h(b.name, "invalid"), b.name === C && (b.focusInvalid(), G.current = null);
            return;
        }
        u?.(n);
    }
    function Ce(n) {
        if (n.defaultPrevented || n.nativeEvent.isComposing || n.keyCode === 229 || !R || !(n.target instanceof Element)) return;
        if (n.key === "Enter" && (n.metaKey || n.ctrlKey) && !n.altKey && !n.shiftKey) {
            n.preventDefault(), n.repeat || se();
            return;
        }
        if (n.metaKey || n.ctrlKey || n.altKey) return;
        if ((n.key === "ArrowUp" || n.key === "ArrowDown") && R.moveAnswerFocus(n.target, n.key === "ArrowDown" ? "next" : "previous")) {
            n.preventDefault();
            return;
        }
        if ((n.key === "ArrowLeft" || n.key === "ArrowRight") && !he(n.target) && !le(n.target)) {
            if (n.preventDefault(), n.repeat) return;
            n.key === "ArrowLeft" ? F() : R.status !== "unanswered" && re();
            return;
        }
        if (n.key === "Enter") {
            let Y = R.getAnswerByElement(n.target);
            if (!Y) return;
            n.preventDefault(), !n.repeat && pe(Y) && se();
            return;
        }
        if (!V || he(n.target)) return;
        let b = He(n.key, V), k = b ? R.getAnswerByShortcut(b) : null;
        k && (n.preventDefault(), !n.repeat && (k.element.focus(), k.type === "choice" && k.element.click()));
    }
    let J = {
        current: de,
        first: _,
        last: j,
        total: q
    }, ae = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Xe.useMemo[ae]": ()=>({
                ...J,
                activeItem: R,
                activeItemName: C,
                activeItemRequired: X,
                activeItemStatus: ie,
                domVersion: P,
                goNext: re,
                goPrevious: F,
                itemDefinitionByName: d?.itemByName ?? null,
                nativeValidation: O,
                registerItem: ge,
                shortcuts: V,
                skipCurrent: ee
            })
    }["Xe.useMemo[ae]"], [
        R,
        C,
        X,
        ie,
        d,
        de,
        P,
        _,
        re,
        F,
        j,
        O,
        ge,
        V,
        ee,
        q
    ]), ye = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Xe.useCallback[ye]": (n)=>{
            U(n), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(f)?.(n);
        }
    }["Xe.useCallback[ye]"], [
        f
    ]);
    return {
        context: ae,
        rootProps: {
            "data-shortcuts": V ?? void 0,
            onKeyDown: Ce,
            onReset: Re,
            onSubmit: Qe,
            ref: ye
        },
        state: J
    };
}
function Ye({ defaultItem: e, item: t, items: i, noValidate: a$1 = true, onItemChange: s, onReset: o, onSubmit: u, ref: f, shortcuts: g, ...d }) {
    let { context: c, rootProps: S, state: B } = Xe({
        defaultItem: e,
        item: t,
        items: i,
        noValidate: a$1,
        onItemChange: s,
        onReset: o,
        onSubmit: u,
        ref: f,
        shortcuts: g
    }), Q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "form",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            ...S,
            noValidate: a$1
        }, d),
        state: B
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ve.Provider, {
        value: c,
        children: Q
    });
}
function Ze({ children: e, render: t, ...i }) {
    let { current: a$1, first: s, last: o, total: u } = ne("Questionnaire.Progress"), f = u ? `Question ${a$1} of ${u}` : void 0;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "div",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            "aria-label": "Questionnaire progress",
            "aria-live": "polite",
            "aria-valuemax": u || void 0,
            "aria-valuemin": u ? 1 : void 0,
            "aria-valuenow": u ? a$1 : void 0,
            "aria-valuetext": f,
            children: e ?? f,
            role: "progressbar"
        }, i),
        render: t,
        state: {
            current: a$1,
            first: s,
            last: o,
            total: u
        }
    });
}
function et({ "aria-describedby": e, "aria-keyshortcuts": t, children: i, disabled: a$1 = false, invalid: s = false, multiple: o = false, name: u, onStatusChange: f, ref: g, required: d = false, ...c }) {
    let { context: S, itemProps: B, state: Q } = Je({
        "aria-describedby": e,
        "aria-keyshortcuts": t,
        disabled: a$1,
        invalid: s,
        multiple: o,
        name: u,
        onStatusChange: f,
        ref: g,
        required: d
    }), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "fieldset",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            ...B,
            children: i
        }, c),
        state: Q,
        stateAttributesMapping: {
            active: (U)=>({
                    "data-active": U ? "" : void 0
                })
        }
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ee.Provider, {
        value: S,
        children: x
    });
}
function tt({ render: e, ...t }) {
    return Z("Questionnaire.Title"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "legend",
        props: t,
        render: e
    });
}
function nt({ id: e, render: t, ...i }) {
    let { registerDescription: a$1 } = Z("Questionnaire.Description"), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"](), o = e ?? s;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "nt.useLayoutEffect": ()=>a$1(o)
    }["nt.useLayoutEffect"], [
        o,
        a$1
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "p",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            id: o
        }, i),
        render: t
    });
}
function it({ render: e, ...t }) {
    let { shortcuts: i } = Z("Questionnaire.Choices");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "div",
        props: t,
        render: e,
        state: {
            shortcuts: i
        }
    });
}
function ot({ checked: e, children: t, defaultChecked: i = false, disabled: a$1 = false, onChange: s, render: o, value: u, ...f }) {
    let { inputProps: g, state: d } = qe({
        checked: e,
        defaultChecked: i,
        disabled: a$1,
        onChange: s,
        value: u
    }), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "label",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            children: t
        }, f),
        render: o,
        state: d,
        stateAttributesMapping: {
            checked: (S)=>({
                    "data-checked": S ? "" : void 0,
                    "data-unchecked": S ? void 0 : ""
                })
        }
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Pe.Provider, {
        value: {
            inputProps: g,
            state: d
        },
        children: c
    });
}
function rt({ render: e, ...t }) {
    let { inputProps: i, state: a$1 } = be("Questionnaire.ChoiceInput");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "input",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(i, t),
        render: e,
        state: a$1,
        stateAttributesMapping: {
            checked: (s)=>({
                    "data-checked": s ? "" : void 0,
                    "data-unchecked": s ? void 0 : ""
                })
        }
    });
}
function st({ render: e, ...t }) {
    return be("Questionnaire.ChoiceLabel"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "span",
        props: t,
        render: e
    });
}
function at({ children: e, render: t, ...i }) {
    let { state: a$1 } = be("Questionnaire.ChoiceShortcut"), s = {
        shortcut: a$1.shortcut
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "span",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            "aria-hidden": true,
            children: e ?? a$1.shortcut,
            hidden: a$1.shortcut === null
        }, i),
        render: t,
        state: s
    });
}
function ut({ defaultValue: e, disabled: t = false, onChange: i, ref: a$1, render: s, type: o = "text", value: u, ...f }) {
    let { inputProps: g, state: d } = _e({
        defaultValue: e,
        disabled: t,
        onChange: i,
        ref: a$1,
        type: o,
        value: u
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "input",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(g, f),
        render: s,
        state: d,
        stateAttributesMapping: {
            filled: (c)=>({
                    "data-empty": c ? void 0 : "",
                    "data-filled": c ? "" : void 0
                })
        }
    });
}
function ct({ children: e, id: t, render: i, ...a$1 }) {
    let { invalid: s, registerError: o, required: u } = Z("Questionnaire.Error"), f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"](), g = t ?? f;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$opentelemetry$2b$_897d872498326607d52df20562703537$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "ct.useLayoutEffect": ()=>o(g)
    }["ct.useLayoutEffect"], [
        g,
        o
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "p",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            children: e ?? (u ? "Choose an answer to continue." : "Choose an answer or skip this question."),
            hidden: !s,
            id: g,
            role: s ? "alert" : void 0
        }, a$1),
        render: i,
        state: {
            invalid: s
        }
    });
}
function lt({ children: e, disabled: t = false, onClick: i, render: a, tabIndex: s, type: o = "button", ...u }) {
    let f = ne("Questionnaire.Previous"), g = f.total > 1 && !f.first;
    function d(c) {
        i?.(c), c.defaultPrevented || f.goPrevious();
    }
    return Se({
        children: e ?? "Previous",
        disabled: t,
        onClick: d,
        props: u,
        render: a,
        status: f.activeItemStatus,
        tabIndex: s,
        type: o,
        visible: g
    });
}
function ft({ children: e, disabled: t = false, onClick: i, render: a, tabIndex: s, type: o = "button", ...u }) {
    let f = ne("Questionnaire.Skip"), g = f.activeItemRequired === false;
    function d(c) {
        i?.(c), c.defaultPrevented || f.skipCurrent();
    }
    return Se({
        children: e ?? "Skip",
        disabled: t,
        onClick: d,
        props: u,
        render: a,
        status: f.activeItemStatus,
        tabIndex: s,
        type: o,
        visible: g
    });
}
function dt({ children: e, disabled: t = false, onClick: i, render: a, tabIndex: s, type: o = "button", ...u }) {
    let f = ne("Questionnaire.Next"), g = f.total > 1 && !f.last;
    function d(c) {
        i?.(c), c.defaultPrevented || f.goNext();
    }
    return Se({
        children: e ?? "Next",
        disabled: t,
        onClick: d,
        props: u,
        render: a,
        shortcut: "Enter",
        status: f.activeItemStatus,
        tabIndex: s,
        type: o,
        visible: g
    });
}
function mt({ children: e, disabled: t = false, render: i, tabIndex: a, type: s = "submit", ...o }) {
    let u = ne("Questionnaire.Submit"), f = u.total > 0 && u.last;
    return Se({
        children: e ?? "Submit",
        disabled: t,
        props: o,
        render: i,
        shortcut: "Enter",
        status: u.activeItemStatus,
        tabIndex: a,
        type: s,
        visible: f
    });
}
function Se({ children: e, disabled: t, onClick: i, props: a$1, render: s, shortcut: o, status: u, tabIndex: f, type: g, visible: d }) {
    let c = d && !t ? o ?? null : null, S = {
        disabled: t,
        shortcut: c,
        status: u,
        visible: d
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])({
        defaultTagName: "button",
        props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$shadcn$2b$react$40$0$2e$3$2e$1_$40$types$2b$react$40$19$2e$2$2e$14_react$40$19$2e$2$2e$4$2f$node_modules$2f40$shadcn$2f$react$2f$dist$2f$chunk$2d$HBS6WEDP$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])({
            "aria-hidden": !d || void 0,
            "aria-keyshortcuts": c ?? void 0,
            children: e,
            disabled: t,
            hidden: !d,
            inert: !d,
            onClick: i,
            tabIndex: d ? f : -1,
            type: g
        }, a$1),
        render: s,
        state: S,
        stateAttributesMapping: {
            visible: (B)=>({
                    "data-hidden": B ? void 0 : "",
                    "data-visible": B ? "" : void 0
                })
        }
    });
}
var zt = {
    Root: Ye,
    Progress: Ze,
    Item: et,
    Title: tt,
    Description: nt,
    Choices: it,
    Choice: ot,
    ChoiceInput: rt,
    ChoiceLabel: st,
    ChoiceShortcut: at,
    Input: ut,
    Error: ct,
    Previous: lt,
    Skip: ft,
    Next: dt,
    Submit: mt
};
;
}),
]);

//# sourceMappingURL=0_hh_%40shadcn_react_dist_0kxuuu1._.js.map