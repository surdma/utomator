(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04wfz00._.css","static/chunks/0ohs_next_0win83v._.js","static/chunks/apps_frontend_components_0f~opln._.js"],
    source: "dynamic"
});
